package dev.horizonlab.parity;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.SharedConstants;
import net.minecraft.core.Holder;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.biome.MultiNoiseBiomeSource;

/** 1.18.2's data generator emits no biome_parameters report (the
 * report arrives in 1.19), so the multi-noise parameter tables the
 * worldgen bundle needs exist only in code: the OVERWORLD and
 * NETHER preset parameter lists. Export them in the report's own
 * JSON form: a span parameter as [min, max], a point as a bare
 * number, values unquantized from Climate's 1/10000 scale. */
public class VanillaBiomeParametersExporter {
    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        Path dir = Path.of(args[0]);
        Files.createDirectories(dir);
        write(dir, "overworld", MultiNoiseBiomeSource.Preset.OVERWORLD);
        write(dir, "nether", MultiNoiseBiomeSource.Preset.NETHER);
    }

    private static void write(Path dir, String name, MultiNoiseBiomeSource.Preset preset) throws Exception {
        var source = preset.biomeSource(BuiltinRegistries.BIOME);
        var field = MultiNoiseBiomeSource.class.getDeclaredField("parameters");
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        var list = (Climate.ParameterList<Holder<Biome>>) field.get(source);
        var biomes = new JsonArray();
        for (var pair : list.values()) {
            var point = pair.getFirst();
            var entry = new JsonObject();
            entry.addProperty("biome", BuiltinRegistries.BIOME.getKey(pair.getSecond().value()).toString());
            var params = new JsonObject();
            params.add("continentalness", param(point.continentalness()));
            params.add("depth", param(point.depth()));
            params.add("erosion", param(point.erosion()));
            params.add("humidity", param(point.humidity()));
            params.addProperty("offset", point.offset() / 10000.0);
            params.add("temperature", param(point.temperature()));
            params.add("weirdness", param(point.weirdness()));
            entry.add("parameters", params);
            biomes.add(entry);
        }
        var root = new JsonObject();
        root.add("biomes", biomes);
        Files.writeString(dir.resolve(name + ".json"), root.toString());
    }

    private static JsonElement param(Climate.Parameter p) {
        if (p.min() == p.max()) {
            return new JsonPrimitive(p.min() / 10000.0);
        }
        var span = new JsonArray();
        span.add(p.min() / 10000.0);
        span.add(p.max() / 10000.0);
        return span;
    }
}
