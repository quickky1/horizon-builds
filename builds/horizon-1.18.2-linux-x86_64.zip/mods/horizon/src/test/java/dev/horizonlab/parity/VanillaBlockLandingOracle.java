package dev.horizonlab.parity;
import com.google.gson.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.level.gameevent.*;
import net.minecraft.world.phys.*;
/** Runs registered native landing/bounce methods with controlled observable providers. */
public final class VanillaBlockLandingOracle {
    static final class Stop extends RuntimeException {}
    static Object unsafe;static Method allocate;
    static <T>T make(Class<T> type){try{return type.cast(allocate.invoke(unsafe,type));}catch(Exception e){throw new AssertionError(e);}}
    static double number(JsonElement v){return Double.longBitsToDouble(Long.parseUnsignedLong(v.getAsString(),16));}
    static float single(JsonElement v){return Float.intBitsToFloat(Integer.parseUnsignedInt(v.getAsString(),16));}
    static String pos(BlockPos p){return p.getX()+" "+p.getY()+" "+p.getZ();}
    static String bounds(String label,AABB b){return String.format("%s %016x %016x %016x %016x %016x %016x",label,Double.doubleToLongBits(b.minX),Double.doubleToLongBits(b.minY),Double.doubleToLongBits(b.minZ),Double.doubleToLongBits(b.maxX),Double.doubleToLongBits(b.maxY),Double.doubleToLongBits(b.maxZ));}
    static AABB box(JsonElement v){var a=v.getAsJsonArray();return new AABB(number(a.get(0)),number(a.get(1)),number(a.get(2)),number(a.get(3)),number(a.get(4)),number(a.get(5)));}
    static String sound(SoundEvent s){if(s==SoundEvents.HONEY_BLOCK_SLIDE)return "honey-slide";if(s==SoundEvents.HONEY_BLOCK_FALL)return "honey-fall";if(s==SoundEvents.TURTLE_EGG_BREAK)return "egg-break";if(s==SoundEvents.GENERIC_SMALL_FALL)return "small";if(s==SoundEvents.GENERIC_BIG_FALL)return "big";throw new AssertionError(s);}
    static final class Data {
        JsonObject f;PrintWriter out;int calls;BlockState state;Rules rules;Server server;Random random;List<Occupant> occupants;
        boolean flag(String name){return f.get(name).getAsBoolean();}
        void query(String s){out.println(s);if(calls++==f.get("fail").getAsInt())throw new Stop();}
        // 1.19.3: there is no DamageSources provider — landing code
        // passes the DamageSource.FALL / STALAGMITE statics directly,
        // so the trace has no "*-sources"/"*-source" queries on this pin.
        boolean damage(double distance,float multiplier,DamageSource source){query(String.format("damage %016x %08x %s",Double.doubleToLongBits(distance),Float.floatToIntBits(multiplier),source==DamageSource.FALL?"fall":source==DamageSource.STALAGMITE?"stalagmite":"unknown"));return flag("damage");}
        void entitySound(SoundEvent s,float volume,float pitch){query(String.format("entity-sound %s %08x %08x",sound(s),Float.floatToIntBits(volume),Float.floatToIntBits(pitch)));}
        boolean set(BlockPos p,BlockState next,int flags){query("set "+pos(p)+" "+Block.getId(next)+" "+flags);if(flag("write"))state=next;return flag("write");}
        boolean destroy(BlockPos p,boolean drops){query("destroy "+pos(p)+" "+drops);if(flag("write"))state=Blocks.AIR.defaultBlockState();return flag("write");}
        void event(GameEvent event,BlockPos p,Entity source){query("event "+(event==GameEvent.BLOCK_CHANGE?"change":event==GameEvent.BLOCK_DESTROY?"destroy":"unknown")+" "+pos(p)+" "+Block.getId(state)+" "+(source!=null));} // 1.18.2: no GameEvent.Context — the trace prints the tracked state and the source entity flag
        void blockSound(Entity entity,BlockPos p,SoundEvent sound,SoundSource source,float volume,float pitch){if(entity!=null||source!=SoundSource.BLOCKS)throw new AssertionError();query(String.format("block-sound %s %s %08x %08x",pos(p),sound(sound),Float.floatToIntBits(volume),Float.floatToIntBits(pitch)));}
        List<Entity> entities(Entity excluded,AABB bounds){if(excluded!=null)throw new AssertionError();query(bounds("entities",bounds));return new ArrayList<Entity>(occupants);}
    }
    static final class Rules extends GameRules {
        Data d;Rules(){super();}
        // 1.21.10: classic GameRules — typed Key lookups, no GameRule<T>
        // registry objects (those are 1.21.11+). Vanilla landing code
        // reads mob griefing via getBoolean(RULE_MOBGRIEFING).
        @Override public boolean getBoolean(GameRules.Key<GameRules.BooleanValue> rule){if(rule!=GameRules.RULE_MOBGRIEFING)throw new AssertionError();d.query("mob-griefing");return d.flag("griefing");}
    }
    static final class Server extends net.minecraft.server.MinecraftServer {
        @Override public int getMaxPlayers(){throw new UnsupportedOperationException();}
        // 26.1.2 MinecraftServer's constructor takes 10 parameters (Thread,
        // LevelStorageAccess, PackRepository, WorldStem, Optional<GameRules>,
        // Proxy, DataFixer, Services, LevelLoadListener), javap-verified
        // against the 1.21.11 server jar: eight parameters here (26.x
        // passes ten, 26.2 eleven with its NotificationManager).
        Data d;Server(){super(null,null,null,null,null,null,null,null,null,null);} // 1.18.2: MinecraftServer's constructor takes 10 parameters (javap-verified)
        @Override public boolean isUnderSpawnProtection(net.minecraft.server.level.ServerLevel level,BlockPos p,Player player){d.query("protection "+pos(p));return d.flag("protected");}
        @Override public boolean initServer(){throw new UnsupportedOperationException();}
        // 1.21.10: plain int levels, no PermissionSet (1.21.11+).
        @Override public int getOperatorUserPermissionLevel(){throw new UnsupportedOperationException();}
        @Override public boolean isCommandBlockEnabled(){throw new UnsupportedOperationException();}
        @Override public int getFunctionCompilationLevel(){throw new UnsupportedOperationException();}
        @Override public boolean shouldRconBroadcast(){throw new UnsupportedOperationException();}
        @Override public net.minecraft.SystemReport fillServerSystemReport(net.minecraft.SystemReport p0){throw new UnsupportedOperationException();}
        @Override public boolean isDedicatedServer(){throw new UnsupportedOperationException();}
        @Override public int getRateLimitPacketsPerSecond(){throw new UnsupportedOperationException();}
        // No getCommandSpamThresholdSeconds/getChatSpamThresholdSeconds here:
        // 26.2 added both as abstract MinecraftServer methods, but 26.1.2's
        // MinecraftServer declares neither (javap-verified against the full
        // abstract method list of the 26.1.2 server jar), so there is nothing
        // to implement and nothing in 26.1.2 can call them.
        // 1.21.10: isEpollEnabled is the abstract transport query
        // (useNativeTransport is the 1.21.11+ name).
        @Override public boolean isEpollEnabled(){throw new UnsupportedOperationException();}
        @Override public boolean isPublished(){throw new UnsupportedOperationException();}
        @Override public boolean shouldInformAdmins(){throw new UnsupportedOperationException();}
        @Override public boolean isSingleplayerOwner(com.mojang.authlib.GameProfile p0){throw new UnsupportedOperationException();}
    }
    static final class ServerWorld extends net.minecraft.server.level.ServerLevel {
        // 1.18.2: ServerLevel's constructor takes 12 arguments
        // (the ChunkGenerator slot sits before the debug flag).
        Data d;ServerWorld(){super(null,null,null,null,null,null,null,null,false,0L,List.of(),false);}
        @Override public GameRules getGameRules(){d.query("rules");return d.rules;}

        @Override public boolean isClientSide(){d.query("client");return d.flag("client");}
        @Override public Random getRandom(){d.query("random");return d.random;}
        @Override public net.minecraft.server.MinecraftServer getServer(){d.query("server");return d.server;}
        @Override public void playSound(Player e,BlockPos p,SoundEvent s,SoundSource source,float volume,float pitch){d.blockSound(e,p,s,source,volume,pitch);}
        @Override public void broadcastEntityEvent(Entity e,byte event){d.query("broadcast "+event);}
        @Override public boolean setBlock(BlockPos p,BlockState state,int flags){return d.set(p,state,flags);}
        @Override public boolean destroyBlock(BlockPos p,boolean drops){return d.destroy(p,drops);}
        // 1.18.2: the only abstract gameEvent form is
        // (Entity, GameEvent, BlockPos); GameEvent.Context arrives in 1.19.
        @Override public void gameEvent(Entity source,GameEvent e,BlockPos p){d.event(e,p,source);}
        @Override public void levelEvent(int event,BlockPos p,int data){d.query("level-event "+event+" "+pos(p)+" "+data);}
        @Override public List<Entity> getEntities(Entity excluded,AABB bounds){return d.entities(excluded,bounds);}
    }
    static final class ClientWorld extends Level {
        // 1.18.2: Level's constructor takes 7 arguments.
        Data d;ClientWorld(){super(null,null,null,null,false,false,0L);}

        @Override public boolean isClientSide(){d.query("client");return d.flag("client");}
        @Override public Random getRandom(){d.query("random");return d.random;}
        @Override public net.minecraft.server.MinecraftServer getServer(){d.query("server");return d.server;}
        @Override public void playSound(Player e,BlockPos p,SoundEvent s,SoundSource source,float volume,float pitch){d.blockSound(e,p,s,source,volume,pitch);}
        @Override public void broadcastEntityEvent(Entity e,byte event){d.query("broadcast "+event);}
        @Override public boolean setBlock(BlockPos p,BlockState state,int flags){return d.set(p,state,flags);}
        @Override public boolean destroyBlock(BlockPos p,boolean drops){return d.destroy(p,drops);}
        @Override public void gameEvent(Entity source,GameEvent e,BlockPos p){d.event(e,p,source);}
        @Override public void levelEvent(int event,BlockPos p,int data){d.query("level-event "+event+" "+pos(p)+" "+data);}
        @Override public List<Entity> getEntities(Entity excluded,AABB bounds){return d.entities(excluded,bounds);}
@Override public int getFreeMapId(){throw new UnsupportedOperationException();}
@Override public void setMapData(java.lang.String p0,net.minecraft.world.level.saveddata.maps.MapItemSavedData p1){throw new UnsupportedOperationException();}
@Override public void levelEvent(net.minecraft.world.entity.player.Player p0,int p1,net.minecraft.core.BlockPos p2,int p3){throw new UnsupportedOperationException();}
// 1.18.2: no playSeededSound (it arrives later) — Level's abstract
// sound forms are the two playSound overloads.
@Override public void playSound(net.minecraft.world.entity.player.Player p0,double p1,double p2,double p3,net.minecraft.sounds.SoundEvent p4,net.minecraft.sounds.SoundSource p5,float p6,float p7){throw new UnsupportedOperationException();}
@Override public void playSound(net.minecraft.world.entity.player.Player p0,net.minecraft.world.entity.Entity p1,net.minecraft.sounds.SoundEvent p2,net.minecraft.sounds.SoundSource p3,float p4,float p5){throw new UnsupportedOperationException();}
// 1.21.11: Level leaves BlockAndTintGetter.getShade abstract (26.x
// implements it on Level); the clockManager() override is 26.x-only.
@Override public float getShade(net.minecraft.core.Direction direction,boolean shade){return 1.0f;}
@Override public void destroyBlockProgress(int p0,net.minecraft.core.BlockPos p1,int p2){throw new UnsupportedOperationException();}
// 1.21.3: LevelAccessor has no dragonParts() (a later addition).
// 1.19.2: no feature flags at all — LevelAccessor has no
// enabledFeatures() on this pin (the method arrives with
// net.minecraft.world.flag in 1.19.3), so there is nothing to stub.
// 1.21.10: no environment attribute system (1.21.11+); Level has no
// environmentAttributes() here.
// 1.20.2: Level's explode overloads are all concrete (the abstract
// long form with explosion particles and sound is a later arrival),
// so the fake needs no explode override.
@Override public java.lang.String gatherChunkSourceStats(){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.ticks.LevelTickAccess getBlockTicks(){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.level.chunk.ChunkSource getChunkSource(){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.level.entity.LevelEntityGetter getEntities(){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.entity.Entity getEntity(int p0){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.ticks.LevelTickAccess getFluidTicks(){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.level.saveddata.maps.MapItemSavedData getMapData(java.lang.String p0){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.scores.Scoreboard getScoreboard(){throw new UnsupportedOperationException();}
@Override public int getSeaLevel(){throw new UnsupportedOperationException();}
@Override public net.minecraft.core.Holder getUncachedNoiseBiome(int p0,int p1,int p2){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.level.border.WorldBorder getWorldBorder(){throw new UnsupportedOperationException();}
@Override public java.util.List players(){throw new UnsupportedOperationException();}
@Override public net.minecraft.world.item.crafting.RecipeManager getRecipeManager(){throw new UnsupportedOperationException();}
@Override public void sendBlockUpdated(net.minecraft.core.BlockPos p0,net.minecraft.world.level.block.state.BlockState p1,net.minecraft.world.level.block.state.BlockState p2,int p3){throw new UnsupportedOperationException();}
// 1.19.3: LevelReader.registryAccess() is abstract and Level does
// not implement it (the field-backed Level method arrives in 1.19.4).
@Override public net.minecraft.core.RegistryAccess registryAccess(){throw new UnsupportedOperationException();}
// 1.20.2: no TickRateManager (it arrives with /tick in 1.20.3).
    }
    static final class Other extends Marker {
        Data d;Other(){super(null,null);}
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
    }
    static final class Living extends net.minecraft.world.entity.decoration.ArmorStand {
        Data d;Living(){super(null,null);}
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
        @Override public Fallsounds getFallSounds(){d.query("fall-sounds");return new Fallsounds(SoundEvents.GENERIC_SMALL_FALL,SoundEvents.GENERIC_BIG_FALL);}
    }
    static final class Human extends Player {
        Data d;Human(){super(null,null,0f,null);} // 1.18.2: no ProfilePublicKey constructor parameter
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
        @Override public Fallsounds getFallSounds(){d.query("fall-sounds");return new Fallsounds(SoundEvents.GENERIC_SMALL_FALL,SoundEvents.GENERIC_BIG_FALL);}
        @Override public boolean isCreative(){return false;}
        @Override public boolean isSpectator(){return false;}
    }
    static final class Undead extends net.minecraft.world.entity.monster.Zombie {
        Data d;Undead(){super(null,null);}
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
        @Override public Fallsounds getFallSounds(){d.query("fall-sounds");return new Fallsounds(SoundEvents.GENERIC_SMALL_FALL,SoundEvents.GENERIC_BIG_FALL);}
    }
    static final class Reptile extends net.minecraft.world.entity.animal.Turtle {
        Data d;Reptile(){super(null,null);}
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
        @Override public Fallsounds getFallSounds(){d.query("fall-sounds");return new Fallsounds(SoundEvents.GENERIC_SMALL_FALL,SoundEvents.GENERIC_BIG_FALL);}
    }
    static final class Flying extends net.minecraft.world.entity.ambient.Bat {
        Data d;Flying(){super(null,null);}
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
        @Override public Fallsounds getFallSounds(){d.query("fall-sounds");return new Fallsounds(SoundEvents.GENERIC_SMALL_FALL,SoundEvents.GENERIC_BIG_FALL);}
    }
    static final class Item extends net.minecraft.world.entity.item.ItemEntity {
        Data d;Item(){super(null,null);}
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
    }
    static final class Tnt extends net.minecraft.world.entity.item.PrimedTnt {
        Data d;Tnt(){super(null,null);}
        @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source){return d.damage(distance,multiplier,source);}
        @Override public boolean isSuppressingBounce(){d.query("suppress");return d.flag("suppress");}
        @Override public void playSound(SoundEvent s,float volume,float pitch){d.entitySound(s,volume,pitch);}
    }
    static final class Occupant extends Marker {
        Data d;int id;Occupant(){super(null,null);}
        public void teleportRelative(double x,double y,double z){d.query(String.format("teleport %d %016x %016x %016x",id,Double.doubleToLongBits(x),Double.doubleToLongBits(y),Double.doubleToLongBits(z)));setBoundingBox(getBoundingBox().move(x,y,z));if(d.flag("mutate")&&id+1<d.occupants.size()){var next=d.occupants.get(id+1);next.setBoundingBox(next.getBoundingBox().move(0,.125,0));}}
    }
    static void export(Path dir)throws Exception {
        VanillaCollisionOracle.main(new String[]{"generate",dir.toString()});VanillaMovementRegistryOracle.export(dir);
        var definitions=new JsonObject();var metadata=new JsonArray();var sound=BlockBehaviour.class.getDeclaredField("soundType");sound.setAccessible(true);
        var owners=Set.of(Block.class,HayBlock.class,HoneyBlock.class,SlimeBlock.class,PowderSnowBlock.class,PointedDripstoneBlock.class,FarmBlock.class,TurtleEggBlock.class,BedBlock.class);
        // 26.2 has no Block.bounceOn and no shelf mushroom: bouncing is part
        // of fallOn (SlimeBlock/BedBlock), so no block declares a separate
        // bounce entry point and "bounce" is false for every block.
        // BedBlock is in the owner set but is exported as the default
        // family: its fallOn only delegates to Block.fallOn with the fall
        // distance halved (bytecode-measured), and that halving is the
        // fallDistanceReduction coefficient the movement export carries.
        for(var block:Registry.BLOCK){var owner=block.getClass().getMethod("fallOn",Level.class,BlockState.class,BlockPos.class,Entity.class,float.class).getDeclaringClass();if(!owners.contains(owner))throw new AssertionError(owner);var entry=new JsonObject();entry.addProperty("fall",owner==BedBlock.class?"Block":owner==FarmBlock.class?"FarmlandBlock":owner.getSimpleName());entry.addProperty("bounce",false);if(owner==FarmBlock.class)entry.addProperty("base",Registry.BLOCK.getKey(net.minecraft.world.level.block.Blocks.DIRT).toString());if(owner==HoneyBlock.class){var type=(SoundType)sound.get(block);entry.addProperty("volume",String.format("%08x",Float.floatToIntBits(type.getVolume())));entry.addProperty("pitch",String.format("%08x",Float.floatToIntBits(type.getPitch())));if(type.getFallSound()!=SoundEvents.HONEY_BLOCK_FALL)throw new AssertionError();}definitions.add(Registry.BLOCK.getKey(block).toString(),entry);}
        for(var state:Block.BLOCK_STATE_REGISTRY){var row=new JsonObject();row.addProperty("id",Block.getId(state));row.addProperty("name",Registry.BLOCK.getKey(state.getBlock()).toString());metadata.add(row);}
        Files.writeString(dir.resolve("landing-definitions.json"),definitions.toString());Files.writeString(dir.resolve("landing-states.json"),metadata.toString());
    }
    public static void main(String[] args)throws Exception {
        net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();Path dir=Path.of(args[1]);if(args[0].equals("export")){export(dir);return;}
        var allocator=Class.forName("sun.misc.Unsafe");var field=allocator.getDeclaredField("theUnsafe");field.setAccessible(true);unsafe=field.get(null);allocate=allocator.getMethod("allocateInstance",Class.class);var dimensions=Entity.class.getDeclaredField("dimensions");dimensions.setAccessible(true);
        var kinds=new Class<?>[]{Other.class,Living.class,Human.class,Undead.class,Reptile.class,Flying.class,Item.class,Tnt.class};
        try(var out=new PrintWriter(Files.newBufferedWriter(dir.resolve(args[0]+".txt")));var lines=Files.lines(dir.resolve("inputs.txt"))){for(var line:(Iterable<String>)lines::iterator){
            var f=JsonParser.parseString(line).getAsJsonObject();var d=new Data();d.f=f;d.out=out;d.state=Block.stateById(f.get("state").getAsInt());d.rules=make(Rules.class);d.rules.d=d;d.server=make(Server.class);d.server.d=d;
            d.random=new Random(){@Override public float nextFloat(){d.query("float");return single(f.get("random_float"));}@Override public int nextInt(int bound){d.query("int "+bound);return f.get("random_int").getAsInt();}}; // 1.18.2: getRandom() returns java.util.Random, so an anonymous subclass replaces the RandomSource proxy
            Level world;if(d.flag("server")){var w=make(ServerWorld.class);w.d=d;world=w;}else{var w=make(ClientWorld.class);w.d=d;world=w;}
            var kind=kinds[f.get("kind").getAsInt()];var entity=(Entity)make(kind);var dataField=kind.getDeclaredField("d");dataField.set(entity,d);dimensions.set(entity,EntityDimensions.scalable(single(f.get("width")),single(f.get("height"))));d.occupants=new ArrayList<>();for(var box:f.getAsJsonArray("entities")){var e=make(Occupant.class);e.d=d;e.id=d.occupants.size();e.setBoundingBox(box(box));d.occupants.add(e);}
            var p=f.getAsJsonArray("position");var position=new BlockPos(p.get(0).getAsInt(),p.get(1).getAsInt(),p.get(2).getAsInt());var state=d.state;
            // 26.2 has no bounceOn entry point: a landing (bouncy or not) is
            // always Block.fallOn, so the "bounce" input flag selects the
            // same native call; fallOn itself performs any bounce.
            try{state.getBlock().fallOn(world,state,position,entity,(float)number(f.get("distance")));out.println("ok");}catch(Stop e){out.println("error");}
            out.println("state "+Block.getId(d.state));for(var e:d.occupants)out.println(bounds("final "+e.id,e.getBoundingBox()));out.println("queries "+d.calls);
        }}
    }
}
