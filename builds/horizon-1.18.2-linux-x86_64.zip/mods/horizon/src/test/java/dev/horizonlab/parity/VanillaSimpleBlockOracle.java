package dev.horizonlab.parity;
import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import net.minecraft.core.*;
import net.minecraft.resources.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.feature.SimpleBlockFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;
import net.minecraft.world.level.levelgen.placement.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;

/** Actual native simple-block map codec and mutable world placement. */
public final class VanillaSimpleBlockOracle {
 private static final class Stop extends RuntimeException {}
 private static final List<ThreadLocal<?>> fixtureCaches=new ArrayList<>();
 private static Biome trackBiome(Biome biome)throws ReflectiveOperationException{
  var field=Biome.class.getDeclaredField("temperatureCache");field.setAccessible(true);fixtureCaches.add((ThreadLocal<?>)field.get(biome));return biome;
 }
 private interface Placeable {
  boolean place(WorldGenLevel world,ChunkGenerator generator,Random random,BlockPos p);
 }
 @SuppressWarnings("unchecked")
 // 1.19.2: RegistryOps.create(DynamicOps, RegistryAccess) is the only
 // RegistryOps factory on this pin (RegistryInfo/RegistryInfoLookup
 // arrive in 1.20.2/1.20.3), and Registry implements HolderGetter
 // directly. Decoding registry references is delegated to a
 // RegistryAccess view over the registries the harness builds.
 private static Optional<Placeable> decode(RegistryOps<JsonElement> ops,JsonObject f) {
  var json=JsonParser.parseString(f.get("definition").getAsString());
  String mode=f.has("mode")?f.get("mode").getAsString():"map";
  if(mode.equals("weather")){
   final Biome biome=makeBiome(f);
   // 26.2 Feature<FC> is abstract over place(FeaturePlaceContext) and
   // takes its configuration codec in the constructor; a
   // configuration-less feature uses NoneFeatureConfiguration.
   var feature=new Feature<NoneFeatureConfiguration>(NoneFeatureConfiguration.CODEC){
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context){return f.get("operation").getAsString().equals("snow")?biome.shouldSnow(context.level(),context.origin()):biome.shouldFreeze(context.level(),context.origin(),f.get("edge").getAsBoolean());}
   };
   return Optional.of((world,generator,random,p)->feature.place(NoneFeatureConfiguration.INSTANCE,world,generator,random,p));
  }
  // 26.2 keeps configuration separate from the feature type: a
  // simple-block definition is a SimpleBlockConfiguration, placed through
  // the vanilla Feature.SIMPLE_BLOCK instance.
  if(mode.equals("map"))return SimpleBlockConfiguration.CODEC.parse(ops,json).result().map(config->(Placeable)(world,generator,random,p)->Feature.SIMPLE_BLOCK.place(config,world,generator,random,p));
  if(mode.equals("feature"))return ConfiguredFeature.DIRECT_CODEC.parse(ops,json).result().map(cf->(Placeable)(world,generator,random,p)->cf.place(world,generator,random,p));
  return PlacedFeature.DIRECT_CODEC.parse(ops,json).result().map(pf->(Placeable)(world,generator,random,p)->pf.place(world,generator,random,p));
 }
 private static Biome makeBiome(JsonObject f){
   try{
    var type=Class.forName("net.minecraft.world.level.biome.Biome$ClimateSettings");
    var climate=type.getDeclaredConstructor(Biome.Precipitation.class,float.class,Biome.TemperatureModifier.class,float.class);climate.setAccessible(true);
    var settings=climate.newInstance(f.get("precipitation").getAsBoolean()?Biome.Precipitation.RAIN:Biome.Precipitation.NONE,Float.intBitsToFloat(Integer.parseUnsignedInt(f.get("base").getAsString(),16)),Biome.TemperatureModifier.valueOf(f.get("modifier").getAsString()),0f);
    var constructor=Biome.class.getDeclaredConstructors()[0];constructor.setAccessible(true);return trackBiome((Biome)constructor.newInstance(settings,null,null,null));
   }catch(ReflectiveOperationException error){throw new IllegalStateException(error);}
 }
 private static BlockPos pos(JsonArray a){return new BlockPos(a.get(0).getAsInt(),a.get(1).getAsInt(),a.get(2).getAsInt());}
 private static String xyz(BlockPos p){return p.getX()+" "+p.getY()+" "+p.getZ();}
 private static final class Chunks {
  static final net.minecraft.core.Registry<net.minecraft.world.level.biome.Biome> FACTORY;
  static {
   FACTORY=biomeRegistry();
  }
  // 1.21.8 has no PalettedContainerFactory (the 1.21.9 palette refactor):
  // ProtoChunk takes the biome registry and fills its sections from it
  // (ChunkAccess.replaceMissingSections -> LevelChunkSection(registry),
  // whose biome container needs registry.getOrThrow(Biomes.PLAINS)). A
  // one-entry MappedRegistry over a reflectively built Biome is enough.
  private static net.minecraft.core.Registry<net.minecraft.world.level.biome.Biome> biomeRegistry() {
   try {
    var climateCtor=Class.forName("net.minecraft.world.level.biome.Biome$ClimateSettings").getDeclaredConstructors()[0];climateCtor.setAccessible(true);
    var climate=climateCtor.newInstance(net.minecraft.world.level.biome.Biome.Precipitation.NONE,0.8f,net.minecraft.world.level.biome.Biome.TemperatureModifier.NONE,0.5f);
    var ctor=net.minecraft.world.level.biome.Biome.class.getDeclaredConstructors()[0];ctor.setAccessible(true);
    var biome=(net.minecraft.world.level.biome.Biome)ctor.newInstance(climate,null,null,null);
    net.minecraft.core.MappedRegistry<net.minecraft.world.level.biome.Biome> registry=new MappedRegistry<net.minecraft.world.level.biome.Biome>(Registry.BIOME_REGISTRY,com.mojang.serialization.Lifecycle.stable(),v->null); // 1.19.2: standalone holders need (registry, key); the harness registries are codec-only, so no reference factory is installed
    Registry.register(registry,"minecraft:plains",biome);
    registry.freeze();
    return registry;
   } catch(ReflectiveOperationException e) { throw new IllegalStateException(e); }
  }
 }
 private static final class World implements InvocationHandler {
  final JsonObject f;final PrintWriter out;final Random random;final Holder<Biome> biome;int calls;
  final TreeMap<BlockPos,BlockState> states=new TreeMap<>(Comparator.<BlockPos>comparingInt(BlockPos::getX).thenComparingInt(BlockPos::getY).thenComparingInt(BlockPos::getZ));
  World(JsonObject f,PrintWriter out,Random random){this.f=f;this.out=out;this.random=random;this.biome=f.has("biome")?Holder.direct(makeBiome(f.getAsJsonObject("biome"))):null;for(var raw:f.getAsJsonArray("states")){var v=raw.getAsJsonArray();states.put(pos(v),Block.stateById(v.get(3).getAsInt()));}}
  final TreeMap<BlockPos,ChestBlockEntity> lootContainers=new TreeMap<>(Comparator.<BlockPos>comparingInt(BlockPos::getX).thenComparingInt(BlockPos::getY).thenComparingInt(BlockPos::getZ));
  final TreeMap<BlockPos,TheEndGatewayBlockEntity> gateways=new TreeMap<>(Comparator.<BlockPos>comparingInt(BlockPos::getX).thenComparingInt(BlockPos::getY).thenComparingInt(BlockPos::getZ));
  final Map<ChunkPos,ProtoChunk> chunks=new HashMap<>();
  ProtoChunk chunk(BlockPos p) {
   event("chunk "+xyz(p));var key=new ChunkPos(p.getX()>>4,p.getZ()>>4);
   return chunks.computeIfAbsent(key,cp->new ProtoChunk(cp,UpgradeData.EMPTY,LevelHeightAccessor.create(-64,384),Chunks.FACTORY,null){
    // 26.1.2 spells this markPosForPostprocessing (ChunkAccess/ProtoChunk,
    // javap-verified in the 26.1.2 server jar); 26.2 respelled it
    // markPosForPostProcessing.
    @Override public void markPosForPostprocessing(BlockPos position){event("post "+xyz(position));super.markPosForPostprocessing(position);}
   });
  }
  void event(String text){out.println(text);if(calls++==f.get("fail").getAsInt())throw new Stop();}
  BlockState at(BlockPos p){return states.getOrDefault(p,f.has("air_above")&&p.getY()>f.get("air_above").getAsInt()?Blocks.AIR.defaultBlockState():Block.stateById(f.get("fallback").getAsInt()));}
  public Object invoke(Object proxy,Method method,Object[] args)throws Throwable {
   String name=method.getName();
   if(name.equals("getBiome")){event("biome "+xyz((BlockPos)args[0]));if(biome==null)throw new IllegalStateException("missing fixture biome");return biome;}
   if(name.equals("getRandom"))return random;
   if(name.equals("isStateAtPosition")){var p=(BlockPos)args[0];event("get "+xyz(p));var state=at(p);out.println("state "+Block.getId(state));return ((java.util.function.Predicate<BlockState>)args[1]).test(state);}
   if(name.equals("getChunk")&&args.length==1&&args[0] instanceof BlockPos)return chunk((BlockPos)args[0]);
   if(name.equals("getMinY"))return -64;
   if(name.equals("getHeight")&&(args==null||args.length==0))return 384;
   if(name.equals("getHeight")&&args.length==3){event("height "+args[0]+" "+args[1]+" "+args[2]);return f.has("height")?f.get("height").getAsInt():64;}
   if(name.equals("getSeaLevel"))return f.has("sea")?f.get("sea").getAsInt():63;
   if(name.equals("getBlockState")){var p=(BlockPos)args[0];event("get "+xyz(p));var state=at(p);out.println("state "+Block.getId(state));return state;}
   if(name.equals("getFluidState")){var p=(BlockPos)args[0];event("fluid "+xyz(p));return (f.has("fluid")?Block.stateById(f.get("fluid").getAsInt()):at(p)).getFluidState();}
   if(name.equals("getBrightness")&&args[0]==LightLayer.BLOCK){event("blocklight "+xyz((BlockPos)args[1]));return f.get("brightness").getAsInt();}
   if(name.equals("getRawBrightness")){var p=(BlockPos)args[0];event("light "+xyz(p)+" "+args[1]);return f.get("brightness").getAsInt();}
   if(name.equals("getBlockEntity")){
    var p=((BlockPos)args[0]).immutable();event("entity "+xyz(p));String mode=f.has("gateway_entity")?f.get("gateway_entity").getAsString():"none";
    if(f.has("loot_entity")){
     String lootMode=f.get("loot_entity").getAsString();
     if(lootMode.equals("chest"))return lootContainers.computeIfAbsent(p,key->new ChestBlockEntity(key,Blocks.CHEST.defaultBlockState()));
     if(lootMode.equals("other"))return new TheEndGatewayBlockEntity(p,Blocks.END_GATEWAY.defaultBlockState());
     return null;
    }
    if(mode.equals("other"))return new ShulkerBoxBlockEntity(p,Blocks.SHULKER_BOX.defaultBlockState());
    if(mode.equals("gateway"))return gateways.computeIfAbsent(p,key->new TheEndGatewayBlockEntity(key,Blocks.END_GATEWAY.defaultBlockState()){@Override public void setChanged(){event("gateway_changed "+xyz(key));}});
    return null;
   }
   if(name.equals("destroyBlock")){
    if(args.length!=3||args[2]!=null)throw new UnsupportedOperationException("only no-entity destruction is defined in this fixture");
    var p=((BlockPos)args[0]).immutable();event("destroy "+xyz(p)+" "+args[1]);boolean result=!f.has("destroy_success")||f.get("destroy_success").getAsBoolean();
    if(result)states.put(p,Blocks.AIR.defaultBlockState());out.println("destroyed "+result);return result;
   }
   if(name.equals("setBlock")){
    var p=((BlockPos)args[0]).immutable();var state=(BlockState)args[1];int call=calls;event("set "+xyz(p)+" "+Block.getId(state)+" "+args[2]);
    int reject=f.get("reject").getAsInt();boolean result=reject==0||call%reject!=0;if(result)states.put(p,state);out.println("written "+result);return result;
   }
   if(name.equals("scheduleTick")&&args[1] instanceof net.minecraft.world.level.material.Fluid fluid){event("fluidtick "+xyz((BlockPos)args[0])+" "+Registry.FLUID.getKey(fluid)+" "+args[2]);return null;}
   if(name.equals("scheduleTick")){event("tick "+xyz((BlockPos)args[0])+" "+Block.getId(((Block)args[1]).defaultBlockState())+" "+args[2]);return null;}
   if(method.isDefault())return InvocationHandler.invokeDefault(proxy,method,args);
   throw new AssertionError(method);
  }
 }
 @SuppressWarnings("unchecked")
 public static void main(String[] args)throws Exception {
  net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();Path dir=Path.of(args[1]);
  if(args[0].equals("export")) {
   VanillaBlockSurvivalOracle.main(args);
   var data=new JsonObject();var doubles=new JsonArray();var moss=new JsonArray();
   for(var block:Registry.BLOCK){String name=Registry.BLOCK.getKey(block).toString();if(block instanceof DoublePlantBlock)doubles.add(name);if(false)moss.add(name);} // MossyCarpetBlock arrives in 1.21.4; no mossy carpets exist in 1.21
   data.add("double_plants",doubles);data.add("mossy_carpets",moss);Files.writeString(dir.resolve("placement-definitions.json"),data.toString());return;
  }
  VanillaHeightmapOracle.bindTags(JsonParser.parseString(Files.readString(dir.resolve("tags.json"))).getAsJsonObject());
  var bind=VanillaBlockSurvivalOracle.class.getDeclaredMethod("bindFluidTags",JsonObject.class);bind.setAccessible(true);bind.invoke(null,JsonParser.parseString(Files.readString(dir.resolve("fluid-tags.json"))).getAsJsonObject());
  // block_state_provider is not a real registry on this era either
  // (providers are inline in feature JSON); the catalog registry keeps
  // a local key of the same name so definitions can still be collected
  // under it. Configured/placed features live in the era registries
  // Registry.CONFIGURED_FEATURE_REGISTRY / PLACED_FEATURE_REGISTRY.
  ResourceKey<Registry<BlockStateProvider>> providerKey=ResourceKey.createRegistryKey(new ResourceLocation("minecraft","block_state_provider"));
  var providers=new MappedRegistry<BlockStateProvider>(providerKey,com.mojang.serialization.Lifecycle.stable(),v->null); // 1.19.2: standalone holders need (registry, key); the harness registries are codec-only, so no reference factory is installed
  var features=new MappedRegistry<ConfiguredFeature<?,?>>(Registry.CONFIGURED_FEATURE_REGISTRY,com.mojang.serialization.Lifecycle.stable(),v->null); // 1.19.2: standalone holders need (registry, key); the harness registries are codec-only, so no reference factory is installed
  var placed=new MappedRegistry<PlacedFeature>(Registry.PLACED_FEATURE_REGISTRY,com.mojang.serialization.Lifecycle.stable(),v->null); // 1.19.2: standalone holders need (registry, key); the harness registries are codec-only, so no reference factory is installed
  // 1.19.2: RegistryOps.create takes (DynamicOps, RegistryAccess);
  // the era-harmonized registries are exposed through a Frozen proxy
  // whose registry()/ownedRegistry() answer from the harness maps.
  @SuppressWarnings("unchecked") final class Harness {
   static RegistryAccess.Frozen access(Map<ResourceKey<?>,Registry<?>> byKey){
    return (RegistryAccess.Frozen)Proxy.newProxyInstance(VanillaSimpleBlockOracle.class.getClassLoader(),new Class<?>[]{RegistryAccess.Frozen.class},(proxy,method,args)->{
     if(method.getName().equals("registry")||method.getName().equals("ownedRegistry"))return Optional.ofNullable(byKey.get(args[0]));
     if(method.getName().equals("registries"))return byKey.entrySet().stream().map(e->new RegistryAccess.RegistryEntry(e.getKey(),(Registry)e.getValue()));
     if(method.getName().equals("freeze"))return proxy;
     if(method.isDefault())return InvocationHandler.invokeDefault(proxy,method,args);
     throw new AssertionError(method);
    });
   }
  }
  var byKey=new HashMap<ResourceKey<?>,Registry<?>>();
  byKey.put(Registry.CONFIGURED_FEATURE_REGISTRY,features);byKey.put(Registry.PLACED_FEATURE_REGISTRY,placed);byKey.put(providerKey,providers);byKey.put(Registry.FLUID_REGISTRY,Registry.FLUID);byKey.put(Registry.BLOCK_REGISTRY,Registry.BLOCK);
  var ops=RegistryOps.create(JsonOps.INSTANCE,Harness.access(byKey));
  for(var entry:JsonParser.parseString(Files.readString(dir.resolve("catalog.json"))).getAsJsonObject().entrySet()) {
   var provider=BlockStateProvider.CODEC.parse(ops,JsonParser.parseString(entry.getValue().getAsString())).getOrThrow(false, __err -> { throw new IllegalStateException(__err); });
   providers.register(ResourceKey.create(providerKey,ResourceLocation.tryParse(entry.getKey())),provider,com.mojang.serialization.Lifecycle.stable());
  }providers.freeze();
  var bundle=JsonParser.parseString(Files.readString(dir.resolve("feature-catalog.json"))).getAsJsonObject();
  for(var entry:bundle.getAsJsonObject("features").entrySet())features.register(ResourceKey.create(Registry.CONFIGURED_FEATURE_REGISTRY,ResourceLocation.tryParse(entry.getKey())),ConfiguredFeature.DIRECT_CODEC.parse(ops,JsonParser.parseString(entry.getValue().getAsString())).getOrThrow(false, __err -> { throw new IllegalStateException(__err); }),com.mojang.serialization.Lifecycle.stable());
  features.freeze();
  for(var entry:bundle.getAsJsonObject("placed").entrySet())placed.register(ResourceKey.create(Registry.PLACED_FEATURE_REGISTRY,ResourceLocation.tryParse(entry.getKey())),PlacedFeature.DIRECT_CODEC.parse(ops,JsonParser.parseString(entry.getValue().getAsString())).getOrThrow(false, __err -> { throw new IllegalStateException(__err); }),com.mojang.serialization.Lifecycle.stable());
  placed.freeze();
  var contextMethod=VanillaPlacementOracle.class.getDeclaredMethod("context",JsonObject.class);contextMethod.setAccessible(true);
  var bounds=new JsonObject();bounds.add("context",JsonParser.parseString("[-64,384,63]"));
  var generator=((PlacementContext)contextMethod.invoke(null,bounds)).generator();
  try(var out=new PrintWriter(Files.newBufferedWriter(dir.resolve(args[0]+".txt")));var inputs=Files.lines(dir.resolve("inputs.txt"))) {
   for(var line:(Iterable<String>)inputs::iterator){var f=JsonParser.parseString(line).getAsJsonObject();long seed=f.get("seed").getAsLong(),worldSeed=f.get("world_seed").getAsLong();boolean legacy=f.get("legacy").getAsBoolean();
    Random random=new Random(seed),worldRandom=new Random(worldSeed); // 1.18.2: worldgen randoms are plain java.util.Random (the RandomSource split arrives in 1.19)
    Optional<Placeable> decoded;
    try{decoded=decode(ops,f);}catch(IllegalArgumentException|IllegalStateException error){decoded=Optional.empty();}
    if(decoded.isEmpty())out.println("decode error");else {
     out.println("decode ok");var handler=new World(f,out,worldRandom);var world=(WorldGenLevel)Proxy.newProxyInstance(WorldGenLevel.class.getClassLoader(),new Class<?>[]{WorldGenLevel.class},handler);var origin=pos(f.getAsJsonArray("origin"));
     for(int repeat=0;repeat<f.get("repeats").getAsInt();repeat++){
      handler.calls=0;try{out.println("place "+decoded.get().place(world,generator,random,origin));}catch(Stop|IllegalArgumentException error){out.println("place error");}
      out.println("next "+random.nextLong()+" "+worldRandom.nextLong());out.println("calls "+handler.calls);
      for(var entry:handler.states.entrySet())out.println("stored "+xyz(entry.getKey())+" "+Block.getId(entry.getValue()));
      for(var entry:handler.lootContainers.entrySet()) {
       // 1.20.2: no getLootTable()/getLootTableSeed() (the getters come
       // with the 1.20.3 RandomizableContainer interface); the state is
       // the protected fields on RandomizableContainerBlockEntity.
       var ltF=net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity.class.getDeclaredField("lootTable");ltF.setAccessible(true);var lsF=net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity.class.getDeclaredField("lootTableSeed");lsF.setAccessible(true);
       var lt=ltF.get(entry.getValue());if(lt!=null)out.println("loot "+xyz(entry.getKey())+" "+lt+" "+lsF.getLong(entry.getValue()));
      }
      for(var entry:handler.gateways.entrySet()) {
       var exit=TheEndGatewayBlockEntity.class.getDeclaredField("exitPortal");exit.setAccessible(true);var exact=TheEndGatewayBlockEntity.class.getDeclaredField("exactTeleport");exact.setAccessible(true);
       out.println("gateway "+xyz(entry.getKey())+" "+xyz((BlockPos)exit.get(entry.getValue()))+" "+exact.getBoolean(entry.getValue()));
      }
      out.println("end");
     }
    }out.println("tail "+random.nextLong()+" "+worldRandom.nextLong());
    for(var cache:fixtureCaches)cache.remove();fixtureCaches.clear();
   }
  }
 }
}
