#!/usr/bin/env python3
"""quikconvert - Horizon mod converter v1.

Python 3 stdlib only. Static / safe only: jars are treated as zips of
data. Code from a mod jar is NEVER executed, extracted-and-run, or loaded.

Usage:
    python3 quikconvert.py <input.zip | folder> <outdir> [--horizon-revision <sha>]
    python3 quikconvert.py --list-curseforge
    python3 quikconvert.py --browse-curseforge <mc-version> [--search <text>]
    python3 quikconvert.py --cf-get <N> <outdir>

A CurseForge pack is accepted directly: an installed instance folder
(minecraftinstance.json + mods/) or an exported pack .zip (manifest.json).
Pack imports write pack-import.json / pack-import.md alongside the
coverage outputs; --install-into DIR also copies the converted content
mods into DIR (Horizon's horizon-mods folder).

Input is either:
  * a .zip file containing one or more .jar / .litemod files (nested .zip
    mod batches are expanded recursively), or
  * a folder containing .jar / .litemod files (searched recursively), or
  * a single .jar / .litemod file (treated as a one-mod batch), or
  * a standalone pack: a folder or .zip that is itself a datapack /
    resource pack / KubeJS pack (pack.mcmeta, a kubejs/ script tree, or
    root-level assets/ + data/), converted as one pack source.
  Loose files inside a batch .zip/folder that together form such a pack
  tree (a kubejs/ subtree, or pack.mcmeta + data//assets/ at a subtree
  root) are grouped and converted as one pack source too; single stray
  files keep an explicit per-file out-of-scope entry.

Every artefact in the input is accounted in coverage: it either becomes a
source or gets an explicit out-of-scope entry — nothing is silently dropped.
Jars that are server plugins (Bukkit/Spigot plugin.yml, BungeeCord
bungee.yml) are not mods: they get an explicit "out-of-scope" verdict.

Outputs (under <outdir>):
  horizon/mods/<modid>/     data-carried content + horizon-mod.toml
  horizon/native/<modid>/   .hnmod-ready entity scaffold (when entity hints)
  rewrite-queue.json
  coverage.json / coverage.md   (every jar file accounted exactly once)

Note: Bedrock pack output was removed 2026-10-31 (Bedrock is out of scope
for this fork); output is Horizon-only.
"""
import argparse
import io
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile

try:
    import tomllib  # stdlib in Python 3.11+
except Exception:  # pragma: no cover - older interpreters
    tomllib = None

DEFAULT_REVISION = "65b312814bfce5eed005db23a7b21a2adc51154e"
BOM = b"\xef\xbb\xbf"

# Bundled native libraries: platform binaries, including versioned
# shared objects (libfoo.so.1, libfoo.so.1.2).
_NATIVE_LIB_RE = re.compile(r"\.(?:so(?:\.\d+)*|dylib|dll)$")


# ---------------------------------------------------------------- helpers

def sanitize_modid(raw):
    """Sanitize to [a-z0-9_]{1,64}. Returns (sanitized, was_sanitized)."""
    if raw is None:
        raw = ""
    raw_str = str(raw)
    s = raw_str.lower().replace("-", "_")
    s = re.sub(r"[^a-z0-9_]", "", s)
    s = s[:64]
    if not s:
        s = "unknown_mod"
    return s, (s != raw_str)


def toml_escape(value):
    return str(value).replace("\\", "\\\\").replace('"', '\\"')


def fmt_float(value):
    """Format as a Rust f32 literal (always carries a decimal point)."""
    s = "%.4g" % float(value)
    if "." not in s and "e" not in s and "E" not in s and s.lstrip("-") not in ("inf", "nan"):
        s += ".0"
    return s


def parse_toml_bytes(data):
    """Parse TOML bytes via tomllib if available; else return {}."""
    if tomllib is None:
        return {}
    try:
        return tomllib.loads(data.decode("utf-8", errors="replace"))
    except Exception:
        return {}


def regex_toml_field(text, field):
    m = re.search(r'(?m)^\s*' + re.escape(field) + r'\s*=\s*"([^"]*)"', text)
    if m:
        return m.group(1)
    m = re.search(r"(?m)^\s*" + re.escape(field) + r"\s*=\s*'([^']*)'", text)
    if m:
        return m.group(1)
    return None


def parse_manifest(zf, names_set):
    """Parse the main section of META-INF/MANIFEST.MF into
    {lowercased key: value}. Continuation lines (starting with a single
    space) are unfolded. Returns {} when there is no manifest."""
    if "META-INF/MANIFEST.MF" not in names_set:
        return {}
    try:
        text = zf.read("META-INF/MANIFEST.MF").decode("utf-8", errors="replace")
    except Exception:
        return {}
    attrs = {}
    key = None
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if line.startswith(" ") and key is not None:
            attrs[key] += line[1:]
        elif not line.strip():
            break  # blank line ends the main section
        elif ": " in line:
            k, _, v = line.partition(": ")
            key = k.strip().lower()
            attrs[key] = v.strip()
        else:
            key = None
    return attrs


def _mixin_refs_from(value):
    """Normalise a loader "mixins" value (str | {config: ...} | list of
    either) into a list of config path strings."""
    refs = []
    if isinstance(value, (str, dict)):
        value = [value]
    if isinstance(value, list):
        for item in value:
            if isinstance(item, str):
                refs.append(item)
            elif isinstance(item, dict) and "config" in item:
                refs.append(str(item["config"]))
    return refs


def extract_metadata(zf, names_set):
    """Return dict(id_raw, name, version, loader, loaders, mod_ids,
    mixins_refs, side, access_widener, manifest).

    Every loader metadata format present is parsed: fabric.mod.json,
    quilt.mod.json, neoforge/forge mods.toml, legacy mcmod.info and
    litemod.json, plus MANIFEST.MF attributes (MixinConfigs, FMLCorePlugin).
    The first format to provide a field wins; later formats only fill gaps.
    "loader" is the primary (first-found) loader; "loaders" names every
    loader found, so a jar shipping several formats is reported honestly."""
    meta = {
        "id_raw": None,
        "name": None,
        "version": None,
        "loader": "unknown",
        "loaders": [],
        "mod_ids": [],
        "mixins_refs": [],
        "side": "both",
        "access_widener": None,
        "manifest": {},
    }
    manifest = parse_manifest(zf, names_set)
    meta["manifest"] = manifest

    def note_loader(name):
        if name not in meta["loaders"]:
            meta["loaders"].append(name)
        if meta["loader"] == "unknown":
            meta["loader"] = name

    def add_mixin_refs(refs):
        for ref in refs:
            if ref not in meta["mixins_refs"]:
                meta["mixins_refs"].append(ref)

    # --- fabric.mod.json ---
    if "fabric.mod.json" in names_set:
        try:
            doc = json.loads(zf.read("fabric.mod.json").decode("utf-8-sig", errors="replace"))
            if isinstance(doc, dict):
                note_loader("fabric")
                meta["id_raw"] = doc.get("id")
                meta["name"] = doc.get("name")
                meta["version"] = doc.get("version")
                env = doc.get("environment")
                if env == "client":
                    meta["side"] = "client"
                elif env == "server":
                    meta["side"] = "server"
                add_mixin_refs(_mixin_refs_from(doc.get("mixins")))
                aw = doc.get("accessWidener")
                if meta["access_widener"] is None and isinstance(aw, str):
                    meta["access_widener"] = aw
        except Exception:
            pass
    # --- quilt.mod.json ---
    if "quilt.mod.json" in names_set:
        try:
            doc = json.loads(zf.read("quilt.mod.json").decode("utf-8-sig", errors="replace"))
            if isinstance(doc, dict):
                note_loader("quilt")
                ql = doc.get("quilt_loader") if isinstance(doc.get("quilt_loader"), dict) else {}
                if meta["id_raw"] is None:
                    meta["id_raw"] = ql.get("id")
                if meta["name"] is None:
                    qmd = ql.get("metadata") if isinstance(ql.get("metadata"), dict) else {}
                    meta["name"] = qmd.get("name")
                if meta["version"] is None:
                    meta["version"] = ql.get("version")
                # Quilt declares its configs under the top-level "mixin" key.
                add_mixin_refs(_mixin_refs_from(doc.get("mixin")))
                aw = ql.get("access_widener") or doc.get("accessWidener") or doc.get("access_widener")
                if meta["access_widener"] is None and isinstance(aw, str):
                    meta["access_widener"] = aw
        except Exception:
            pass
    # --- neoforge / forge mods.toml ---
    toml_path = None
    loader_name = None
    if "META-INF/neoforge.mods.toml" in names_set:
        toml_path = "META-INF/neoforge.mods.toml"
        loader_name = "neoforge"
    elif "META-INF/mods.toml" in names_set:
        toml_path = "META-INF/mods.toml"
        loader_name = "forge"
    elif "mods.toml" in names_set:
        toml_path = "mods.toml"
        loader_name = "forge"
    if toml_path is not None:
        try:
            raw = zf.read(toml_path)
            text = raw.decode("utf-8", errors="replace")
            parsed = parse_toml_bytes(raw)
            mod_entry = {}
            toml_mixin_refs = []
            if isinstance(parsed, dict):
                mods_list = parsed.get("mods")
                if isinstance(mods_list, list):
                    # A jar may declare several mods ([[mods]] x N): record
                    # every id; the jar still converts once, under the first.
                    for m in mods_list:
                        if isinstance(m, dict) and m.get("modId"):
                            meta["mod_ids"].append(str(m["modId"]))
                    if mods_list and isinstance(mods_list[0], dict):
                        mod_entry = mods_list[0]
                # FML declares mixin configs as [[mixins]] config = "..."
                mix_list = parsed.get("mixins")
                if isinstance(mix_list, list):
                    for m in mix_list:
                        if isinstance(m, dict) and m.get("config"):
                            toml_mixin_refs.append(str(m["config"]))
            add_mixin_refs(toml_mixin_refs)
            if not meta["mod_ids"]:
                # tomllib unavailable/failed: regex fallback (may also catch
                # [[dependencies]] modIds — degraded mode only).
                meta["mod_ids"] = re.findall(r'(?m)^\s*modId\s*=\s*"([^"]+)"', text)
            if not toml_mixin_refs:
                for section in re.split(r"\[\[mixins\]\]", text)[1:]:
                    body = re.split(r"\[\[", section, maxsplit=1)[0]
                    cfg = regex_toml_field(body, "config")
                    if cfg:
                        add_mixin_refs([cfg])
            if meta["id_raw"] is None:
                meta["id_raw"] = mod_entry.get("modId") or regex_toml_field(text, "modId")
            if meta["name"] is None:
                meta["name"] = mod_entry.get("displayName") or regex_toml_field(text, "displayName")
            if meta["version"] is None:
                v = mod_entry.get("version") or regex_toml_field(text, "version")
                # version may be a placeholder like "${file.jarVersion}" —
                # left unset here; the MANIFEST.MF fallback below resolves it.
                if v and not str(v).startswith("${"):
                    meta["version"] = v
            note_loader(loader_name)
            side_val = mod_entry.get("side")
            if isinstance(side_val, str) and side_val.lower() in ("client", "server", "both"):
                meta["side"] = side_val.lower()
        except Exception:
            pass
    # --- legacy Forge: mcmod.info (pre-1.13) ---
    if "mcmod.info" in names_set:
        try:
            doc = json.loads(zf.read("mcmod.info").decode("utf-8-sig", errors="replace"))
            entries = None
            if isinstance(doc, list):
                entries = doc
            elif isinstance(doc, dict) and isinstance(doc.get("modList"), list):
                entries = doc["modList"]
            if entries and isinstance(entries[0], dict):
                note_loader("forge-legacy")
                e = entries[0]
                if meta["id_raw"] is None:
                    meta["id_raw"] = e.get("modid")
                if meta["name"] is None:
                    meta["name"] = e.get("name")
                v = e.get("version")
                if meta["version"] is None and v and not str(v).startswith("${"):
                    meta["version"] = v
        except Exception:
            pass
    # --- LiteLoader: litemod.json ---
    if "litemod.json" in names_set:
        try:
            doc = json.loads(zf.read("litemod.json").decode("utf-8-sig", errors="replace"))
            if isinstance(doc, dict):
                note_loader("liteloader")
                if meta["id_raw"] is None:
                    meta["id_raw"] = doc.get("name")
                if meta["name"] is None:
                    meta["name"] = doc.get("name")
                if meta["version"] is None:
                    meta["version"] = doc.get("version")
        except Exception:
            pass
    # --- MANIFEST.MF-declared mixin configs (MixinConfigs attribute) ---
    mixin_configs_attr = manifest.get("mixinconfigs")
    if mixin_configs_attr:
        add_mixin_refs([r.strip() for r in mixin_configs_attr.split(",") if r.strip()])
    # --- version fallback: MANIFEST.MF Implementation-Version ---
    # Covers the pervasive mods.toml idiom version="${file.jarVersion}",
    # where the real version lives in the manifest.
    if meta["version"] is None:
        iv = manifest.get("implementation-version")
        if iv and not str(iv).startswith("${"):
            meta["version"] = iv
    if meta["version"] is None:
        meta["version"] = "unknown"
    if meta["name"] is None:
        meta["name"] = meta["id_raw"] or "unknown"
    if meta["id_raw"] is not None and not meta["mod_ids"]:
        meta["mod_ids"] = [str(meta["id_raw"])]
    return meta


def detect_platform(names_set):
    """Detect server-plugin platforms that are NOT Minecraft mods.
    Returns (loader, platform_label, descriptor_name) or None. The
    descriptor must sit at the jar root, as the platforms require."""
    lowered = {n.lower(): n for n in names_set}
    if "plugin.yml" in lowered:
        return ("bukkit", "Bukkit/Spigot", lowered["plugin.yml"])
    if "bungee.yml" in lowered:
        return ("bungeecord", "BungeeCord", lowered["bungee.yml"])
    return None


def parse_plugin_descriptor(zf, name):
    """Minimal plugin.yml / bungee.yml scrape: name + version. Line-based —
    the stdlib has no YAML parser, and these two fields are plain scalars
    at the top level of every descriptor."""
    info = {}
    try:
        text = zf.read(name).decode("utf-8", errors="replace")
    except Exception:
        return info
    for line in text.splitlines():
        m = re.match(r"^(name|version)\s*:\s*(.+?)\s*$", line)
        if m and m.group(1) not in info:
            info[m.group(1)] = m.group(2).strip("'\"")
    return info


_TRIVIA_STEMS = ("license", "licence", "copying", "notice", "readme",
                 "changelog", "authors", "credits")


def is_trivia_path(path):
    """True for true metadata/manifest trivia: everything under META-INF/
    (manifest, signatures, loader config such as accesstransformer.cfg —
    named via blockers where relevant), pack.mcmeta, and doc/licence
    files. Anything else that is not code, mod metadata or a known
    content tree is NOT trivia: it is carried as content (see
    process_jar's extra-content pass)."""
    low = path.lower()
    if low.startswith("meta-inf/"):
        return True
    if low == "pack.mcmeta":
        return True  # root-level pack descriptor only; a nested one is content
    base = low.rsplit("/", 1)[-1]
    stem = base.rsplit(".", 1)[0] if "." in base else base
    return any(stem == t or stem.startswith(t + "_") or stem.startswith(t + "-")
               or stem.startswith(t + ".") for t in _TRIVIA_STEMS)


def is_metadata_path(path):
    low = path.lower()
    return (
        low == "fabric.mod.json"
        or low == "quilt.mod.json"
        or low == "mcmod.info"
        or low == "litemod.json"
        or low.endswith("/neoforge.mods.toml")
        or low.endswith("/mods.toml")
        or low == "mods.toml"
        or low == "neoforge.mods.toml"
    )


def is_mixin_config_shape(zf, name):
    """True when the entry parses as a JSON object shaped like a Mixin config:
    a "package" string, or a "mixins" / "client" / "server" array."""
    try:
        doc = json.loads(zf.read(name).decode("utf-8-sig", errors="replace"))
    except Exception:
        return False
    if not isinstance(doc, dict):
        return False
    if isinstance(doc.get("package"), str):
        return True
    return any(isinstance(doc.get(k), list) for k in ("mixins", "client", "server"))


def detect_mixin_configs(zf, names, names_set, mixins_refs):
    """Detect actual Mixin config files. Rule (documented, principled):

    A file counts only when its CONTENT parses as a Mixin-config-shaped JSON
    (see is_mixin_config_shape) AND it is identified by name in one of two ways:
      * it is referenced from loader metadata (fabric.mod.json "mixins", ...), or
      * it sits at the jar root and its filename contains "mixin"/"mixins" as a
        whole token (split on non-alphanumerics) — e.g. "create.mixins.json".
    Substring matches in data paths (data/<ns>/recipe/mixing/*.json recipes,
    whose JSON has type/ingredients keys, not a mixin shape) never count.
    """
    found = set()
    for ref in mixins_refs:
        targets = []
        if ref in names_set:
            targets.append(ref)
        else:
            targets.extend(n for n in names if n.endswith("/" + ref))
        for t in targets:
            if is_mixin_config_shape(zf, t):
                found.add(t)
    for n in names:
        if "/" in n or not n.lower().endswith(".json"):
            continue
        stem = n.rsplit(".", 1)[0].lower()
        tokens = [t for t in re.split(r"[^a-z0-9]+", stem) if t]
        if "mixins" in tokens or "mixin" in tokens:
            if is_mixin_config_shape(zf, n):
                found.add(n)
    return sorted(found)


def is_kubejs_script(name):
    """True only for files KubeJS would actually execute as scripts.

    KubeJS runs *.js files from <phase>_scripts folders (startup_scripts,
    server_scripts, client_scripts) under a kubejs/ root — at the root of a
    pack/jar, or under an assets/ or data/<ns>/ root. A mod's own Java package
    path (dev/latvian/mods/kubejs/...) is NOT a script root: the segment after
    "kubejs" there is a package name, not a *_scripts folder, and the files
    are classes/resources, not scripts.
    """
    low = name.lower()
    if not low.endswith(".js"):
        return False
    parts = low.split("/")
    if "kubejs" not in parts:
        return False
    idx = parts.index("kubejs")
    if idx != 0 and parts[0] not in ("assets", "data"):
        return False
    rest = parts[idx + 1:]
    return bool(rest) and rest[0].endswith("_scripts")


def is_dimension_content(name):
    """True for real dimension definitions: a "dimension",
    "dimension_type" (or legacy "dimensions") path segment outside any
    tags tree — data/<ns>/dimension/**, data/<ns>/dimension_type/**.
    Tag files (data/<ns>/tags/dimension/**) only REFERENCE dimensions;
    they are not definitions and never count."""
    parts = name.lower().split("/")
    if "tags" in parts:
        return False
    return any(p in ("dimension", "dimensions", "dimension_type") for p in parts)


def census_nested_jar(zf, name, depth=1, max_depth=5):
    """Census one nested (Jar-in-Jar) jar IN MEMORY: entry + class counts,
    recursing into jars inside it. Zip entries are read as bytes only —
    nothing is extracted to disk and nothing is executed."""
    detail = {"path": name, "files": 0, "classes": 0, "nested": [], "error": None}
    try:
        nzf = zipfile.ZipFile(io.BytesIO(zf.read(name)), "r")
    except Exception as exc:
        detail["error"] = str(exc)
        return detail
    with nzf:
        entries = [n for n in nzf.namelist() if not n.endswith("/")]
        detail["files"] = len(entries)
        detail["classes"] = sum(1 for n in entries if n.endswith(".class"))
        child_jars = [n for n in entries if n.lower().endswith(".jar")]
        if depth < max_depth:
            for child in child_jars:
                detail["nested"].append(census_nested_jar(nzf, child, depth + 1, max_depth))
        elif child_jars:
            detail["error"] = "nested jars deeper than census limit (%d) not censused" % max_depth
    return detail


def nested_census_totals(details):
    """Aggregate (files, classes, errors) over census_nested_jar details."""
    files = classes = 0
    errors = []
    for d in details:
        files += d.get("files", 0)
        classes += d.get("classes", 0)
        if d.get("error"):
            errors.append("%s: %s" % (d.get("path"), d["error"]))
        sub_files, sub_classes, sub_errors = nested_census_totals(d.get("nested", []))
        files += sub_files
        classes += sub_classes
        errors.extend(sub_errors)
    return files, classes, errors


def check_verdict_consistency(verdict, in_rewrite_queue, queued_files, scaffold_emitted=False):
    """Invariants tying the headline verdict to the rewrite queue:
    * a "data" verdict must never contradict the rewrite queue — a mod
      labelled data-only has no queue entry and zero queued files;
    * a "pattern" verdict with a queue entry is only honest when a
      scaffold was actually emitted for the mod — queued code with no
      scaffold is a rewrite-queue verdict, not a pattern conversion.
    Raises AssertionError when an invariant is violated (fail loud rather
    than ship a false-clean label)."""
    if verdict == "data" and (in_rewrite_queue or queued_files > 0):
        raise AssertionError(
            "verdict 'data' contradicts rewrite queue (in_queue=%r, queued_files=%d)"
            % (in_rewrite_queue, queued_files)
        )
    if verdict == "pattern" and in_rewrite_queue and not scaffold_emitted:
        raise AssertionError(
            "verdict 'pattern' contradicts rewrite queue: mod is queued but "
            "no scaffold was emitted (queued_files=%d)" % queued_files
        )


def detect_entity_ids(names, zf):
    """Split entity evidence into (confirmed_ids, candidate_ids, hint_files).

    CONFIRMED ids come from registration-grade evidence only:
      * entity loot tables: data/<ns>/loot_table(s)/entities/<id>.json
      * lang keys: entity.<ns>.<id> and item.<ns>.<id>_spawn_egg
      * spawn-egg item models: assets/<ns>/models/item/<id>_spawn_egg.json
      * entity-type tags: values "<ns>:<id>" in data/<ns>/tags/entity_type/*.json
      * entity models: assets/<ns>/models/entity/<id>.json, geo/entity models
      * "entity": "<ns>:<id>" references inside data/assets JSONs (spawn eggs)
    CANDIDATE ids are texture/path hints only (textures/entity/** stems and
    other entity-ish path stems): real entities may hide there, but so do
    armour overlays, variants and props — they are reported as candidates in
    the punch-list and NEVER turned into register stubs.
    """
    confirmed = set()
    candidates = set()
    hint_files = set()

    def clean(raw):
        if not raw:
            return None
        s = re.sub(r"[^a-z0-9_]", "_", str(raw).lower()).strip("_")
        return s if s and s not in ("entity", "entities") else None

    def add_confirmed(raw):
        s = clean(raw)
        if s:
            confirmed.add(s)

    def add_candidate(raw):
        s = clean(raw)
        if s:
            candidates.add(s)

    for name in names:
        low = name.lower()
        parts = low.split("/")
        stem = parts[-1].rsplit(".", 1)[0] if "." in parts[-1] else parts[-1]
        is_class = low.endswith(".class")
        m = re.match(r"data/[^/]+/loot_tables?/entities/([^/]+)\.json$", low)
        if m:
            add_confirmed(m.group(1))
            hint_files.add(name)
            continue
        m = re.match(r"assets/[^/]+/models/item/([^/]+)_spawn_egg\.json$", low)
        if m:
            add_confirmed(m.group(1))
            hint_files.add(name)
            continue
        if "/models/entity/" in low or "/geo/entity/" in low:
            if not is_class:
                add_confirmed(stem)
                hint_files.add(name)
            continue
        if "spawn_egg" in low and not is_class:
            add_confirmed(stem.replace("_spawn_egg", ""))
            hint_files.add(name)
            continue
        if "entity" in parts or "entities" in parts:
            hint_files.add(name)
            if not is_class:
                # texture stems and other bare path stems are hints, not ids
                add_candidate(stem)

    # JSON content evidence: lang keys, entity-type tags, spawn-egg refs.
    for name in names:
        low = name.lower()
        if not low.endswith(".json"):
            continue
        if not (low.startswith("data/") or low.startswith("assets/")):
            continue
        try:
            text = zf.read(name).decode("utf-8-sig", errors="replace")
        except Exception:
            continue
        if "/lang/" in low:
            try:
                doc = json.loads(text)
            except Exception:
                doc = None
            if isinstance(doc, dict):
                used = False
                for key in doc:
                    m = re.match(r"entity\.[a-z0-9_]+\.([a-z0-9_]+)$", str(key).lower())
                    if m:
                        add_confirmed(m.group(1))
                        used = True
                        continue
                    m = re.match(r"item\.[a-z0-9_]+\.([a-z0-9_]+)_spawn_egg$", str(key).lower())
                    if m:
                        add_confirmed(m.group(1))
                        used = True
                if used:
                    hint_files.add(name)
        if "/tags/entity_type/" in low:
            parts = low.split("/")
            ns = parts[1] if len(parts) > 1 else ""
            try:
                doc = json.loads(text)
            except Exception:
                doc = None
            if isinstance(doc, dict) and ns:
                used = False
                for v in doc.get("values", []) if isinstance(doc.get("values"), list) else []:
                    ref = v.get("id") if isinstance(v, dict) else v
                    if isinstance(ref, str) and ref.lower().startswith(ns + ":"):
                        add_confirmed(ref.split(":", 1)[1])
                        used = True
                if used:
                    hint_files.add(name)
        if "spawn_egg" in text.lower():
            hits = [m.group(1) for m in re.finditer(r'"entity"\s*:\s*"[^":]+:([a-z0-9_]+)"', text)]
            for h in hits:
                add_confirmed(h)
            if hits:
                hint_files.add(name)

    candidates -= confirmed
    return sorted(confirmed), sorted(candidates), sorted(hint_files)


def find_numeric_facts(zf, names, entity_ids):
    """Look for health/speed/attack numbers in entity-ish JSONs. Best effort."""
    facts = {}
    key_map = {
        "health": "HEALTH", "max_health": "HEALTH", "maxhealth": "HEALTH",
        "speed": "SPEED", "movement_speed": "SPEED", "movementspeed": "SPEED",
        "attack": "ATTACK", "attack_damage": "ATTACK", "attackdamage": "ATTACK", "damage": "ATTACK",
    }
    for name in names:
        low = name.lower()
        if not low.endswith(".json"):
            continue
        if "entit" not in low:
            continue
        try:
            text = zf.read(name).decode("utf-8-sig", errors="replace")
            doc = json.loads(text)
        except Exception:
            continue
        found = {}

        def walk(obj):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    lk = str(k).lower()
                    if lk in key_map and isinstance(v, (int, float)):
                        found[key_map[lk]] = float(v)
                    else:
                        walk(v)
            elif isinstance(obj, list):
                for item in obj:
                    walk(item)

        walk(doc)
        if found:
            stem = low.rsplit("/", 1)[-1].rsplit(".", 1)[0]
            facts[stem] = found
    return facts


# ---------------------------------------------------------------- jar sources

class JarSource:
    def __init__(self, display_name, path=None, data=None, kind="jar"):
        self.display_name = display_name
        self.path = path
        self.data = data
        self.kind = kind  # "jar" or "pack" (standalone datapack/resource/KubeJS pack)

    def open(self):
        if self.path is not None:
            return zipfile.ZipFile(self.path, "r")
        return zipfile.ZipFile(io.BytesIO(self.data), "r")


_MOD_ARCHIVE_SUFFIXES = (".jar", ".litemod")


def looks_like_pack(names):
    """True when a zip/folder listing is itself a standalone pack: a
    pack.mcmeta at the root, a KubeJS tree (kubejs/ holding scripts or
    kubejs/assets / kubejs/data content), or root-level assets/ / data/
    content trees."""
    names_set = set(names)
    if "pack.mcmeta" in names_set:
        return True
    if any(is_kubejs_script(n) for n in names):
        return True
    if any(n.startswith(("kubejs/assets/", "kubejs/data/")) for n in names):
        return True
    return any(n.startswith(("assets/", "data/")) for n in names)


def _loose_pack_groups(names):
    """Group loose (non-archive) entry names into pack trees.

    Returns (groups, strays): groups maps a root prefix ("" for the
    listing root itself, else "dir/") to the entry names under it that
    together form a standalone pack (see looks_like_pack); strays are
    the names in no pack tree. Candidate roots are claimed deepest
    first, so a pack nested inside another tree is still found, and a
    shallower pack claims only the files no deeper pack claimed."""
    names = sorted(names)
    candidates = {""}
    for n in names:
        parts = n.split("/")
        for i in range(1, len(parts)):
            candidates.add("/".join(parts[:i]) + "/")
    pack_roots = []
    for root in candidates:
        # A kubejs/ directory is a pack COMPONENT, never a pack root:
        # the pack's own files (pack.mcmeta, data/, assets/) sit beside
        # it, and the assets//data/ layout mirrored INSIDE kubejs/ would
        # otherwise make the kubejs subtree itself look like a pack.
        if root and root.rstrip("/").rsplit("/", 1)[-1] == "kubejs":
            continue
        rel = [n[len(root):] for n in names if n.startswith(root)]
        if rel and looks_like_pack(rel):
            pack_roots.append(root)
    pack_roots.sort(key=lambda r: (r.count("/"), r), reverse=True)
    claimed = set()
    groups = {}
    for root in pack_roots:
        members = [n for n in names if n.startswith(root) and n not in claimed]
        rel = [n[len(root):] for n in members]
        if members and looks_like_pack(rel):
            groups[root] = members
            claimed.update(members)
    strays = [n for n in names if n not in claimed]
    return groups, strays


def _sources_from_zip(zf, prefix):
    """Expand a batch zip into (sources, ignored). .jar/.litemod entries
    become sources; nested .zip entries are expanded recursively when
    they are batches, or become single sources when they are themselves
    a mod/pack; loose entries that together form a pack tree (a kubejs/
    subtree, or pack.mcmeta + data//assets/ at a subtree root) are
    grouped into ONE pack source; every remaining entry is named in
    ignored so it still gets an explicit coverage entry — no artefact
    is silently dropped."""
    sources = []
    ignored = []
    loose = []
    entries = [n for n in zf.namelist() if not n.endswith("/")]
    for n in sorted(entries):
        low = n.lower()
        display = prefix + n
        if low.endswith(_MOD_ARCHIVE_SUFFIXES):
            sources.append(JarSource(display, data=zf.read(n)))
        elif low.endswith(".zip"):
            try:
                sub = zipfile.ZipFile(io.BytesIO(zf.read(n)))
            except Exception:
                ignored.append({"name": display, "reason": "nested .zip is not a readable archive"})
                continue
            with sub:
                sub_sources, sub_ignored = _sources_from_zip(sub, display + "!")
                if sub_sources:
                    sources.extend(sub_sources)
                    ignored.extend(sub_ignored)
                else:
                    sub_names = [x for x in sub.namelist() if not x.endswith("/")]
                    if "fabric.mod.json" in set(sub.namelist()) or looks_like_pack(sub_names):
                        kind = "jar" if "fabric.mod.json" in set(sub.namelist()) else "pack"
                        sources.append(JarSource(display, data=zf.read(n), kind=kind))
                    else:
                        ignored.append({"name": display,
                                        "reason": "nested .zip contains no mod jars and is not itself a mod/pack"})
        else:
            loose.append(n)
    groups, strays = _loose_pack_groups(loose)
    for root in sorted(groups):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as out:
            for n in groups[root]:
                out.writestr(n[len(root):], zf.read(n))
        display = prefix + (root.rstrip("/") if root else "(loose pack)")
        sources.append(JarSource(display, data=buf.getvalue(), kind="pack"))
    for n in strays:
        ignored.append({"name": prefix + n, "reason": "not a .jar/.litemod mod file"})
    return sources, ignored


def _zip_folder_bytes(folder):
    """Pack a folder's contents into in-memory zip bytes (arcnames are
    the folder-relative paths), so a pack folder flows through the same
    zip-based processing as a jar."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for dirpath, _dirnames, filenames in os.walk(folder):
            for fname in sorted(filenames):
                full = os.path.join(dirpath, fname)
                arc = os.path.relpath(full, folder).replace(os.sep, "/")
                zf.write(full, arc)
    return buf.getvalue()


def _collect_folder(input_path):
    """Folder input: a folder that IS a pack (pack.mcmeta / kubejs/ /
    assets/ / data/ at its root, and no mod archives at the root)
    converts as one pack source. Otherwise mod archives are collected
    RECURSIVELY (subfolders included), nested .zip batches expanded,
    and every other file named in ignored."""
    root_entries = sorted(os.listdir(input_path))
    root_files = [e for e in root_entries
                  if os.path.isfile(os.path.join(input_path, e))]
    root_dirs = {e.lower() for e in root_entries
                 if os.path.isdir(os.path.join(input_path, e))}
    has_root_archives = any(e.lower().endswith(_MOD_ARCHIVE_SUFFIXES) for e in root_files)
    pack_markers = ("pack.mcmeta" in root_files or "kubejs" in root_dirs
                    or "assets" in root_dirs or "data" in root_dirs)
    if pack_markers and not has_root_archives:
        display = os.path.basename(os.path.abspath(input_path))
        return [JarSource(display, data=_zip_folder_bytes(input_path), kind="pack")], []
    sources = []
    ignored = []
    loose = []  # (rel, full) non-archive files; grouped after the walk
    for dirpath, _dirnames, filenames in os.walk(input_path):
        for fname in sorted(filenames):
            full = os.path.join(dirpath, fname)
            rel = os.path.relpath(full, input_path).replace(os.sep, "/")
            low = fname.lower()
            if low.endswith(_MOD_ARCHIVE_SUFFIXES):
                sources.append(JarSource(rel, path=full))
            elif low.endswith(".zip"):
                try:
                    with zipfile.ZipFile(full, "r") as zf:
                        sub_sources, sub_ignored = _sources_from_zip(zf, rel + "!")
                        sub_names = [x for x in zf.namelist() if not x.endswith("/")]
                        sub_is_single = ("fabric.mod.json" in set(zf.namelist())
                                         or looks_like_pack(sub_names))
                except Exception:
                    ignored.append({"name": rel, "reason": ".zip file is not a readable archive"})
                    continue
                if sub_sources:
                    sources.extend(sub_sources)
                    ignored.extend(sub_ignored)
                elif sub_is_single:
                    kind = "jar" if "fabric.mod.json" in set(sub_names) else "pack"
                    sources.append(JarSource(rel, path=full, kind=kind))
                else:
                    ignored.append({"name": rel,
                                    "reason": ".zip contains no mod jars and is not itself a mod/pack"})
            else:
                loose.append((rel, full))
    # Loose files that together form a pack tree (a kubejs/ subtree, or
    # pack.mcmeta + data//assets/ at a subtree root) convert as ONE pack
    # source — the same handling as a standalone pack — instead of one
    # out-of-scope entry per file. Single stray files stay per-file.
    groups, strays = _loose_pack_groups([rel for rel, _full in loose])
    full_by_rel = dict(loose)
    for root in sorted(groups):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as out:
            for rel in groups[root]:
                out.write(full_by_rel[rel], rel[len(root):])
        display = root.rstrip("/") if root else "(loose pack)"
        sources.append(JarSource(display, data=buf.getvalue(), kind="pack"))
    for rel in strays:
        ignored.append({"name": rel, "reason": "not a .jar/.litemod mod file"})
    return sources, ignored


def collect_jar_sources(input_path):
    """Return (sources, ignored_artefacts). Raises ValueError on missing
    input. INVARIANT: every artefact in the input is accounted — it
    either becomes a JarSource or is named in ignored_artefacts, and
    main() gives each ignored artefact an explicit out-of-scope
    coverage entry."""
    if not os.path.exists(input_path):
        raise ValueError("input does not exist: %s" % input_path)
    if os.path.isdir(input_path):
        return _collect_folder(input_path)
    # file input
    low = input_path.lower()
    if low.endswith(_MOD_ARCHIVE_SUFFIXES):
        return [JarSource(os.path.basename(input_path), path=input_path)], []
    if low.endswith(".zip"):
        with zipfile.ZipFile(input_path, "r") as zf:
            sources, ignored = _sources_from_zip(zf, "")
            if sources:
                return sources, ignored
            # No jar-like entries: treat the zip itself as a single mod
            # jar / pack if it looks like one (mod metadata / pack shape).
            names = [n for n in zf.namelist() if not n.endswith("/")]
            if "fabric.mod.json" in set(zf.namelist()) or looks_like_pack(names):
                kind = "jar" if "fabric.mod.json" in set(zf.namelist()) else "pack"
                return [JarSource(os.path.basename(input_path), path=input_path, kind=kind)], []
            return [], []
    raise ValueError("unsupported input (expected .zip, .jar, .litemod, or folder): %s" % input_path)


# ---------------------------------------------------------------- per-jar

def _jar_stem(jar_name):
    """Filename stem of a (possibly path- or '!'-qualified) jar display name."""
    base = re.split(r"[/!]", jar_name)[-1]
    return os.path.splitext(base)[0]


def nested_has_metadata(names_set):
    """True when a nested jar carries its OWN mod metadata (any loader
    format) plus at least one content entry beyond the metadata file —
    such a jar is an embedded mod, not a plain library."""
    metadata_files = 0
    content_files = 0
    for n in names_set:
        if n.endswith("/"):
            continue
        if is_metadata_path(n):
            metadata_files += 1
        else:
            content_files += 1
    return metadata_files > 0 and content_files > 0


def process_jar(source, outdir, revision, used_modids, depth=0):
    """Process one jar. Returns (coverage_entry, queue_entry_or_None,
    embedded_pairs) where embedded_pairs is a list of (entry, queue_entry)
    for nested jars that are mods in their own right."""
    jar_name = source.display_name
    notes = []
    try:
        zf = source.open()
        all_names = zf.namelist()
    except Exception as exc:
        fallback_id, _ = sanitize_modid(_jar_stem(jar_name))
        entry = {
            "modid": fallback_id,
            "original_modid": None,
            "modid_sanitized": False,
            "name": fallback_id,
            "version": "unknown",
            "loader": "unknown",
            "loaders": [],
            "mod_ids": [],
            "jar": jar_name,
            "verdict": "error",
            "components": [],
            "error": "bad jar (not a readable zip): %s" % exc,
            "census": {},
            "buckets": {"carried": 0, "scaffold_input": 0, "queued": 0, "meta_skipped": 0},
            "total_files": 0,
            "blockers": [],
            "notes": ["bad jar skipped; processing continued with other jars"],
            "horizon_mod_path": None,
            "native_scaffold_path": None,
        }
        return entry, None, []

    with zf:
        names = [n for n in all_names if not n.endswith("/")]
        names_set = set(all_names)
        total_files = len(names)

        # ---- server plugins are not mods: explicit out-of-scope ----
        platform = detect_platform(names_set)
        if platform is not None:
            plat_loader, plat_label, descriptor = platform
            info = parse_plugin_descriptor(zf, descriptor)
            plat_id, _ = sanitize_modid(info.get("name") or _jar_stem(jar_name))
            entry = {
                "modid": plat_id,
                "original_modid": None,
                "modid_sanitized": False,
                "name": info.get("name") or plat_id,
                "version": info.get("version") or "unknown",
                "loader": plat_loader,
                "loaders": [plat_loader],
                "mod_ids": [],
                "jar": jar_name,
                "verdict": "out-of-scope",
                "platform": "%s (%s)" % (plat_label, descriptor),
                "components": [],
                "census": {},
                "buckets": {"carried": 0, "scaffold_input": 0, "queued": 0,
                            "meta_skipped": total_files},
                "total_files": total_files,
                "blockers": [],
                "notes": [
                    "not a Minecraft mod: %s server plugin (%s) — out of scope "
                    "for the mod converter; nothing carried, queued or scaffolded. "
                    "All %d file(s) are counted as meta_skipped for accounting only."
                    % (plat_label, descriptor, total_files)
                ],
                "horizon_mod_path": None,
                "native_scaffold_path": None,
            }
            return entry, None, []

        meta = extract_metadata(zf, names_set)
        if source.kind == "pack":
            notes.append("standalone pack input converted as a single pack source")
        if meta["id_raw"] is None:
            meta["id_raw"] = _jar_stem(jar_name)
            notes.append("no mod metadata found; mod id derived from jar filename")
        if len(meta["mod_ids"]) > 1:
            notes.append(
                "jar declares %d mod ids (%s); converted once under %r"
                % (len(meta["mod_ids"]), ", ".join(meta["mod_ids"]), meta["mod_ids"][0])
            )
        modid_sanitized, was_sanitized = sanitize_modid(meta["id_raw"])
        if was_sanitized:
            notes.append("mod id sanitized: %r -> %r" % (meta["id_raw"], modid_sanitized))

        # namespace / modid conflict handling
        final_modid = modid_sanitized
        if final_modid in used_modids:
            idx = 2
            while "%s_%d" % (modid_sanitized, idx) in used_modids:
                idx += 1
            final_modid = "%s_%d" % (modid_sanitized, idx)
            notes.append(
                "namespace conflict: mod id %r already used by %s; this jar written as %r"
                % (modid_sanitized, used_modids[modid_sanitized], final_modid)
            )
        used_modids[final_modid] = jar_name

        # ---- census ----
        assets_files = [n for n in names if n.startswith("assets/")]
        data_files = [n for n in names if n.startswith("data/")]
        class_files = [n for n in names if n.endswith(".class")]
        kubejs_files = [n for n in names if is_kubejs_script(n)]
        nested_jars = [n for n in names if n.lower().endswith(".jar")]
        mixin_files = detect_mixin_configs(zf, names, names_set, meta["mixins_refs"])

        # ---- coremods ----
        # Modern: META-INF/coremods.json maps transformer names to script
        # paths ANYWHERE in the jar (e.g. META-INF/asm/*.js), plus scripts
        # under META-INF/coremods/. Legacy: FMLCorePlugin in MANIFEST.MF.
        # A pure-JS coremod has zero .class files, so without this pass it
        # is invisible to the class-driven verdict logic.
        coremod_files = set()
        if "META-INF/coremods.json" in names_set:
            coremod_files.add("META-INF/coremods.json")
            try:
                cdoc = json.loads(zf.read("META-INF/coremods.json").decode("utf-8-sig", errors="replace"))
                if isinstance(cdoc, dict):
                    for v in cdoc.values():
                        if isinstance(v, str) and v in names_set:
                            coremod_files.add(v)
            except Exception:
                pass
        for n in names:
            if n.startswith("META-INF/coremods/"):
                coremod_files.add(n)
        fml_core_plugin = meta["manifest"].get("fmlcoreplugin")
        is_coremod = bool(coremod_files) or bool(fml_core_plugin)

        # ---- access transformers / wideners ----
        at_files = []
        for n in names:
            low = n.lower()
            base = low.rsplit("/", 1)[-1]
            if low.startswith("meta-inf/") and base.startswith("accesstransformer") \
                    and base.endswith(".cfg"):
                at_files.append(n)
            elif low.endswith(".accesswidener"):
                at_files.append(n)
        if meta.get("access_widener") and meta["access_widener"] in names_set \
                and meta["access_widener"] not in at_files:
            at_files.append(meta["access_widener"])
        at_files = sorted(at_files)

        # ---- bundled native libraries ----
        # Platform binaries (.so/.dylib/.dll, incl. versioned .so.N)
        # anywhere in the jar are part of the rewrite surface: the
        # native rewrite must replace or port them. They are not data
        # (never carried into the .hmod) and not manifest trivia.
        native_files = sorted(n for n in names if _NATIVE_LIB_RE.search(n.lower()))

        # Nested (Jar-in-Jar) jars are censused recursively IN MEMORY so code
        # hiding inside them is visible to the verdict logic; their contents
        # are not jar files of this mod, so buckets below are unaffected —
        # each nested jar itself still counts exactly once, as queued.
        nested_details = [census_nested_jar(zf, n) for n in nested_jars]
        nested_file_count, nested_class_count, nested_census_errors = nested_census_totals(nested_details)
        total_classes = len(class_files) + nested_class_count
        block_entity_files = [
            n for n in names
            if any(tok in n.lower() for tok in ("blockentity", "block_entity", "blockentities", "block_entities"))
        ]
        dimension_files = [n for n in names if is_dimension_content(n)]
        entity_ids, entity_candidate_ids, entity_hint_files = detect_entity_ids(names, zf)
        has_entities_dir = any(
            ("/entities/" in ("/" + n.lower()) or n.lower().startswith("data/") and "/entities/" in n.lower())
            for n in names
        ) or any("entities" in n.lower().split("/") for n in names if n.startswith("data/"))

        # ---- unrecognized content trees ----
        # Files that are neither assets//data/ content, code, mod metadata
        # nor manifest trivia are still CONTENT (e.g. Biomes O' Plenty's
        # embedded classic/ legacy pack tree): they are carried into the
        # .hmod under their original paths, never silently meta_skipped.
        known = set(assets_files) | set(data_files) | set(class_files) | set(mixin_files) \
            | set(kubejs_files) | set(nested_jars) | set(coremod_files) | set(native_files)
        metadata_paths = {n for n in names if is_metadata_path(n)}
        extra_content_files = [
            n for n in names
            if n not in known and n not in metadata_paths and not is_trivia_path(n)
        ]
        extra_trees = {}
        for n in extra_content_files:
            tree = (n.split("/", 1)[0] + "/") if "/" in n else "(jar root)"
            extra_trees[tree] = extra_trees.get(tree, 0) + 1
        other_files = [
            n for n in names
            if n not in known and n not in metadata_paths
            and n not in set(extra_content_files)
        ]
        census = {
            "assets": len(assets_files),
            "data": len(data_files),
            "classes": total_classes,
            "top_level_classes": len(class_files),
            "nested_classes": nested_class_count,
            "nested_files": nested_file_count,
            "nested_jar_details": nested_details,
            "nested_census_errors": nested_census_errors,
            "mixin_configs": len(mixin_files),
            "mixin_config_files": mixin_files,
            "kubejs_scripts": len(kubejs_files),
            "kubejs_script_files": kubejs_files,
            "coremod": is_coremod,
            "coremod_files": sorted(coremod_files),
            "fml_core_plugin": fml_core_plugin,
            "access_transformer_files": at_files,
            "native_files": len(native_files),
            "native_library_files": native_files,
            "extra_content": len(extra_content_files),
            "extra_content_trees": extra_trees,
            "entity_hint_files": len(entity_hint_files),
            "entity_ids": entity_ids,
            "entity_candidate_ids": entity_candidate_ids,
            "block_entity_files": len(block_entity_files),
            "dimension_files": len(dimension_files),
            "nested_jars": nested_jars,
            "other": len(other_files),
            "other_files": other_files,
        }

        # ---- embedded mods inside Jar-in-Jar ----
        # A nested jar carrying its OWN mod metadata is an embedded mod:
        # it gets its own coverage entry (processed after this jar's) and
        # its content is carried like a top-level mod's. Plain library
        # jars without metadata stay census-only dependencies.
        embedded_jar_bytes = {}
        if depth < 3:
            for n in nested_jars:
                try:
                    raw = zf.read(n)
                    with zipfile.ZipFile(io.BytesIO(raw)) as nzf:
                        nested_names_set = set(nzf.namelist())
                except Exception:
                    continue
                if nested_has_metadata(nested_names_set):
                    embedded_jar_bytes[n] = raw
        plain_nested_jars = [n for n in nested_jars if n not in embedded_jar_bytes]

        # ---- blockers / classification ----
        blockers = []
        if total_classes:
            if nested_class_count:
                blockers.append(
                    "%d .class files — behaviour code (%d top-level + %d inside nested jars)"
                    % (total_classes, len(class_files), nested_class_count)
                )
            else:
                blockers.append("%d .class files — behaviour code" % total_classes)
        if mixin_files:
            blockers.append("%d mixin configs" % len(mixin_files))
        if coremod_files:
            blockers.append(
                "coremod: %d JS coremod file(s) (%s) — coremods patch vanilla "
                "classes at load time; that behaviour must be re-implemented "
                "in the native rewrite"
                % (len(coremod_files), ", ".join(sorted(coremod_files)))
            )
        if fml_core_plugin:
            blockers.append(
                "coremod: legacy FMLCorePlugin %s declared in MANIFEST.MF — "
                "coremods patch vanilla classes at load time; that behaviour "
                "must be re-implemented in the native rewrite" % fml_core_plugin
            )
        if at_files:
            blockers.append(
                "access transformer/widener present — rewrite must honour it: %s"
                % ", ".join(at_files)
            )
        if native_files:
            blockers.append(
                "bundles native libraries — the rewrite must replace or port them: %s"
                % ", ".join(native_files)
            )
        if block_entity_files:
            blockers.append("block entity indicators: %d files" % len(block_entity_files))
        if dimension_files:
            blockers.append("dimension indicators: %d files" % len(dimension_files))
        if kubejs_files:
            blockers.append("KubeJS scripts: %d" % len(kubejs_files))
        if plain_nested_jars:
            blockers.append(
                "nested jar (Jar-in-Jar): %d file(s) — not extracted or run, queued as dependency: %s"
                % (len(plain_nested_jars), ", ".join(plain_nested_jars))
            )
        if nested_census_errors:
            blockers.append(
                "nested jar census incomplete — code inside not censused: %s"
                % "; ".join(nested_census_errors)
            )

        has_data_part = bool(assets_files or data_files or extra_content_files)
        has_pattern_part = bool(entity_hint_files or has_entities_dir)
        scaffold_generated = bool(has_pattern_part or has_entities_dir)
        rewrite_triggers = bool(mixin_files) or total_classes > 20 or bool(block_entity_files) \
            or bool(dimension_files) or bool(kubejs_files) or bool(nested_jars) \
            or bool(nested_census_errors) or is_coremod or bool(native_files)

        # Verdict precedence: any rewrite trigger wins FIRST. A mod must never
        # be labelled "data" while a blocker queues it for rewrite (the
        # Fabric API failure: 0 top-level classes but 49 nested jars).
        # Second: a mod with a rewrite-queue entry but NO emitted scaffold
        # is a rewrite-queue verdict, not "pattern" — the pattern label is
        # reserved for mods a scaffold was actually generated for.
        if rewrite_triggers or (blockers and not scaffold_generated):
            verdict = "rewrite-queue"
        elif has_pattern_part or total_classes:
            verdict = "pattern"
        else:
            verdict = "data"

        components = []
        if has_data_part:
            components.append("data")
        if has_pattern_part:
            components.append("pattern")
        if total_classes or mixin_files or kubejs_files or nested_jars \
                or coremod_files or fml_core_plugin or at_files or native_files:
            components.append("rewrite-queue")

        # ---- buckets: every file exactly once ----
        buckets = {"carried": 0, "scaffold_input": 0, "queued": 0, "meta_skipped": 0}
        mixin_set = set(mixin_files)
        kubejs_set = set(kubejs_files)
        native_set = set(native_files)
        extra_set = set(extra_content_files)
        for n in names:
            low = n.lower()
            if n.startswith("assets/") or n.startswith("data/") or n in extra_set:
                buckets["carried"] += 1
            elif is_metadata_path(n):
                buckets["scaffold_input"] += 1
            elif low.endswith(".class") or n in mixin_set or n in kubejs_set \
                    or n in coremod_files or n in native_set or low.endswith(".jar"):
                buckets["queued"] += 1
            else:
                # META-INF/MANIFEST.MF and any other true meta trivia
                buckets["meta_skipped"] += 1

        # ---- data carry ----
        horizon_mod_path = None
        bom_stripped = 0
        if has_data_part:
            mod_dir = os.path.join(outdir, "horizon", "mods", final_modid)
            os.makedirs(mod_dir, exist_ok=True)
            horizon_mod_path = "horizon/mods/%s" % final_modid
            for n in assets_files + data_files + extra_content_files:
                # path traversal guard
                parts = [p for p in n.split("/") if p not in ("", ".", "..")]
                dest = os.path.join(mod_dir, *parts)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                data_bytes = zf.read(n)
                if n.lower().endswith(".json") and data_bytes.startswith(BOM):
                    data_bytes = data_bytes[len(BOM):]
                    bom_stripped += 1
                with open(dest, "wb") as fh:
                    fh.write(data_bytes)
            toml_content = (
                'id = "%s"\nname = "%s"\nversion = "%s"\napi = "0.2"\nside = "%s"\ncapabilities = ["registries"]\n'
                % (toml_escape(final_modid), toml_escape(meta["name"]),
                   toml_escape(meta["version"]), toml_escape(meta["side"]))
            )
            with open(os.path.join(mod_dir, "horizon-mod.toml"), "w", encoding="utf-8") as fh:
                fh.write(toml_content)
        if bom_stripped:
            notes.append("BOM stripped from %d .json file(s) during data carry" % bom_stripped)
        if extra_content_files:
            trees_desc = ", ".join(
                "%s (%d file(s))" % (t, c) for t, c in sorted(extra_trees.items()))
            notes.append(
                "carried %d unrecognized content file(s) as-is under their original "
                "paths — trees: %s" % (len(extra_content_files), trees_desc))
        notes.append("recipe path renames (data/<ns>/recipes/ style) NOT rewritten in v1 — not-implemented, paths carried as-is")

        # ---- entity scaffold (pattern) ----
        native_path = None
        if has_pattern_part or has_entities_dir:
            native_dir = os.path.join(outdir, "horizon", "native", final_modid)
            os.makedirs(os.path.join(native_dir, "src"), exist_ok=True)
            native_path = "horizon/native/%s" % final_modid
            with open(os.path.join(native_dir, "horizon-mixin.toml"), "w", encoding="utf-8") as fh:
                fh.write(
                    'id = "%s"\nname = "%s"\nversion = "%s"\n'
                    'horizon_revision = "%s"\napi = "0.2"\n'
                    '# hooks note: this scaffold is an .hnmod-ready folder; wire the\n'
                    '# register_* stubs in src/lib.rs to Horizon hooks at the pinned revision.\n'
                    % (toml_escape(final_modid), toml_escape(meta["name"]),
                       toml_escape(meta["version"]), toml_escape(revision))
                )
            facts = find_numeric_facts(zf, names, entity_ids)
            # Register stubs are generated ONLY for confirmed entity ids.
            # Texture/path-only candidates are listed in the punch-list as
            # unconfirmed and deliberately get no stub.
            scaffold_ids = entity_ids
            lines = []
            lines.append("// Generated by quikconvert v1 — entity scaffold for %s (%s)." % (final_modid, jar_name))
            lines.append("// DO NOT treat as finished: every attribute below is a TODO placeholder")
            lines.append("// unless a numeric fact was found in the source JSONs (noted inline).")
            lines.append("// Punch-list: see PUNCHLIST.md in this folder.")
            lines.append("")
            if not scaffold_ids:
                lines.append("// No confirmed entity registrations were found; texture/path")
                lines.append("// candidates (if any) are listed in PUNCHLIST.md, unscaffolded.")
                lines.append("")
            for eid in scaffold_ids:
                const = re.sub(r"[^A-Z0-9_]", "_", eid.upper())
                f = facts.get(eid, {})
                health = f.get("HEALTH", 20.0)
                speed = f.get("SPEED", 0.25)
                attack = f.get("ATTACK", 2.0)
                src_note = "from source JSON" if f else "vanilla-ish default, TODO verify"
                lines.append("// --- entity: %s (%s) ---" % (eid, src_note))
                lines.append("pub const %s_HEALTH: f32 = %s; // TODO verify" % (const, fmt_float(health)))
                lines.append("pub const %s_SPEED: f32 = %s; // TODO verify" % (const, fmt_float(speed)))
                lines.append("pub const %s_ATTACK: f32 = %s; // TODO verify" % (const, fmt_float(attack)))
                lines.append("pub fn register_%s() { // TODO: register entity %s, goals, spawn rules" % (eid, eid))
                lines.append("    // TODO: implement")
                lines.append("}")
                lines.append("")
            lines.append("pub fn register() {")
            for eid in scaffold_ids:
                lines.append("    register_%s();" % eid)
            lines.append("}")
            lines.append("")
            with open(os.path.join(native_dir, "src", "lib.rs"), "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines))
            punch = [
                "# Punch-list — %s entity scaffold" % final_modid,
                "",
                "Generated by quikconvert v1 from %s. Nothing here is finished behaviour." % jar_name,
                "",
                "## Detected entities (confirmed by registration-grade evidence)",
            ]
            for eid in scaffold_ids:
                punch.append("- %s" % eid)
            if entity_candidate_ids:
                punch += [
                    "",
                    "## Candidate entities (UNCONFIRMED — texture/path hints only)",
                    "These names came from texture or path stems alone. They may be real",
                    "entities, variants, armour overlays or props. No register stubs were",
                    "generated for them; confirm against the mod's registrations first.",
                ]
                for cid in entity_candidate_ids:
                    punch.append("- %s" % cid)
            punch += [
                "",
                "## A Rust dev / AI rewrite must implement",
                "- Goals / AI behaviour for each entity (target selection, movement, attacks)",
                "- Renderer + model/animation wiring (source assets were data-carried, not converted)",
                "- Spawn rules in detail (biomes, light level, group size, spawn egg / natural spawn)",
                "- Attributes: verify HEALTH / SPEED / ATTACK constants in src/lib.rs against the real mod",
                "- Sounds, loot tables and drops behaviour",
                "- Any behaviour that lived in .class files (see rewrite-queue.json blockers)",
                "",
                "## Source hints used",
            ]
            for hf in entity_hint_files:
                punch.append("- %s" % hf)
            punch.append("")
            with open(os.path.join(native_dir, "PUNCHLIST.md"), "w", encoding="utf-8") as fh:
                fh.write("\n".join(punch))

        entry = {
            "modid": final_modid,
            "original_modid": meta["id_raw"],
            "modid_sanitized": was_sanitized,
            "name": meta["name"],
            "version": meta["version"],
            "loader": meta["loader"],
            "loaders": meta["loaders"],
            "mod_ids": meta["mod_ids"],
            "jar": jar_name,
            "verdict": verdict,
            "components": components,
            "census": census,
            "buckets": buckets,
            "total_files": total_files,
            "blockers": blockers,
            "notes": notes,
            "horizon_mod_path": horizon_mod_path,
            "native_scaffold_path": native_path,
        }
        queue_entry = None
        if blockers:
            queue_entry = {"modid": final_modid, "jar": jar_name, "blockers": blockers}
        # Invariants (Bug 3 + pattern-label rule): the headline verdict must
        # never contradict the rewrite queue.
        check_verdict_consistency(verdict, queue_entry is not None, buckets["queued"],
                                  scaffold_emitted=native_path is not None)

        # ---- embedded mods: process each metadata-bearing nested jar as
        # its own coverage entry, marked embedded_in this jar ----
        embedded_pairs = []
        for n in sorted(embedded_jar_bytes):
            sub_source = JarSource(n, data=embedded_jar_bytes[n])
            e_entry, e_queue, e_embedded = process_jar(
                sub_source, outdir, revision, used_modids, depth=depth + 1)
            e_entry["embedded_in"] = jar_name
            embedded_pairs.append((e_entry, e_queue))
            embedded_pairs.extend(e_embedded)
            notes.append(
                "nested jar %s carries its own mod metadata — processed as a "
                "separate coverage entry (embedded in %s)" % (n, jar_name))
        return entry, queue_entry, embedded_pairs


# ---------------------------------------------------------------- main

def artefact_entry(name, reason):
    """Coverage entry for an input artefact that is not a mod source.
    Every artefact in the input appears in coverage — nothing is
    silently dropped."""
    stem_id, _ = sanitize_modid(_jar_stem(name))
    return {
        "modid": stem_id,
        "original_modid": None,
        "modid_sanitized": False,
        "name": stem_id,
        "version": "unknown",
        "loader": "unknown",
        "loaders": [],
        "mod_ids": [],
        "jar": name,
        "verdict": "out-of-scope",
        "components": [],
        "census": {},
        "buckets": {"carried": 0, "scaffold_input": 0, "queued": 0, "meta_skipped": 0},
        "total_files": 0,
        "blockers": [],
        "notes": ["input artefact not processed: %s — accounted here with an "
                  "explicit out-of-scope verdict so no input artefact is "
                  "silently dropped" % reason],
        "horizon_mod_path": None,
        "native_scaffold_path": None,
    }


# ---------------------------------------------------------------- CurseForge packs
#
# A CurseForge pack reaches quikconvert in two shapes:
#   * an INSTALLED instance folder (the CurseForge app's Instances/<name>/):
#     minecraftinstance.json at its root, the mods physically in mods/;
#   * an EXPORTED pack .zip (or unpacked folder): manifest.json at its root
#     naming every mod by CurseForge project/file ID. The jars themselves are
#     usually NOT in the export — CurseForge downloads them at install time,
#     and quikconvert never downloads (no API key ships). An export with no
#     jars converts nothing: it gets a pack summary naming the blocker and
#     pointing at the installed instance instead. An export that does carry
#     jars under mods/ converts those.
# Either way the pack's identity (name, Minecraft version, loader) is read
# and a pack-import.json / pack-import.md summary is written next to the
# usual coverage outputs. Conversion itself is the ordinary pipeline over
# the pack's mods/ plus any KubeJS tree the instance carries.

_CF_LOADER_ID_RE = re.compile(r"^([A-Za-z]+)[-\s]+(.+)$")


def _cf_parse_loader(raw):
    """'forge-47.1.0' / 'Fabric 0.14.21' -> {'name': 'forge', 'version': '47.1.0'}."""
    if not raw:
        return None
    m = _CF_LOADER_ID_RE.match(str(raw).strip())
    if not m:
        return {"name": str(raw).strip().lower(), "version": None}
    return {"name": m.group(1).lower(), "version": m.group(2).strip()}


def _cf_info_from_manifest(data):
    """Exported-pack manifest.json shape -> pack info, or None."""
    if not isinstance(data, dict):
        return None
    mc = data.get("minecraft")
    if not isinstance(mc, dict) or "files" not in data:
        return None
    loader = None
    loaders = mc.get("modLoaders") or []
    chosen = None
    for cand in loaders:
        if isinstance(cand, dict) and cand.get("primary"):
            chosen = cand
            break
    if chosen is None and loaders and isinstance(loaders[0], dict):
        chosen = loaders[0]
    if chosen is not None:
        loader = _cf_parse_loader(chosen.get("id"))
    return {
        "name": data.get("name"),
        "pack_version": data.get("version"),
        "author": data.get("author"),
        "mc_version": mc.get("version"),
        "loader": loader,
        "manifest_files": data.get("files") or [],
    }


def _cf_info_from_instance(data):
    """minecraftinstance.json shape -> pack info, or None."""
    if not isinstance(data, dict):
        return None
    if "name" not in data and "gameVersion" not in data:
        return None
    info = {
        "name": data.get("name"),
        "pack_version": None,
        "author": None,
        "mc_version": data.get("gameVersion"),
        "loader": None,
        "manifest_files": [],
    }
    bml = data.get("baseModLoader")
    if isinstance(bml, dict):
        info["loader"] = _cf_parse_loader(bml.get("name"))
    elif isinstance(bml, str):
        info["loader"] = _cf_parse_loader(bml)
    manifest = data.get("manifest")
    if isinstance(manifest, dict):
        minfo = _cf_info_from_manifest(manifest)
        if minfo:
            for key, val in minfo.items():
                if info.get(key) in (None, [], "") and val not in (None, [], ""):
                    info[key] = val
    return info


def _cf_read_json_file(path):
    try:
        with open(path, "r", encoding="utf-8-sig") as fh:
            return json.load(fh)
    except Exception:
        return None


def _cf_read_json_zip(zf, name):
    try:
        raw = zf.read(name)
    except Exception:
        return None
    try:
        return json.loads(raw.decode("utf-8-sig"))
    except Exception:
        return None


def detect_cf_pack(input_path):
    """Return a pack-info dict with 'kind' ('instance' | 'export') when the
    input is a CurseForge pack, else None."""
    if os.path.isdir(input_path):
        inst = _cf_read_json_file(os.path.join(input_path, "minecraftinstance.json"))
        if inst is not None:
            info = _cf_info_from_instance(inst)
            if info:
                info["kind"] = "instance"
                return info
        man = _cf_read_json_file(os.path.join(input_path, "manifest.json"))
        if man is not None:
            info = _cf_info_from_manifest(man)
            if info:
                info["kind"] = "export"
                return info
        return None
    if os.path.isfile(input_path) and input_path.lower().endswith(".zip"):
        try:
            with zipfile.ZipFile(input_path, "r") as zf:
                names = set(zf.namelist())
                if "manifest.json" in names:
                    info = _cf_info_from_manifest(_cf_read_json_zip(zf, "manifest.json"))
                    if info:
                        info["kind"] = "export"
                        return info
                if "minecraftinstance.json" in names:
                    info = _cf_info_from_instance(
                        _cf_read_json_zip(zf, "minecraftinstance.json"))
                    if info:
                        info["kind"] = "instance"
                        return info
        except Exception:
            return None
    return None


def cf_instance_roots():
    """Folders that may hold an 'Instances' directory of installed packs."""
    env = os.environ.get("QUIKCONVERT_CF_INSTANCES")
    if env:
        return [p for p in env.split(os.pathsep) if p]
    home = os.path.expanduser("~")
    if os.name == "nt":
        return [os.path.join(home, "curseforge", "minecraft", "Instances")]
    return [
        os.path.join(home, "curseforge", "minecraft", "Instances"),
        os.path.join(home, "Documents", "curseforge", "minecraft", "Instances"),
    ]


def list_cf_instances():
    """Every installed CurseForge instance found under the known roots."""
    found = []
    for root in cf_instance_roots():
        if not os.path.isdir(root):
            continue
        for child in sorted(os.listdir(root)):
            path = os.path.join(root, child)
            if not os.path.isdir(path):
                continue
            info = None
            inst = _cf_read_json_file(os.path.join(path, "minecraftinstance.json"))
            if inst is not None:
                info = _cf_info_from_instance(inst)
            if info is None:
                info = {"name": child, "mc_version": None, "loader": None}
            if not info.get("name"):
                info["name"] = child
            info["path"] = path
            found.append(info)
    return found


def _cf_stage_kubejs(base_dir, stage_root, pack):
    """Copy a KubeJS tree (instance root or overrides/) into a staging
    folder so the folder-pack path converts it as one pack source."""
    candidates = [os.path.join(base_dir, "kubejs"),
                  os.path.join(base_dir, "overrides", "kubejs")]
    for cand in candidates:
        if os.path.isdir(cand):
            stage = os.path.join(stage_root, "kubejs-pack")
            os.makedirs(stage, exist_ok=True)
            shutil.copytree(cand, os.path.join(stage, "kubejs"))
            for meta in ("pack.mcmeta", os.path.join("overrides", "pack.mcmeta")):
                src = os.path.join(base_dir, meta)
                if os.path.isfile(src):
                    shutil.copyfile(src, os.path.join(stage, "pack.mcmeta"))
                    break
            pack["kubejs_tree"] = cand
            return stage
    return None


def collect_cf_pack_sources(input_path, pack):
    """Scoped collection for a CurseForge pack: the mods/ folder (jars in
    place, never copied) plus a staged KubeJS tree when present. The rest
    of an instance (saves, logs, screenshots, config) is accounted in the
    pack summary, never walked. Returns (sources, ignored, stage_root);
    the caller removes stage_root when done (jar bytes are read into
    memory at collect time for pack sources; mod jars stay path-based,
    so mods/ must outlive the call — it is the player's own folder)."""
    import tempfile
    sources, ignored = [], []
    stage_root = tempfile.mkdtemp(prefix="quikconvert-cf-")
    if os.path.isdir(input_path):
        pack["overrides_files"] = 0
        ovr = os.path.join(input_path, "overrides")
        if os.path.isdir(ovr):
            for _dp, _dn, fns in os.walk(ovr):
                pack["overrides_files"] += len(fns)
        mods_dir = os.path.join(input_path, "mods")
        pack["mods_dir_found"] = os.path.isdir(mods_dir)
        if pack["mods_dir_found"]:
            s, i = collect_jar_sources(mods_dir)
            sources.extend(s)
            ignored.extend(i)
        stage = _cf_stage_kubejs(input_path, stage_root, pack)
        if stage:
            s, i = collect_jar_sources(stage)
            sources.extend(s)
            ignored.extend(i)
        pack["instance_trees"] = sorted(
            e for e in os.listdir(input_path)
            if os.path.isdir(os.path.join(input_path, e)))
        return sources, ignored, stage_root
    # Exported pack .zip: pull the jars it actually carries into staging.
    pack["mods_dir_found"] = False
    with zipfile.ZipFile(input_path, "r") as zf:
        names = [n for n in zf.namelist() if not n.endswith("/")]
        jar_names = [n for n in names
                     if n.startswith("mods/") and n.lower().endswith(_MOD_ARCHIVE_SUFFIXES)]
        kube_names = [n for n in names
                      if n.startswith("overrides/kubejs/") or n.startswith("kubejs/")]
        pack["overrides_files"] = sum(1 for n in names if n.startswith("overrides/"))
        if jar_names:
            pack["mods_dir_found"] = True
            stage_mods = os.path.join(stage_root, "mods")
            os.makedirs(stage_mods, exist_ok=True)
            for n in jar_names:
                dst = os.path.join(stage_mods, os.path.basename(n))
                with open(dst, "wb") as fh:
                    fh.write(zf.read(n))
            s, i = collect_jar_sources(stage_mods)
            sources.extend(s)
            ignored.extend(i)
            pack["staged_jars"] = [os.path.basename(n) for n in jar_names]
        if kube_names:
            stage = os.path.join(stage_root, "kubejs-pack")
            os.makedirs(os.path.join(stage, "kubejs"), exist_ok=True)
            for n in kube_names:
                rel = n.split("kubejs/", 1)[1]
                dst = os.path.join(stage, "kubejs", rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with open(dst, "wb") as fh:
                    fh.write(zf.read(n))
            pack["kubejs_tree"] = "in the pack zip"
            s, i = collect_jar_sources(stage)
            sources.extend(s)
            ignored.extend(i)
    return sources, ignored, stage_root


def write_cf_pack_summary(outdir, pack, entries, queue, installed):
    """pack-import.json + pack-import.md: what this pack is, what converted,
    what is queued, and any blocker that kept mods out entirely."""
    mc = pack.get("mc_version")
    loader = pack.get("loader") or {}
    verdicts = {}
    for e in entries:
        verdicts[e.get("modid")] = e.get("verdict")
    blockers = list(pack.get("blockers") or [])
    summary = {
        "kind": pack.get("kind"),
        "name": pack.get("name"),
        "pack_version": pack.get("pack_version"),
        "author": pack.get("author"),
        "minecraft_version": mc,
        "loader": loader,
        "horizon_tag": ("mc-%s" % mc) if mc else None,
        "mods_in_manifest": len(pack.get("manifest_files") or []),
        "mods_dir_found": pack.get("mods_dir_found"),
        "kubejs_tree": pack.get("kubejs_tree"),
        "overrides_files": pack.get("overrides_files", 0),
        "mods_converted": len([e for e in entries if e.get("jar")]),
        "verdicts": verdicts,
        "rewrite_queue_entries": len(queue),
        "installed_into": installed,
        "blockers": blockers,
    }
    with open(os.path.join(outdir, "pack-import.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    md = []
    md.append("# CurseForge pack import: %s" % (pack.get("name") or "(unnamed)"))
    md.append("")
    md.append("- Source: %s" % pack.get("kind"))
    md.append("- Minecraft: %s" % mc)
    md.append("- Loader: %s %s" % (loader.get("name"), loader.get("version") or ""))
    if pack.get("pack_version"):
        md.append("- Pack version: %s" % pack["pack_version"])
    if pack.get("author"):
        md.append("- Author: %s" % pack["author"])
    if mc:
        md.append("- Horizon build for this version: `%s`" % summary["horizon_tag"])
    md.append("- Mods converted: %d" % summary["mods_converted"])
    md.append("- Rewrite-queue entries: %d" % len(queue))
    if installed:
        md.append("- Installed into: `%s`" % installed)
    if blockers:
        md.append("")
        md.append("## Blockers")
        md.append("")
        for b in blockers:
            md.append("- %s" % b)
    md.append("")
    md.append("Per-mod verdicts and file accounting: see coverage.md / coverage.json.")
    md.append("Code that could not be carried as data: see rewrite-queue.json.")
    md.append("")
    with open(os.path.join(outdir, "pack-import.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md))
    return summary


# ------------------------------------------------------- CurseForge browse + get
#
# Browsing and downloading straight from CurseForge, without an API key:
# the keyless api.curse.tools mirror of the official API answers search
# and file queries, and the files themselves come from edge.forgecdn.net.
# This is the ONLY networked part of quikconvert, and it is opt-in (the
# --browse-curseforge / --cf-get modes). Downloaded jars are verified as
# complete readable zips before the converter ever sees them, and — as
# everywhere in quikconvert — jar code is never executed, only read as
# data. QUIKCONVERT_CF_API overrides the API base (tests / mirrors).

CF_API_DEFAULT = "https://api.curse.tools/v1"
_CF_GAME_ID = 432        # Minecraft
_CF_MODPACK_CLASS = 4471  # modpack class on CurseForge


def _cf_api_base():
    return os.environ.get("QUIKCONVERT_CF_API", CF_API_DEFAULT).rstrip("/")


def _cf_http_get(url, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "quikconvert"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _cf_api_json(path):
    return json.loads(_cf_http_get(_cf_api_base() + path, timeout=30)
                      .decode("utf-8-sig"))


def cf_browse_state_path():
    return os.path.join(tempfile.gettempdir(), "quikconvert-browse.json")


def cf_save_browse(version, rows):
    with open(cf_browse_state_path(), "w", encoding="utf-8") as fh:
        json.dump({"version": version, "results": rows}, fh)


def cf_load_browse():
    try:
        with open(cf_browse_state_path(), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def cf_browse_packs(version, search=None, limit=15):
    """Search CurseForge modpacks for one Minecraft version, most
    downloaded first. Returns [{id, name, downloads, versions}]."""
    params = {"gameId": _CF_GAME_ID, "classId": _CF_MODPACK_CLASS,
              "gameVersion": version, "pageSize": limit,
              "sortField": 2, "sortOrder": "desc"}
    if search:
        params["searchFilter"] = search
    data = _cf_api_json("/mods/search?" + urllib.parse.urlencode(params))
    rows = []
    for mod in data.get("data") or []:
        vers = []
        for f in mod.get("latestFiles") or []:
            for v in f.get("gameVersions") or []:
                if v not in vers:
                    vers.append(v)
        rows.append({"id": mod.get("id"), "name": mod.get("name"),
                     "downloads": mod.get("downloadCount"),
                     "versions": vers})
    return rows


def _cf_pick_pack_file(files, version):
    """The newest .zip pack file for the requested version."""
    cands = []
    for f in files or []:
        name = f.get("fileName") or ""
        if not name.lower().endswith(".zip"):
            continue
        vers = f.get("gameVersions") or []
        if vers and version not in vers:
            continue
        cands.append(f)
    if not cands:
        return None
    cands.sort(key=lambda f: f.get("fileDate") or "", reverse=True)
    return cands[0]


def _cf_download_verified(url, dst):
    """Download to dst, verifying the result is a complete readable zip.
    The egress proxy truncates silently; a short file fails testzip."""
    raw = _cf_http_get(url, timeout=180)
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        bad = zf.testzip()
        if bad is not None:
            raise ValueError("corrupt entry in download: %s" % bad)
    with open(dst, "wb") as fh:
        fh.write(raw)
    return len(raw)


def cf_install_pack(project_id, version, instance_dir):
    """Download a pack and assemble it as an installed instance folder:
    the pack zip's manifest + overrides, every manifest mod jar (verified,
    one retry), and a minecraftinstance.json. Returns (info, failures)."""
    listing = _cf_api_json("/mods/%d/files?gameVersion=%s&pageSize=50"
                           % (project_id, urllib.parse.quote(version)))
    pack_file = _cf_pick_pack_file(listing.get("data"), version)
    if pack_file is None:
        raise ValueError("no pack file for Minecraft %s on project %d"
                         % (version, project_id))
    os.makedirs(os.path.join(instance_dir, "mods"), exist_ok=True)
    pack_zip = os.path.join(instance_dir, ".pack-download.zip")
    _cf_download_verified(pack_file["downloadUrl"], pack_zip)
    with zipfile.ZipFile(pack_zip) as zf:
        manifest = json.loads(zf.read("manifest.json").decode("utf-8-sig"))
        for name in zf.namelist():
            if name.startswith("overrides/") and not name.endswith("/"):
                dst = os.path.join(instance_dir, name[len("overrides/"):])
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with open(dst, "wb") as fh:
                    fh.write(zf.read(name))
    os.remove(pack_zip)
    info = _cf_info_from_manifest(manifest) or {}
    loaders = (manifest.get("minecraft") or {}).get("modLoaders") or []
    meta = {"name": manifest.get("name"),
            "gameVersion": (manifest.get("minecraft") or {}).get("version"),
            "baseModLoader": {"name": loaders[0]["id"]} if loaders else None,
            "manifest": manifest}
    with open(os.path.join(instance_dir, "minecraftinstance.json"), "w",
              encoding="utf-8") as fh:
        json.dump(meta, fh, indent=1)
    files = manifest.get("files") or []
    failures = []
    done = 0
    for i, entry in enumerate(files, 1):
        pid, fid = entry["projectID"], entry["fileID"]
        try:
            fmeta = _cf_api_json("/mods/%d/files/%d" % (pid, fid))["data"]
            fname, furl = fmeta["fileName"], fmeta["downloadUrl"]
        except Exception as exc:
            failures.append("project %d file %d: could not resolve (%s)"
                            % (pid, fid, str(exc)[:100]))
            continue
        dst = os.path.join(instance_dir, "mods", fname)
        ok = False
        for _attempt in (1, 2):
            try:
                _cf_download_verified(furl, dst)
                ok = True
                break
            except Exception:
                continue
        if ok:
            done += 1
        else:
            failures.append("%s: download failed verification twice" % fname)
        if i % 20 == 0 or i == len(files):
            print("quikconvert: mods %d/%d downloaded (%d failed)"
                  % (i, len(files), len(failures)))
    info["downloaded_mods"] = done
    info["manifest_mods"] = len(files)
    return info, failures


def main(argv=None):
    parser = argparse.ArgumentParser(prog="quikconvert", description="Horizon mod converter v1 (stdlib only, static/safe)")
    parser.add_argument("input", nargs="?", help="input .zip containing .jar files, a folder of .jar files, a single .jar/.litemod, or a standalone pack folder/zip")
    parser.add_argument("outdir", nargs="?", help="output directory")
    parser.add_argument("--horizon-revision", default=DEFAULT_REVISION, help="Horizon commit SHA to pin scaffolds to")
    parser.add_argument("--list-curseforge", action="store_true", help="list the installed CurseForge instances found on this machine and exit")
    parser.add_argument("--curseforge", type=int, default=None, metavar="N", help="convert the Nth installed CurseForge instance (see --list-curseforge) instead of INPUT")
    parser.add_argument("--curseforge-name", type=int, default=None, metavar="N", help="print a filesystem-safe folder name for the Nth installed instance and exit")
    parser.add_argument("--browse-curseforge", default=None, metavar="VERSION", help="browse CurseForge modpacks for this Minecraft version and exit (numbered list, most downloaded first)")
    parser.add_argument("--search", default=None, help="search text for --browse-curseforge")
    parser.add_argument("--cf-get", type=int, default=None, metavar="N", help="download the Nth pack from the last --browse-curseforge list, assemble it as an instance next to OUTDIR, and convert it")
    parser.add_argument("--cf-get-name", type=int, default=None, metavar="N", help="print a filesystem-safe folder name for the Nth browsed pack and exit")
    parser.add_argument("--install-into", default=None, help="after converting, copy the converted content mods into this folder (Horizon's horizon-mods folder)")
    args = parser.parse_args(argv)

    if args.list_curseforge:
        instances = list_cf_instances()
        if not instances:
            print("quikconvert: no CurseForge instances found (looked in: %s)"
                  % "; ".join(cf_instance_roots()), file=sys.stderr)
            return 2
        for i, inst in enumerate(instances, 1):
            ld = inst.get("loader") or {}
            print("%d\t%s\t%s\t%s\t%s" % (i, inst.get("name"),
                                          inst.get("mc_version") or "?",
                                          ld.get("name") or "?",
                                          inst["path"]))
        return 0
    if args.browse_curseforge:
        try:
            rows = cf_browse_packs(args.browse_curseforge, args.search)
        except Exception as exc:
            print("quikconvert: CurseForge browse failed: %s" % exc, file=sys.stderr)
            return 2
        if not rows:
            print("quikconvert: no CurseForge modpacks found for Minecraft %s"
                  % args.browse_curseforge, file=sys.stderr)
            return 2
        cf_save_browse(args.browse_curseforge, rows)
        for i, row in enumerate(rows, 1):
            print("%d\t%s\t%s downloads\t%s" % (
                i, row["name"], row["downloads"],
                ", ".join(row["versions"][:4])))
        return 0
    if args.cf_get_name is not None:
        state = cf_load_browse()
        if not state or not 1 <= args.cf_get_name <= len(state["results"]):
            print("quikconvert: no browsed pack #%d (browse first)"
                  % args.cf_get_name, file=sys.stderr)
            return 2
        name = state["results"][args.cf_get_name - 1].get("name") or "pack"
        print(re.sub(r"[^A-Za-z0-9._-]+", "-", str(name)).strip("-") or "pack")
        return 0
    cf_get_blockers = []
    if args.cf_get is not None:
        # The one positional is the OUTDIR (argparse fills in order).
        if args.outdir is None and args.input is not None:
            args.outdir, args.input = args.input, None
        if not args.outdir:
            parser.error("--cf-get needs an output folder")
        state = cf_load_browse()
        if not state or not 1 <= args.cf_get <= len(state["results"]):
            print("quikconvert: no browsed pack #%d (browse first)"
                  % args.cf_get, file=sys.stderr)
            return 2
        row = state["results"][args.cf_get - 1]
        instance_dir = os.path.abspath(args.outdir) + ".instance"
        print("quikconvert: downloading '%s' (Minecraft %s) from CurseForge..."
              % (row["name"], state["version"]))
        try:
            _info, cf_get_blockers = cf_install_pack(
                row["id"], state["version"], instance_dir)
        except Exception as exc:
            print("quikconvert: pack download failed: %s" % exc, file=sys.stderr)
            return 2
        print("quikconvert: instance assembled at %s" % instance_dir)
        args.input = instance_dir

    if args.curseforge_name is not None:
        instances = list_cf_instances()
        if not 1 <= args.curseforge_name <= len(instances):
            print("quikconvert: no CurseForge instance #%d" % args.curseforge_name,
                  file=sys.stderr)
            return 2
        name = instances[args.curseforge_name - 1].get("name") or "pack"
        print(re.sub(r"[^A-Za-z0-9._-]+", "-", str(name)).strip("-") or "pack")
        return 0
    if args.curseforge is not None:
        # With --curseforge the one positional is the OUTDIR (argparse fills
        # positionals in order, so it lands in `input`).
        if args.outdir is None and args.input is not None:
            args.outdir, args.input = args.input, None
        instances = list_cf_instances()
        if not 1 <= args.curseforge <= len(instances):
            print("quikconvert: no CurseForge instance #%d" % args.curseforge,
                  file=sys.stderr)
            return 2
        args.input = instances[args.curseforge - 1]["path"]
    if not args.input or not args.outdir:
        parser.error("input and outdir are required (or use --list-curseforge)")

    pack = detect_cf_pack(args.input)
    if pack is not None and cf_get_blockers:
        pack["blockers"] = list(pack.get("blockers") or []) + cf_get_blockers
    if pack is None and os.path.isdir(args.input):
        kids = [c for c in sorted(os.listdir(args.input))
                if os.path.isfile(os.path.join(args.input, c, "minecraftinstance.json"))]
        if kids:
            print("quikconvert: '%s' holds %d CurseForge instance(s); pass one instance folder:"
                  % (args.input, len(kids)))
            for c in kids:
                print("  %s" % os.path.join(args.input, c))
            return 2

    stage_root = None
    try:
        if pack is not None:
            sources, ignored, stage_root = collect_cf_pack_sources(args.input, pack)
        else:
            sources, ignored = collect_jar_sources(args.input)
    except ValueError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 2
    except zipfile.BadZipFile as exc:
        print("error: input zip is not readable: %s" % exc, file=sys.stderr)
        return 2
    if pack is not None:
        ld = pack.get("loader") or {}
        print("quikconvert: CurseForge pack '%s' (Minecraft %s, %s %s) — %s"
              % (pack.get("name"), pack.get("mc_version"), ld.get("name"),
                 ld.get("version") or "", pack.get("kind")))
    if not sources:
        if pack is not None:
            os.makedirs(args.outdir, exist_ok=True)
            if pack.get("kind") == "export":
                pack["blockers"] = [
                    "This exported pack names %d mod(s) by CurseForge project/file "
                    "ID, but the mod jars are not inside it — CurseForge downloads "
                    "them when the pack is installed. Import the INSTALLED instance "
                    "instead (in the CurseForge app, open the pack's folder and pass "
                    "that folder), or convert a folder containing the jars."
                    % len(pack.get("manifest_files") or [])]
            else:
                pack["blockers"] = ["No mod jars found in this instance's mods/ folder."]
            write_cf_pack_summary(args.outdir, pack, [], [], None)
            if stage_root:
                shutil.rmtree(stage_root, ignore_errors=True)
            print("quikconvert: 0 mods converted — see pack-import.md in %s" % args.outdir)
            return 3
        print("error: no .jar files found in input: %s" % args.input, file=sys.stderr)
        return 2

    outdir = args.outdir
    os.makedirs(outdir, exist_ok=True)

    used_modids = {}
    entries = []
    queue = []
    for source in sources:
        entry, queue_entry, embedded_pairs = process_jar(
            source, outdir, args.horizon_revision, used_modids)
        entries.append(entry)
        if queue_entry is not None:
            queue.append(queue_entry)
        for e_entry, e_queue in embedded_pairs:
            entries.append(e_entry)
            if e_queue is not None:
                queue.append(e_queue)
    for art in ignored:
        entries.append(artefact_entry(art["name"], art["reason"]))

    # Artefact accounting: every artefact in the input — each source and
    # each ignored artefact — must have a coverage entry under its name.
    entry_jars = [e.get("jar") for e in entries]
    input_artefacts = sorted([s.display_name for s in sources]
                             + [a["name"] for a in ignored])
    artefact_check = "PASS" if all(a in entry_jars for a in input_artefacts) else "FAIL"

    totals = {"total_files": 0, "carried": 0, "scaffold_input": 0, "queued": 0, "meta_skipped": 0}
    for e in entries:
        totals["total_files"] += e.get("total_files", 0)
        for k in ("carried", "scaffold_input", "queued", "meta_skipped"):
            totals[k] += e.get("buckets", {}).get(k, 0)
    bucket_sum = totals["carried"] + totals["scaffold_input"] + totals["queued"] + totals["meta_skipped"]
    accounting_check = "PASS" if bucket_sum == totals["total_files"] else "FAIL"

    coverage = {
        "generated_by": "quikconvert v1",
        "horizon_revision": args.horizon_revision,
        "input": args.input,
        "mods": entries,
        "totals": totals,
        "bucket_sum": bucket_sum,
        "accounting_check": accounting_check,
        "input_artefacts": input_artefacts,
        "artefact_check": artefact_check,
        "notes": [
            "Every non-directory entry of every jar is counted once in exactly one bucket: carried / scaffold_input / queued / meta_skipped.",
            "Every artefact in the input is accounted: it either became a source (a coverage entry under its name) or is listed with an explicit out-of-scope verdict — see artefact_check and input_artefacts.",
            "Scaffold is derived output, not a jar-file bucket: a carried file that also fed the scaffold is counted as carried only.",
            "BOM stripping: .json files carried with a UTF-8 BOM have the BOM stripped; noted per-mod when it happens.",
            "Recipe path renames (data/<ns>/recipes/ style) are NOT rewritten in v1 — not-implemented, paths carried as-is.",
            "Nested jars (Jar-in-Jar) are never extracted or run; they are queued as dependencies. Their contents are censused recursively in memory (entry/class counts in census.nested_jar_details) so code inside them counts toward the verdict. A nested jar carrying its own mod metadata is an embedded mod: it additionally gets its own coverage entry (embedded_in) and its files are counted and carried there; the nested jar file itself is still counted once in its parent, as queued.",
            "Files outside assets//data/ that are not code, mod metadata or manifest trivia are carried as content under their original paths (census.extra_content_trees, named per-mod in notes); meta_skipped holds only true metadata/manifest trivia.",
            "Loose files inside a batch input that together form a pack tree (a kubejs/ subtree, or pack.mcmeta + data//assets/ at a subtree root) are grouped and converted as ONE pack source; single stray files keep an explicit per-file out-of-scope entry.",
            "Bundled native libraries (.so/.dylib/.dll, incl. versioned .so.N) are part of the rewrite surface: counted in census.native_library_files, named in a blocker, counted as queued — never carried as data and never meta trivia.",
            "Server plugins (Bukkit/Spigot plugin.yml, BungeeCord bungee.yml) are not mods: they get an explicit out-of-scope verdict, no queue entry and no carried content.",
        ],
    }
    if pack is not None:
        coverage["pack"] = {
            "kind": pack.get("kind"),
            "name": pack.get("name"),
            "minecraft_version": pack.get("mc_version"),
            "loader": pack.get("loader"),
            "mods_dir_found": pack.get("mods_dir_found"),
            "kubejs_tree": pack.get("kubejs_tree"),
        }
    with open(os.path.join(outdir, "coverage.json"), "w", encoding="utf-8") as fh:
        json.dump(coverage, fh, indent=2)
    with open(os.path.join(outdir, "rewrite-queue.json"), "w", encoding="utf-8") as fh:
        json.dump(queue, fh, indent=2)

    # coverage.md
    md = []
    md.append("# quikconvert coverage")
    md.append("")
    md.append("Input: `%s`" % args.input)
    md.append("Horizon revision: `%s`" % args.horizon_revision)
    md.append("")
    md.append("## Totals")
    md.append("")
    md.append("- Total files: %d" % totals["total_files"])
    md.append("- Carried: %d" % totals["carried"])
    md.append("- Scaffold-input: %d" % totals["scaffold_input"])
    md.append("- Queued: %d" % totals["queued"])
    md.append("- Meta-skipped: %d" % totals["meta_skipped"])
    md.append("- Bucket sum: %d" % bucket_sum)
    md.append("- Accounting check: **%s**" % accounting_check)
    md.append("- Input artefacts: %d" % len(input_artefacts))
    md.append("- Artefact check: **%s**" % artefact_check)
    md.append("")
    md.append("## Notes")
    md.append("")
    for n in coverage["notes"]:
        md.append("- %s" % n)
    md.append("")
    md.append("## Per-mod")
    md.append("")
    for e in entries:
        md.append("### %s (%s)" % (e["modid"], e["jar"]))
        md.append("")
        if e.get("error"):
            md.append("- Error: %s" % e["error"])
        md.append("- Name: %s" % e.get("name"))
        md.append("- Version: %s" % e.get("version"))
        md.append("- Loader: %s" % e.get("loader"))
        if e.get("loaders") and len(e.get("loaders") or []) > 1:
            md.append("- Loaders found: %s" % ", ".join(e["loaders"]))
        if e.get("mod_ids") and len(e.get("mod_ids") or []) > 1:
            md.append("- Mod ids declared: %s" % ", ".join(e["mod_ids"]))
        if e.get("platform"):
            md.append("- Platform: %s" % e["platform"])
        if e.get("embedded_in"):
            md.append("- Embedded in: %s" % e["embedded_in"])
        md.append("- Verdict: %s" % e.get("verdict"))
        md.append("- Components: %s" % ", ".join(e.get("components") or []))
        md.append("- Total files: %d" % e.get("total_files", 0))
        b = e.get("buckets", {})
        md.append("- Buckets: carried=%d scaffold_input=%d queued=%d meta_skipped=%d"
                  % (b.get("carried", 0), b.get("scaffold_input", 0), b.get("queued", 0), b.get("meta_skipped", 0)))
        if e.get("blockers"):
            md.append("- Blockers:")
            for bl in e["blockers"]:
                md.append("  - %s" % bl)
        for n in e.get("notes", []):
            md.append("- Note: %s" % n)
        md.append("")
    with open(os.path.join(outdir, "coverage.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md))

    if pack is not None:
        installed = None
        if args.install_into:
            src_mods = os.path.join(outdir, "horizon", "mods")
            if os.path.isdir(src_mods):
                os.makedirs(args.install_into, exist_ok=True)
                for modid in sorted(os.listdir(src_mods)):
                    s = os.path.join(src_mods, modid)
                    if os.path.isdir(s):
                        shutil.copytree(s, os.path.join(args.install_into, modid),
                                        dirs_exist_ok=True)
                installed = args.install_into
        write_cf_pack_summary(outdir, pack, entries, queue, installed)
        if installed:
            print("quikconvert: converted content mods installed into %s" % installed)
    if stage_root:
        shutil.rmtree(stage_root, ignore_errors=True)

    print("quikconvert: %d jar(s), %d file(s), accounting %s, artefacts %s -> %s"
          % (len(entries), totals["total_files"], accounting_check, artefact_check, outdir))
    for e in entries:
        print("  %s: verdict=%s files=%d blockers=%d" % (e["modid"], e.get("verdict"), e.get("total_files", 0), len(e.get("blockers", []))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
