@echo off
setlocal
set "HERE=%~dp0"
set "PY="
where py >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if defined PY goto have_py
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY goto no_py
:have_py
if not "%~1"=="" goto from_arg
:menu
echo.
echo QuikConvert - convert mods and CurseForge packs for Horizon
echo   1. Import a CurseForge pack you already installed (auto convert)
echo   2. Convert a mod zip or folder (type the path)
echo   3. Browse CurseForge packs by version (download and convert)
echo   4. Exit
set /p "CHOICE=Pick 1, 2, 3 or 4: "
if "%CHOICE%"=="1" goto cf
if "%CHOICE%"=="2" goto manual
if "%CHOICE%"=="3" goto browse
if "%CHOICE%"=="4" exit /b 0
goto menu
:cf
%PY% "%HERE%quikconvert.py" --list-curseforge > "%TEMP%\qc-list.txt" 2>nul
if errorlevel 1 goto cf_none
echo.
echo Your CurseForge packs:
type "%TEMP%\qc-list.txt"
echo.
set /p "NUM=Type the pack number: "
%PY% "%HERE%quikconvert.py" --curseforge-name %NUM% > "%TEMP%\qc-name.txt" 2>nul
if errorlevel 1 goto bad_num
set /p PACKNAME=<"%TEMP%\qc-name.txt"
if not defined PACKNAME set "PACKNAME=instance-%NUM%"
set "OUT=%HERE%converted\%PACKNAME%"
echo.
echo Converting into %OUT% ...
%PY% "%HERE%quikconvert.py" --curseforge %NUM% "%OUT%"
set "RC=%ERRORLEVEL%"
if "%RC%"=="3" goto cf_empty
if not "%RC%"=="0" goto failed
goto offer_install
:browse
echo.
set /p "VER=Minecraft version, e.g. 1.20.1: "
%PY% "%HERE%quikconvert.py" --browse-curseforge %VER% > "%TEMP%\qc-browse.txt" 2>nul
if errorlevel 1 goto browse_none
echo.
echo Top CurseForge packs for Minecraft %VER%:
type "%TEMP%\qc-browse.txt"
echo.
set /p "NUM=Type the pack number: "
%PY% "%HERE%quikconvert.py" --cf-get-name %NUM% > "%TEMP%\qc-name.txt" 2>nul
if errorlevel 1 goto bad_num
set /p PACKNAME=<"%TEMP%\qc-name.txt"
if not defined PACKNAME set "PACKNAME=pack-%NUM%"
set "OUT=%HERE%converted\%PACKNAME%"
echo.
echo Downloading and converting into %OUT% - big packs can take a while...
%PY% "%HERE%quikconvert.py" --cf-get %NUM% "%OUT%"
set "RC=%ERRORLEVEL%"
if "%RC%"=="3" goto cf_empty
if not "%RC%"=="0" goto failed
goto offer_install
:browse_none
echo.
echo No packs found for that version, or CurseForge could not be reached.
pause
goto menu
:cf_none
echo.
echo No CurseForge packs found. QuikConvert looked in:
echo   %USERPROFILE%\curseforge\minecraft\Instances
echo Install a pack in the CurseForge app first, use option 3 to browse
echo and download one, or use option 2.
pause
goto menu
:bad_num
echo.
echo That number is not on the list.
pause
goto menu
:cf_empty
echo.
echo Nothing was converted. Details are in pack-import.md in the output folder.
pause
exit /b 0
:manual
echo.
set /p "TARGET=Path of the mod zip or folder: "
set "OUT=%HERE%converted"
%PY% "%HERE%quikconvert.py" "%TARGET%" "%OUT%"
set "RC=%ERRORLEVEL%"
if "%RC%"=="3" goto cf_empty
if not "%RC%"=="0" goto failed
goto offer_install
:from_arg
set "OUT=%HERE%converted"
%PY% "%HERE%quikconvert.py" "%~1" "%OUT%"
set "RC=%ERRORLEVEL%"
if "%RC%"=="3" goto cf_empty
if not "%RC%"=="0" goto failed
goto offer_install
:offer_install
if not exist "%OUT%\horizon\mods" goto done
echo.
if exist "%OUT%\pack-import.md" echo This pack targets one Minecraft version - see pack-import.md in the output folder, and play that version in Horizon.
set /p "YN=Install the converted mods into Horizon now? (y/n): "
if /i not "%YN%"=="y" goto done
if not exist "%APPDATA%\horizon\horizon-mods" mkdir "%APPDATA%\horizon\horizon-mods"
xcopy "%OUT%\horizon\mods\*" "%APPDATA%\horizon\horizon-mods\" /E /I /Y >nul
echo Installed into %APPDATA%\horizon\horizon-mods
:done
echo.
echo Done. Converted output is in %OUT%
pause
exit /b 0
:failed
echo.
echo QuikConvert hit an error (code %RC%). Nothing was installed.
pause
exit /b 1
:no_py
echo Python 3 is not installed on this PC.
echo QuikConvert needs Python 3 - it is free from python.org or the Microsoft Store app.
pause
exit /b 1
