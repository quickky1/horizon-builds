Quicks Horizon Launcher
=======================

One launcher for every Horizon version (Minecraft: Java Edition rewritten
in Rust). Made by Quickdeveloper.

HOW TO RUN
----------
1. Unzip this folder anywhere (your Desktop is fine).
2. Run horizon-launcher.exe.

No keys, no setup, nothing to copy anywhere.

WHAT IT DOES
------------
- Lists every released Horizon version. Pick one and hit Install: the
  launcher downloads that build and checks it against its published
  SHA-256 checksums.
- It finds your existing Minecraft files by itself (the official
  launcher's install and the usual folders). If it can't find them, it
  downloads the game files from Mojang after you sign in - Horizon only
  runs with your own legal copy of Minecraft: Java Edition and your
  Microsoft account, same as the official launcher.
- Each version prepares itself using its own bundled preparer, then Play
  starts the game.

Your worlds and settings live in the launcher's own data folder per
version; your real Minecraft install is only read, never changed.
