package dev.horizonlab.parity;

import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.resources.RegistryDataLoader;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.Bootstrap;
import net.minecraft.server.RegistryLayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.ServerPacksSource;
import net.minecraft.server.packs.resources.MultiPackResourceManager;
import net.minecraft.tags.TagLoader;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Shared set-up for the interaction/inventory parity oracles: the vanilla data
 * pack loaded into registries (as the server does), an NBT registry ops, a
 * stand-in ServerLevel that only answers registryAccess, and canonical text
 * for item stacks and NBT so both sides print comparable lines.
 */
public final class ParityData {
    public static HolderLookup.Provider lookup;
    public static RegistryAccess access;
    public static RegistryOps<Tag> ops;
    public static ServerLevel level;
    /** The loot tables of the vanilla data pack (1.20.4: the
     * resources' LootDataManager; the registry-backed holder form
     * arrives with ReloadableServerRegistries in 1.20.5). */
    public static net.minecraft.world.level.storage.loot.LootDataManager loot;

    public static void init() throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        var repo = ServerPacksSource.createVanillaTrustedRepository();
        repo.reload();
        repo.setSelected(List.of("vanilla"));
        var resources = new MultiPackResourceManager(PackType.SERVER_DATA, repo.openAllSelected());
        // No PendingTags stage — RegistryDataLoader.load takes the
        // layer's own access as its lookup context, and tags bind
        // through the server resources. 1.20.4: no
        // ReloadableServerRegistries either — the layered access's
        // composite is the frozen registry access, and loot tables
        // live in the resources' LootDataManager.
        var layers = RegistryLayer.createRegistryAccess();
        RegistryAccess.Frozen world = RegistryDataLoader.load(resources, layers.getAccessForLoading(RegistryLayer.WORLDGEN), RegistryDataLoader.WORLDGEN_REGISTRIES);
        var worldLayers = layers.replaceFrom(RegistryLayer.WORLDGEN, world);
        RegistryAccess.Frozen frozen = worldLayers.compositeAccess();
        lookup = frozen;
        access = frozen;
        var managers = net.minecraft.server.ReloadableServerResources.loadResources(
            resources, frozen, net.minecraft.world.flag.FeatureFlags.VANILLA_SET,
            net.minecraft.commands.Commands.CommandSelection.INTEGRATED, 4, Runnable::run, Runnable::run).join();
        managers.updateRegistryTags(frozen);
        loot = managers.getLootData();
        ops = RegistryOps.create(NbtOps.INSTANCE, lookup);
        var unsafeField = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
        unsafeField.setAccessible(true);
        Object unsafe = unsafeField.get(null);
        level = (ServerLevel) unsafe.getClass().getMethod("allocateInstance", Class.class).invoke(unsafe, ServerLevel.class);
        Field registryAccess = Level.class.getDeclaredField("registryAccess");
        registryAccess.setAccessible(true);
        long offset = (long) unsafe.getClass().getMethod("objectFieldOffset", Field.class).invoke(unsafe, registryAccess);
        unsafe.getClass().getMethod("putObject", Object.class, long.class, Object.class).invoke(unsafe, level, offset, access);
    }

    /** "-" is the empty stack; otherwise the stack's NBT form
     * ({id, Count, tag}) over SNBT — 1.20.4 has no ItemStack.CODEC
     * (that arrives with data components in 1.20.5). */
    public static ItemStack stack(String snbt) throws Exception {
        if (snbt.equals("-")) return ItemStack.EMPTY;
        Tag tag = TagParser.parseTag(snbt);
        return ItemStack.of((CompoundTag) tag);
    }

    public static String canon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "-";
        Tag tag = stack.save(new CompoundTag());
        return canon(tag);
    }

    /** Sorted-key, type-annotated text of an NBT tag. */
    public static String canon(Tag tag) {
        StringBuilder out = new StringBuilder();
        canon(tag, out);
        return out.toString();
    }

    private static void canon(Tag tag, StringBuilder out) {
        // Switch patterns are preview-only on Java 17; instanceof
        // patterns are standard, so the chain is spelled out.
        if (tag instanceof ByteTag t) {
            out.append(t.getAsByte()).append('b');
        } else if (tag instanceof ShortTag t) {
            out.append(t.getAsShort()).append('s');
        } else if (tag instanceof IntTag t) {
            out.append(t.getAsInt());
        } else if (tag instanceof LongTag t) {
            out.append(t.getAsLong()).append('L');
        } else if (tag instanceof FloatTag t) {
            out.append(t.getAsFloat()).append('f');
        } else if (tag instanceof DoubleTag t) {
            out.append(t.getAsDouble()).append('d');
        } else if (tag instanceof StringTag t) {
            out.append('"').append(t.getAsString().replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
        } else if (tag instanceof ByteArrayTag t) {
            out.append("[B;");
            byte[] a = t.getAsByteArray();
            for (int i = 0; i < a.length; i++) out.append(i > 0 ? "," : "").append(a[i]);
            out.append(']');
        } else if (tag instanceof IntArrayTag t) {
            out.append("[I;");
            int[] a = t.getAsIntArray();
            for (int i = 0; i < a.length; i++) out.append(i > 0 ? "," : "").append(a[i]);
            out.append(']');
        } else if (tag instanceof LongArrayTag t) {
            out.append("[L;");
            long[] a = t.getAsLongArray();
            for (int i = 0; i < a.length; i++) out.append(i > 0 ? "," : "").append(a[i]);
            out.append(']');
        } else if (tag instanceof ListTag t) {
            out.append('[');
            for (int i = 0; i < t.size(); i++) {
                if (i > 0) out.append(',');
                canon(t.get(i), out);
            }
            out.append(']');
        } else if (tag instanceof CompoundTag t) {
            out.append('{');
            boolean first = true;
            for (String key : new TreeSet<>(t.getAllKeys())) {
                if (!first) out.append(',');
                first = false;
                out.append(key).append(':');
                canon(t.get(key), out);
            }
            out.append('}');
        } else {
            throw new IllegalStateException(tag.toString());
        }
    }
}
