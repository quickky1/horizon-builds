package dev.horizonlab.parity;

import com.google.gson.*;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.*;

/**
 * 1.20.4 predates data components, so vanilla's data generator has
 * no item report for prepare to read (that report arrives in
 * 1.20.5). This exporter writes the same per-item {components} shape
 * from the item classes themselves: stack size and max damage from
 * the item, attribute modifiers from getDefaultAttributeModifiers
 * over every equipment slot, food from FoodProperties, tool rules
 * from the DiggerItem / SwordItem / ShearsItem destroy-speed and
 * correct-for-drops logic (the needs_*_tool tags stand in for the
 * incorrect_for_* tags, which do not exist yet), and a consumable
 * synthesized from the use animation and duration — the consumable
 * component itself is a 1.21.2 invention, but its facts (eat/drink
 * timing, sound, particles, on-consume effects) are the classes'.
 */
public final class VanillaItemFactsExporter {
    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        var result = new JsonObject();
        for (var item : BuiltInRegistries.ITEM) {
            result.add(BuiltInRegistries.ITEM.getKey(item).toString(), entry(item));
        }
        Files.writeString(Path.of(args[0]), new Gson().toJson(result), StandardCharsets.UTF_8);
    }

    private static JsonObject entry(Item item) throws Exception {
        var components = new JsonArray();
        components.add(component("minecraft:max_stack_size", new JsonPrimitive(item.getMaxStackSize())));
        if (item.getMaxDamage() > 0) {
            components.add(component("minecraft:damage", new JsonPrimitive(0)));
            components.add(component("minecraft:max_damage", new JsonPrimitive(item.getMaxDamage())));
        }
        components.add(component("minecraft:attribute_modifiers", modifiers(item)));
        var food = item.getFoodProperties();
        if (food != null) components.add(component("minecraft:food", food(food)));
        var consumable = consumable(item, food);
        if (consumable != null) components.add(component("minecraft:consumable", consumable));
        var tool = tool(item);
        if (tool != null) components.add(component("minecraft:tool", tool));
        if (item.isFireResistant()) components.add(component("minecraft:fire_resistant", new JsonObject()));
        if (item == Items.BUNDLE) components.add(component("minecraft:bundle_contents", new JsonArray()));
        // No equippable component exists before 1.21.2 and the armour
        // item tags the reader's fallback uses are just as new: the
        // slot lives in the item class (Equipable: armour, elytra).
        if (item instanceof Equipable equipable) {
            var equippable = new JsonObject();
            equippable.addProperty("slot", equipable.getEquipmentSlot().getName());
            var sound = equipable.getEquipSound();
            if (sound != null) equippable.addProperty("equip_sound", sound.getLocation().toString());
            components.add(component("minecraft:equippable", equippable));
        }
        var entry = new JsonObject();
        entry.add("components", components);
        return entry;
    }

    private static JsonObject component(String type, JsonElement value) {
        var o = new JsonObject();
        o.addProperty("type", type);
        o.add("value", value);
        return o;
    }

    private static JsonObject modifiers(Item item) {
        var list = new JsonArray();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            for (var e : item.getDefaultAttributeModifiers(slot).entries()) {
                AttributeModifier mod = e.getValue();
                var o = new JsonObject();
                o.addProperty("type", BuiltInRegistries.ATTRIBUTE.getKey(e.getKey()).toString());
                o.addProperty("amount", mod.getAmount());
                o.addProperty("operation", switch (mod.getOperation()) {
                    case ADDITION -> "add_value";
                    case MULTIPLY_BASE -> "add_multiplied_base";
                    case MULTIPLY_TOTAL -> "add_multiplied_total";
                });
                o.addProperty("slot", slot.getName());
                // Both id spellings: the component codec's uuid int
                // array (the report form) and the string form the
                // item-facts readers index.
                o.addProperty("id", mod.getId().toString());
                var uuid = new JsonArray();
                long msb = mod.getId().getMostSignificantBits();
                long lsb = mod.getId().getLeastSignificantBits();
                uuid.add((int) (msb >> 32));
                uuid.add((int) msb);
                uuid.add((int) (lsb >> 32));
                uuid.add((int) lsb);
                o.add("uuid", uuid);
                list.add(o);
            }
        }
        var value = new JsonObject();
        value.add("modifiers", list);
        return value;
    }

    private static JsonObject food(net.minecraft.world.food.FoodProperties food) {
        var value = new JsonObject();
        value.addProperty("nutrition", food.getNutrition());
        // FoodProperties' own saturation: nutrition * modifier * 2.
        value.addProperty("saturation", food.getNutrition() * food.getSaturationModifier() * 2.0f);
        if (food.canAlwaysEat()) value.addProperty("can_always_eat", true);
        if (!food.getEffects().isEmpty()) {
            var effects = new JsonArray();
            for (var pair : food.getEffects()) {
                var holder = new JsonObject();
                holder.add("effect", effectInstance(pair.getFirst()));
                if (pair.getSecond() != 1.0f) holder.addProperty("probability", pair.getSecond());
                effects.add(holder);
            }
            value.add("effects", effects);
        }
        return value;
    }

    private static JsonObject effectInstance(net.minecraft.world.effect.MobEffectInstance e) {
        var o = new JsonObject();
        o.addProperty("id", BuiltInRegistries.MOB_EFFECT.getKey(e.getEffect()).toString());
        o.addProperty("duration", e.getDuration());
        o.addProperty("amplifier", e.getAmplifier());
        o.addProperty("ambient", e.isAmbient());
        o.addProperty("show_particles", e.isVisible());
        o.addProperty("show_icon", e.showIcon());
        return o;
    }

    /** The consumable the class facts describe, or null when the item
     * is not eaten or drunk (bows, shields and spyglasses animate
     * otherwise and are not consumables). */
    private static JsonObject consumable(Item item, net.minecraft.world.food.FoodProperties food) {
        var stack = new ItemStack(item);
        var anim = item.getUseAnimation(stack);
        if (anim != UseAnim.EAT && anim != UseAnim.DRINK) return null;
        int duration = item.getUseDuration(stack);
        if (duration <= 0) return null;
        var value = new JsonObject();
        value.addProperty("consume_seconds", duration / 20.0);
        boolean eat = anim == UseAnim.EAT;
        value.addProperty("animation", eat ? "eat" : "drink");
        value.addProperty("sound", eat ? "minecraft:entity.generic.eat" : "minecraft:entity.generic.drink");
        value.addProperty("has_consume_particles", eat);
        var effects = new JsonArray();
        if (food != null) {
            for (var pair : food.getEffects()) {
                var apply = new JsonObject();
                apply.addProperty("type", "minecraft:apply_effects");
                var list = new JsonArray();
                var spec = new JsonObject();
                var inst = pair.getFirst();
                spec.addProperty("id", BuiltInRegistries.MOB_EFFECT.getKey(inst.getEffect()).toString());
                spec.addProperty("duration", inst.getDuration());
                spec.addProperty("amplifier", inst.getAmplifier());
                list.add(spec);
                apply.add("effects", list);
                // One entry per effect: vanilla rolls each effect's
                // probability separately.
                if (pair.getSecond() != 1.0f) apply.addProperty("probability", pair.getSecond());
                effects.add(apply);
            }
        }
        if (item instanceof MilkBucketItem) {
            var clear = new JsonObject();
            clear.addProperty("type", "minecraft:clear_all_effects");
            effects.add(clear);
        }
        if (item instanceof HoneyBottleItem) {
            var remove = new JsonObject();
            remove.addProperty("type", "minecraft:remove_effects");
            remove.addProperty("effects", "minecraft:poison");
            effects.add(remove);
        }
        if (item instanceof ChorusFruitItem) {
            var teleport = new JsonObject();
            teleport.addProperty("type", "minecraft:teleport_randomly");
            teleport.addProperty("diameter", 16.0);
            effects.add(teleport);
        }
        if (!effects.isEmpty()) value.add("on_consume_effects", effects);
        return value;
    }

    private static JsonObject tool(Item item) throws Exception {
        var rules = new JsonArray();
        var value = new JsonObject();
        if (item instanceof DiggerItem digger) {
            // DiggerItem.isCorrectToolForDrops on this pin: a needs_*
            // tag the tier is too low for fails the check, then the
            // mineable tag decides; speed is the tier's on that tag.
            Tier tier = digger.getTier();
            int level = tier.getLevel();
            rules.add(needsRule("minecraft:needs_diamond_tool", level >= 3));
            rules.add(needsRule("minecraft:needs_iron_tool", level >= 2));
            rules.add(needsRule("minecraft:needs_stone_tool", level >= 1));
            Field blocks = DiggerItem.class.getDeclaredField("blocks");
            blocks.setAccessible(true);
            var mineable = new JsonObject();
            mineable.addProperty("blocks", "#" + ((net.minecraft.tags.TagKey<?>) blocks.get(digger)).location());
            mineable.addProperty("speed", tier.getSpeed());
            mineable.addProperty("correct_for_drops", true);
            rules.add(mineable);
        } else if (item instanceof SwordItem) {
            // SwordItem.getDestroySpeed / isCorrectToolForDrops:
            // cobwebs at 15 and correct, the sword_efficient tag at
            // 1.5; a sword loses 2 durability per block and cannot
            // break blocks in creative (canAttackBlock).
            var cobweb = new JsonObject();
            cobweb.addProperty("blocks", "minecraft:cobweb");
            cobweb.addProperty("speed", 15.0);
            cobweb.addProperty("correct_for_drops", true);
            rules.add(cobweb);
            var efficient = new JsonObject();
            efficient.addProperty("blocks", "#minecraft:sword_efficient");
            efficient.addProperty("speed", 1.5);
            rules.add(efficient);
            value.addProperty("damage_per_block", 2);
            value.addProperty("can_destroy_blocks_in_creative", false);
        } else if (item instanceof ShearsItem) {
            // ShearsItem.getDestroySpeed: cobweb 15 (and the correct
            // tool for it), leaves 15, wool 5, vine/glow lichen 2.
            var cobweb = new JsonObject();
            cobweb.addProperty("blocks", "minecraft:cobweb");
            cobweb.addProperty("speed", 15.0);
            cobweb.addProperty("correct_for_drops", true);
            rules.add(cobweb);
            var leaves = new JsonObject();
            leaves.addProperty("blocks", "#minecraft:leaves");
            leaves.addProperty("speed", 15.0);
            rules.add(leaves);
            var wool = new JsonObject();
            wool.addProperty("blocks", "#minecraft:wool");
            wool.addProperty("speed", 5.0);
            rules.add(wool);
            var vines = new JsonObject();
            var names = new JsonArray();
            names.add("minecraft:vine");
            names.add("minecraft:glow_lichen");
            vines.add("blocks", names);
            vines.addProperty("speed", 2.0);
            rules.add(vines);
        } else {
            return null;
        }
        value.add("rules", rules);
        return value;
    }

    private static JsonObject needsRule(String tag, boolean correct) {
        var rule = new JsonObject();
        rule.addProperty("blocks", "#" + tag);
        rule.addProperty("correct_for_drops", correct);
        return rule;
    }
}
