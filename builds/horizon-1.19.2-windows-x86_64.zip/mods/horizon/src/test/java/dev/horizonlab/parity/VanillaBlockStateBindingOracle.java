package dev.horizonlab.parity;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.BlockModelDefinition;
import net.minecraft.client.renderer.block.model.MultiVariant;
import net.minecraft.client.renderer.block.model.multipart.MultiPart;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import static dev.horizonlab.parity.VanillaCuboidModelOracle.map;

/** Native registry binding and multipart visual-equality selection, without a GPU. */
public final class VanillaBlockStateBindingOracle {
    private static java.util.function.Function<ResourceLocation,StateDefinition<Block,BlockState>> mapper;
    private static final Gson JSON = new GsonBuilder().serializeNulls().create();
    private static Object field(Object value,String name) throws Exception {
        var f=value.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(value);
    }
    private static void export(Path path) throws Exception {
        var blocks=new TreeMap<String,Object>();
        var ids=new TreeSet<>(Registry.BLOCK.keySet());
        ids.add(ResourceLocation.tryParse("minecraft:item_frame"));ids.add(ResourceLocation.tryParse("minecraft:glow_item_frame"));
        for(var id:ids) {
            var definition=Objects.requireNonNull(mapper.apply(id));
            var schema=new TreeMap<String,Object>();
            for(var property:definition.getProperties()) {
                if(property instanceof IntegerProperty integer) {
                    var values=integer.getPossibleValues();schema.put(property.getName(),map("integer",new int[]{Collections.min(values),Collections.max(values)}));
                } else {
                    var values=values(property);
                    schema.put(property.getName(),map("named",values));
                }
            }
            var states=new ArrayList<Object>();
            for(var state:definition.getPossibleStates()) {
                var properties=new TreeMap<String,String>();
                for(var property:definition.getProperties())properties.put(property.getName(),value(state,property));
                states.add(properties);
            }
            blocks.put(id.toString(),map("schema",schema,"states",states));
        }
        Files.writeString(path,JSON.toJson(blocks));
    }
    private static <T extends Comparable<T>> Set<String> values(Property<T> property) {
        var values=new TreeSet<String>();for(var value:property.getPossibleValues())values.add(property.getName(value));return values;
    }
    private static <T extends Comparable<T>> String value(BlockState state,Property<T> property) {return property.getName(state.getValue(property));}
    private static Object loaderPredicate(Object definition,String key) throws Exception {
        var m=Class.forName("net.minecraft.client.resources.model.BlockStateModelLoader").getDeclaredMethod("predicate",net.minecraft.world.level.block.state.StateDefinition.class,String.class);
        m.setAccessible(true);
        return m.invoke(null,definition,key);
    }
    private static Object bind(JsonObject row) throws Exception {
        var states=Objects.requireNonNull(mapper.apply(ResourceLocation.tryParse(row.get("block").getAsString())));
        var json=GsonHelper.parse(row.get("json").getAsString());
        // 1.19.2: the parse entry is fromStream(Context, Reader)
        // (fromJsonElement is a later form), and there is no
        // instantiate() (that arrives with the 1.21.2 model rework)
        // — selection is the loader's own:
        // multipart selectors by their predicates, variants by the
        // loader's key predicate, first match in JSON key order.
        var context=new BlockModelDefinition.Context();
        context.setDefinition(states);
        var definition=BlockModelDefinition.fromStream(context,new java.io.StringReader(row.get("json").getAsString()));
        var indices=new IdentityHashMap<MultiVariant,Integer>();
        var variantKeys=new ArrayList<String>();
        if(json.isJsonObject()&&json.getAsJsonObject().has("variants")) {
            int index=0;
            for(var key:json.getAsJsonObject().getAsJsonObject("variants").keySet()){indices.put(definition.getVariant(key),index++);variantKeys.add(key);}
        }
        var selected=new ArrayList<Object>();
        for(var state:states.getPossibleStates()) {
            if(definition.isMultiPart()) {
                var matched=new ArrayList<Integer>();
                var selectors=definition.getMultiPart().getSelectors();
                for(int i=0;i<selectors.size();i++)
                    if(selectors.get(i).getPredicate(states).test(state))matched.add(i);
                selected.add(map("multipart",matched));
                continue;
            }
            MultiVariant found=null;
            for(var key:variantKeys) {
                @SuppressWarnings("unchecked")
                var predicate=(java.util.function.Predicate<BlockState>)loaderPredicate(states,key);
                if(predicate.test(state)){found=definition.getVariant(key);break;}
            }
            if(found==null) {selected.add(null);continue;}
            var index=indices.get(found);if(index==null)throw new AssertionError("unrecognized simple root");
            selected.add(map("variant",index));
        }
        return selected;
    }
    public static void main(String[] args) throws Exception {
        net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
        // 1.21.4 has no BlockStateDefinitions mapper (1.21.5+); the
        // blockstate location of a block is its registry id, so the
        // registry is the equivalent source of state definitions.
        mapper=id->{var block=Registry.BLOCK.get(id);return block==null?null:block.getStateDefinition();};
        if(args[0].equals("export")){export(Path.of(args[1]));return;}
        try(var input=Files.newBufferedReader(Path.of(args[0]));var output=Files.newBufferedWriter(Path.of(args[1]))) {
            for(String line;(line=input.readLine())!=null;) {
                var row=JsonParser.parseString(line).getAsJsonObject();Object result;
                try {result=map("name",row.get("name").getAsString(),"selected",bind(row));}
                catch(RuntimeException error) {result=map("name",row.get("name").getAsString(),"error",true);}
                output.write(JSON.toJson(result));output.newLine();
            }
        }
    }
}
