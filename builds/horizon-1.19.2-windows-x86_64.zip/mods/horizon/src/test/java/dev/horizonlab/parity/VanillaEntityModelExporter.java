package dev.horizonlab.parity;

import com.google.gson.*;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.client.model.geom.LayerDefinitions;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.server.Bootstrap;

/**
 * Original exporter of every baked entity model layer (part tree, initial poses and
 * textured polygons) produced by vanilla's own LayerDefinitions.
 */
public final class VanillaEntityModelExporter {
    private static Field cubes;
    private static Field cubePolygons;
    private static Field children;

    @SuppressWarnings("unchecked")
    private static JsonObject part(ModelPart part) throws Exception {
        var o = new JsonObject();
        var pose = new JsonArray();
        for (float f : new float[] {part.x, part.y, part.z, part.xRot, part.yRot, part.zRot, part.xScale, part.yScale, part.zScale})
            pose.add(f);
        o.add("pose", pose);
        var polygons = new JsonArray();
        var normals = new JsonArray();
        for (ModelPart.Cube cube : (List<ModelPart.Cube>) cubes.get(part)) {
            // 1.21: ModelPart.Polygon and ModelPart.Vertex are
            // package-private classes; walk them reflectively.
            for (Object polygon : (Object[]) cubePolygons.get(cube)) {
                var polygonClass = polygon.getClass();
                var verticesField = polygonClass.getDeclaredField("vertices");
                verticesField.setAccessible(true);
                var normalField = polygonClass.getDeclaredField("normal");
                normalField.setAccessible(true);
                var p = new JsonArray();
                for (Object v : (Object[]) verticesField.get(polygon)) {
                    // 1.21's Vertex is a class with public fields,
                    // not a record: pos (com.mojang.math.Vector3f on this era), u, v.
                    var vertexClass = v.getClass();
                    var posField = vertexClass.getField("pos");
                    posField.setAccessible(true);
                    var uField = vertexClass.getField("u");
                    uField.setAccessible(true);
                    var vField = vertexClass.getField("v");
                    vField.setAccessible(true);
                    var pos = (com.mojang.math.Vector3f) posField.get(v);
                    var u = uField.getFloat(v);
                    var vv = vField.getFloat(v);
                    var vertex = new JsonArray();
                    // Degenerate (zero-size) faces have NaN UVs: write them as 0.
                    for (float f : new float[] {pos.x(), pos.y(), pos.z(), u, vv})
                        vertex.add(Float.isFinite(f) ? f : 0.0F);
                    p.add(vertex);
                }
                polygons.add(p);
                var normalVec = (com.mojang.math.Vector3f) normalField.get(polygon);
                var normal = new JsonArray();
                normal.add(normalVec.x());
                normal.add(normalVec.y());
                normal.add(normalVec.z());
                normals.add(normal);
            }
        }
        o.add("polygons", polygons);
        o.add("normals", normals);
        var kids = new JsonObject();
        for (var entry : ((Map<String, ModelPart>) children.get(part)).entrySet())
            kids.add(entry.getKey(), part(entry.getValue()));
        o.add("children", kids);
        return o;
    }

    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        cubes = ModelPart.class.getDeclaredField("cubes");
        cubePolygons = ModelPart.Cube.class.getDeclaredField("polygons");
        cubePolygons.setAccessible(true);
        cubes.setAccessible(true);
        children = ModelPart.class.getDeclaredField("children");
        children.setAccessible(true);
        var out = new JsonObject();
        for (var entry : LayerDefinitions.createRoots().entrySet()) {
            try {
                out.add(entry.getKey().toString(), part(entry.getValue().bakeRoot()));
            } catch (RuntimeException error) {
                System.err.println("skipped " + entry.getKey() + ": " + error);
            }
        }
        Files.writeString(Path.of(args[0]), new Gson().toJson(out), StandardCharsets.UTF_8);
    }
}
