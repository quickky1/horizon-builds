package dev.horizonlab.parity;

import com.google.gson.*;
import java.io.PrintWriter;
import java.nio.file.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.village.poi.PoiManager;
import net.minecraft.world.entity.ai.village.poi.PoiSection;
import net.minecraft.world.entity.ai.village.poi.PoiTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;

/**
 * Nether portal travel, one entity per case: `NetherPortalBlock.getPortalDestination`
 * for an entity standing in a portal of one headless level (the block update
 * oracle's), going to another (the Nether from the overworld or back), whose
 * points of interest are the case's portal blocks in the case's order. It runs
 * `PortalForcer.findClosestPortalPosition` and, when nothing is found,
 * `createPortal`, `BlockUtil.getLargestRectangleAround`,
 * `PortalShape.getRelativePosition` and `findCollisionFreePosition`. Printed:
 * the entity's size, the exit portal found (or "created"), the blocks the
 * destination changed and the arrival position (bits) and yaw.
 */
public final class VanillaPortalOracle {
    /** The points of interest of the destination: the case's portal blocks. */
    static final class Poi extends PoiManager {
        Map<Long, PoiSection> sections;
        Poi() {
            super(null, null, null, false, null, null, null);
        }
        @Override protected Optional<PoiSection> getOrLoad(long key) { return Optional.ofNullable(sections.get(key)); }
        @Override public void ensureLoadedAndValid(net.minecraft.world.level.LevelReader reader, BlockPos center, int radius) { }
    }

    static net.minecraft.world.level.dimension.DimensionType OVERWORLD, NETHER;

    public static void main(String[] args) throws Exception {
        ParityData.init();
        VanillaBlockUpdateOracle.AIR = Blocks.AIR.defaultBlockState();
        VanillaLevelShapeOracle.bindFluidTags(Path.of(args[0]).resolve("data/minecraft/tags/fluid"));
        OVERWORLD = VanillaBlockUpdateOracle.OVERWORLD_TYPE = VanillaBlockUpdateOracle.loadOverworld();
        NETHER = VanillaBlockUpdateOracle.loadDimensionType(BuiltinDimensionTypes.NETHER);
        var allocator = Class.forName("sun.misc.Unsafe");
        var field = allocator.getDeclaredField("theUnsafe");
        field.setAccessible(true);
        VanillaBlockUpdateOracle.unsafe = field.get(null);
        VanillaBlockUpdateOracle.allocate = allocator.getMethod("allocateInstance", Class.class);
        try (var out = new PrintWriter(Files.newBufferedWriter(Path.of(args[2]))); var lines = Files.lines(Path.of(args[1]))) {
            int index = 0;
            for (var line : (Iterable<String>) lines::iterator) {
                var f = JsonParser.parseString(line).getAsJsonObject();
                out.print("case " + index++ + "\n");
                try {
                    for (String s : run(f)) out.print(s + "\n");
                } catch (Throwable e) {
                    Throwable c = e;
                    while (c.getCause() != null) c = c.getCause();
                    if (System.getenv("ORACLE_TRACE") != null) c.printStackTrace();
                    StackTraceElement[] st = c.getStackTrace();
                    out.print("error " + c.getClass().getSimpleName() + " " + (st.length > 0 ? st[0].toString() : "") + " " + c.getMessage() + "\n");
                }
            }
        }
    }

    static VanillaBlockUpdateOracle.World level(JsonObject f, String cells, boolean nether) throws Exception {
        var copy = new JsonObject();
        copy.add("cells", f.get(cells));
        copy.add("seed", f.get("seed"));
        var w = VanillaBlockUpdateOracle.build(copy);
        w.type = nether ? NETHER : OVERWORLD;
        w.dimensionKey = nether ? Level.NETHER : Level.OVERWORLD;
        return w;
    }

    static List<String> run(JsonObject f) throws Exception {
        boolean fromNether = f.get("from").getAsString().equals("nether");
        var source = level(f, "source", fromNether);
        var target = level(f, "target", !fromNether);
        var levels = new HashMap<net.minecraft.resources.ResourceKey<Level>, net.minecraft.server.level.ServerLevel>();
        levels.put(source.dimension(), source);
        levels.put(target.dimension(), target);
        source.server.levels = levels;
        target.server = source.server;
        var border = new net.minecraft.world.level.border.WorldBorder();
        var b = f.getAsJsonObject("border");
        border.setCenter(b.get("x").getAsDouble(), b.get("z").getAsDouble());
        border.setSize(b.get("size").getAsDouble());
        target.border = border;
        var poi = (Poi) VanillaBlockUpdateOracle.allocate.invoke(VanillaBlockUpdateOracle.unsafe, Poi.class);
        poi.sections = new HashMap<>();
        VanillaBlockUpdateOracle.set(net.minecraft.world.level.chunk.storage.SectionStorage.class, poi, "levelHeightAccessor", target);
        var portalType = Registry.POINT_OF_INTEREST_TYPE.getOrThrow(PoiTypes.NETHER_PORTAL);
        for (var p : f.getAsJsonArray("pois")) {
            BlockPos at = VanillaBlockUpdateOracle.readPos(p.getAsJsonArray());
            poi.sections.computeIfAbsent(SectionPos.asLong(at), k -> new PoiSection(() -> { })).add(at, portalType);
        }
        target.poi = poi;
        VanillaBlockUpdateOracle.set(net.minecraft.server.level.ServerLevel.class, target, "portalForcer", new net.minecraft.world.level.portal.PortalForcer(target));
        var e = f.getAsJsonObject("entity");
        Entity entity = Registry.ENTITY_TYPE.getValue(ResourceLocation.tryParse(e.get("type").getAsString())).create(source, EntitySpawnReason.LOAD);
        // Exact doubles, as bits.
        var at = e.getAsJsonArray("bits");
        java.util.function.IntToDoubleFunction bit = i -> Double.longBitsToDouble(Long.parseUnsignedLong(at.get(i).getAsString(), 16));
        entity.setPos(bit.applyAsDouble(0), bit.applyAsDouble(1), bit.applyAsDouble(2));
        List<String> out = new ArrayList<>();
        var dimensions = entity.getDimensions(entity.getPose());
        out.add(String.format("dims %08x %08x", Float.floatToIntBits(dimensions.width()), Float.floatToIntBits(dimensions.height())));
        Map<BlockPos, BlockState> before = new HashMap<>(target.cells);
        BlockPos entry = VanillaBlockUpdateOracle.readPos(f.getAsJsonArray("entry"));
        // The steps getPortalDestination takes, for the report.
        BlockState entryState = source.getBlockState(entry);
        if (entryState.hasProperty(NetherPortalBlock.AXIS)) {
            var axis = entryState.getValue(NetherPortalBlock.AXIS);
            var area = net.minecraft.util.BlockUtil.getLargestRectangleAround(entry, axis, 21, net.minecraft.core.Direction.Axis.Y, 21, q -> source.getBlockState(q) == entryState);
            out.add("entry " + VanillaBlockUpdateOracle.pos(area.minCorner) + " " + area.axis1Size + "x" + area.axis2Size);
            var offset = entity.getRelativePortalPosition(axis, area);
            out.add(String.format("offset %016x %016x %016x", Double.doubleToLongBits(offset.x), Double.doubleToLongBits(offset.y), Double.doubleToLongBits(offset.z)));
        }
        double scale = net.minecraft.world.level.dimension.DimensionType.getTeleportationScale(source.dimensionType(), target.dimensionType());
        BlockPos approximate = border.clampToBounds(entity.getX() * scale, entity.getY(), entity.getZ() * scale);
        out.add("approximate " + VanillaBlockUpdateOracle.pos(approximate));
        out.add("found " + target.getPortalForcer().findClosestPortalPosition(approximate, !fromNether, border).map(VanillaBlockUpdateOracle::pos).orElse("none"));
        var transition = ((NetherPortalBlock) Blocks.NETHER_PORTAL).getPortalDestination(source, entity, entry);
        out.addAll(VanillaBlockUpdateOracle.summary(target, before));
        if (transition == null) {
            out.add("dest none");
        } else {
            var p = transition.position();
            out.add(String.format("dest %016x %016x %016x %s", Double.doubleToLongBits(p.x), Double.doubleToLongBits(p.y), Double.doubleToLongBits(p.z),
                Float.toString(transition.yRot())));
        }
        return out;
    }
}
