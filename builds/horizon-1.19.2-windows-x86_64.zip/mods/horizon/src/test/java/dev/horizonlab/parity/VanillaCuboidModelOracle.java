package dev.horizonlab.parity;

import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.minecraft.client.renderer.block.model.*;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.resources.ResourceLocation;
import com.mojang.math.Vector3f;

/** Original adapter around the pinned client parser. No model assets are embedded. */
public final class VanillaCuboidModelOracle {
    private static final Gson JSON = new GsonBuilder().serializeNulls().create();
    private static long bits(float value) { return Integer.toUnsignedLong(Float.floatToIntBits(value)); }
    private static Object vector(Vector3f value) { return new long[]{bits(value.x()), bits(value.y()), bits(value.z())}; }
    private static String direction(net.minecraft.core.Direction value) { return value == null ? null : value.getName(); }
    static Map<String, Object> map(Object... values) {
        var result = new TreeMap<String, Object>();
        for (int i=0;i<values.length;i+=2) result.put((String)values[i], values[i+1]);
        return result;
    }
    static Object transform(ItemTransform value) {
        if (value == ItemTransform.NO_TRANSFORM) return "inherit";
        if (value == null) return null;
        return map("rotation", vector(value.rotation), "translation", vector(value.translation), "scale", vector(value.scale));
    }
    private static Object rotation(BlockElementRotation value) {
        if (value == null) return null;
        // 1.19.2: BlockElementRotation is the classic class with
        // public fields (origin, axis, angle, rescale) — the record
        // accessors are a later re-form. The emitted "value" keeps
        // the single-axis map shape.
        Object angles = map("axis", value.axis.getName(), "angle", bits(value.angle));
        return map("origin", vector(value.origin), "value", angles, "rescale", value.rescale);
    }
    private static Object face(BlockElementFace value) {
        if (value == null) return null;
        // 1.21.4: BlockElementFace.uv() is a BlockFaceUV (float[4] uvs,
        // rotation in degrees); the uvs() object and the FaceRotation
        // enum are 1.21.5+. Emitted rotation keeps quarter-turn units.
        var uv = value.uv;
        return map("cull", direction(value.cullForDirection), "tint", value.tintIndex, "texture", value.texture,
            "rotation", uv == null ? 0 : uv.rotation / 90, "uv", uv == null ? null : new long[]{bits(uv.uvs[0]), bits(uv.uvs[1]), bits(uv.uvs[2]), bits(uv.uvs[3])});
    }
    static Object element(BlockElement value) {
        if (value == null) return null;
        var faces = new TreeMap<String, Object>();
        value.faces.forEach((key, f) -> faces.put(key.getName(), face(f)));
        return map("from", vector(value.from), "to", vector(value.to), "faces", faces,
            // BlockElement.shade is a plain boolean field in this era too.
            "rotation", rotation(value.rotation), "shade", value.shade, "light", 0);
    }
    private static String serializedName(ItemTransforms.TransformType context) {
        return switch (context) {
            case THIRD_PERSON_LEFT_HAND -> "thirdperson_lefthand";
            case THIRD_PERSON_RIGHT_HAND -> "thirdperson_righthand";
            case FIRST_PERSON_LEFT_HAND -> "firstperson_lefthand";
            case FIRST_PERSON_RIGHT_HAND -> "firstperson_righthand";
            case HEAD -> "head";
            case GUI -> "gui";
            case GROUND -> "ground";
            case FIXED -> "fixed";
            case NONE -> "none";
        };
    }

    private static Object model(BlockModel value) throws Exception {
        if (value == null) return null;
        var textures = new TreeMap<String, Object>();
        // 1.21.3: no texture-slot system (that arrives in 1.21.4);
        // BlockModel carries a protected textureMap of
        // Either<Material, String> — a material on the left, a "#name"
        // reference string on the right. Emit both as the plain
        // strings the Rust decoder accepts.
        var textureMapField = BlockModel.class.getDeclaredField("textureMap"); textureMapField.setAccessible(true);
        var textureMap = (java.util.Map<String, com.mojang.datafixers.util.Either<net.minecraft.client.resources.model.Material, String>>)textureMapField.get(value);
        for (var entry : textureMap.entrySet()) {
            var either = entry.getValue();
            if (either.left().isPresent()) {
                textures.put(entry.getKey(), either.left().get().texture().toString());
            } else {
                textures.put(entry.getKey(), either.right().orElse(""));
            }
        }
        // 1.21.4: elements live behind the package-private getElements()
        // and the JSON parent is the parentLocation field (the resolved
        // parent model is only set by resolveDependencies). There is no
        // geometry()/SimpleUnbakedGeometry split (1.21.5+); the element
        // list is always the model's own. getAmbientOcclusion() is a
        // nullable Boolean whose effective default is true.
        List<Object> elements = new ArrayList<>();
        var elementsMethod = BlockModel.class.getDeclaredMethod("getElements"); elementsMethod.setAccessible(true);
        for (var element : (List<BlockElement>)elementsMethod.invoke(value)) elements.add(element(element));
        var parentField = BlockModel.class.getDeclaredField("parentLocation"); parentField.setAccessible(true);
        var parentLocation = (ResourceLocation)parentField.get(value);
        Object display = null;
        var itemTransforms = value.getTransforms();
        if (itemTransforms != null && !itemTransforms.equals(ItemTransforms.NO_TRANSFORMS)) {
            var transforms = new TreeMap<String, Object>();
            // 1.19.3: ItemDisplayContext arrives in 1.19.4 with the
            // display entities; the contexts are the nested
            // ItemTransforms.TransformType enum, and the JSON names
            // its Deserializer uses are the same strings.
            for (var context : ItemTransforms.TransformType.values()) {
                if (context != ItemTransforms.TransformType.NONE) transforms.put(serializedName(context), transform(itemTransforms.getTransform(context)));
            }
            display = transforms;
        }
        // 1.21.3: ambient occlusion is hasAmbientOcclusion() (a plain
        // boolean, defaulting true); there is no nullable accessor.
        return map("parent", parentLocation == null ? null : parentLocation.toString(), "ao", value.hasAmbientOcclusion(),
            "gui", value.getGuiLight() == null ? null : value.getGuiLight().name().toLowerCase(Locale.ROOT), "textures", textures, "elements", elements, "display", display);
    }
    public static void main(String[] args) throws Exception {
        net.minecraft.SharedConstants.tryDetectVersion();
        try (var input=Files.newBufferedReader(Path.of(args[0])); var output=Files.newBufferedWriter(Path.of(args[1]))) {
            for (String line; (line=input.readLine())!=null;) {
                var row=JsonParser.parseString(line).getAsJsonArray();
                BlockModel decoded;
                try { decoded=BlockModel.fromStream(new StringReader(row.get(1).getAsString())); }
                catch (RuntimeException failure) {
                    output.write(JSON.toJson(map("name", row.get(0).getAsString(), "error", true))); output.newLine(); continue;
                }
                output.write(JSON.toJson(map("name", row.get(0).getAsString(), "model", model(decoded)))); output.newLine();
            }
        }
    }
}
