package dev.horizonlab.parity;

import com.google.gson.*;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/**
 * Original exporter of the creative inventory, era form for 1.19.2: there is
 * no CreativeModeTabs class, no tab registry and no feature flags on this
 * pin — the tabs are the static TAB_* fields of CreativeModeTab itself, in
 * TABS array order, and a tab's contents are what its own fillItemList
 * appends to a fresh list. Tab ids come from the tab's langId field with
 * the vanilla mapping ("buildingBlocks" -> building_blocks, "misc" ->
 * miscellaneous, ...); the search tab (TAB_SEARCH) also carries every
 * stack's creative tooltip lines and item tags, the inputs of the client's
 * creative search trees (SessionSearchTrees).
 *
 * There are no permissions builds on this pin: fillItemList is
 * unconditional, so no permissions_only / visible fields are exported —
 * the Rust reader treats their absence as "everything is listed".
 *
 *   VanillaCreativeTabsExporter OUT.json
 */
public final class VanillaCreativeTabsExporter {
    // ParityData is resolved from the sourcepath at compile time.
    public static void main(String[] args) throws Exception {
        ParityData.init();
        Files.writeString(Path.of(args[0]), export().toString(), StandardCharsets.UTF_8);
    }

    /** CreativeModeTab's langId -> the registry-style tab id. */
    private static String tabId(String langId) {
        return switch (langId) {
            case "buildingBlocks" -> "minecraft:building_blocks";
            case "decorations" -> "minecraft:decorations";
            case "redstone" -> "minecraft:redstone";
            case "transportation" -> "minecraft:transportation";
            case "misc" -> "minecraft:miscellaneous";
            case "search" -> "minecraft:search";
            case "food" -> "minecraft:food";
            case "tools" -> "minecraft:tools";
            case "combat" -> "minecraft:combat";
            case "brewing" -> "minecraft:brewing";
            case "materials" -> "minecraft:materials";
            case "hotbar" -> "minecraft:hotbar";
            case "inventory" -> "minecraft:inventory";
            default -> "minecraft:" + langId;
        };
    }

    private static List<ItemStack> contents(CreativeModeTab tab) {
        var list = NonNullList.<ItemStack>create();
        try {
            tab.fillItemList(list);
        } catch (RuntimeException e) {
            // 1.19.2: the hotbar tab's fillItemList is a client-side
            // stub ("Implement exception client-side.") — its contents
            // are the player's locally saved hotbars, not game data,
            // so the era-true export is the empty list a fresh
            // profile shows. (Runtime-probed on this jar: hotbar is
            // the only throwing tab; search fills 1405, inventory is
            // a no-op fill.) Anything else is a real failure.
            if (!"Implement exception client-side.".equals(e.getMessage())) throw e;
        }
        return list;
    }

    public static JsonObject export() throws Exception {
        Field langIdField = CreativeModeTab.class.getDeclaredField("langId");
        langIdField.setAccessible(true);
        var tabs = new JsonArray();
        for (CreativeModeTab tab : CreativeModeTab.TABS) {
            String langId = (String) langIdField.get(tab);
            var items = contents(tab);
            var o = new JsonObject();
            o.addProperty("id", tabId(langId));
            // TAB_SEARCH doubles as the client's search tab and
            // TAB_INVENTORY as its survival-inventory tab; every other
            // tab is a category tab.
            o.addProperty("type", langId.equals("search") ? "SEARCH"
                : langId.equals("inventory") ? "INVENTORY" : "CATEGORY");
            o.addProperty("row", tab.isTopRow() ? "TOP" : "BOTTOM");
            o.addProperty("column", tab.getColumn());
            o.addProperty("title", tab.getDisplayName().getString());
            o.addProperty("icon", snbt(tab.getIconItem()));
            var arr = new JsonArray();
            for (ItemStack stack : items) arr.add(snbt(stack));
            o.add("items", arr);
            if (langId.equals("search")) {
                var lines = new JsonArray();
                var tags = new JsonArray();
                for (ItemStack stack : items) {
                    lines.add(strings(tooltipLines(stack, TooltipFlag.Default.NORMAL)));
                    tags.add(strings(itemTags(stack.getItem())));
                }
                o.add("lines", lines);
                o.add("tags", tags);
            }
            tabs.add(o);
        }
        var out = new JsonObject();
        out.addProperty("schema", 3);
        out.add("tabs", tabs);
        return out;
    }

    /** SessionSearchTrees.getTooltipLines for one stack. */
    public static List<String> tooltipLines(ItemStack stack, TooltipFlag flag) {
        return stack.getTooltipLines(null, flag).stream()
            .map(Component::getString)
            .map(l -> ChatFormatting.stripFormatting(l).trim())
            .filter(s -> !s.isEmpty())
            .toList();
    }

    /** ItemStack as SNBT (the form horizon_client::item_data::parse_stack reads). */
    public static String snbt(ItemStack stack) {
        if (stack.isEmpty()) return "-";
        return ParityData.canon(stack);
    }

    /** 1.18.1: no ItemStack.getTags() (it arrives in 1.18.2 with
     * the Holder system) — an item's tags are its matches in the
     * item registry's bound tag collection, held by its
     * StaticTagHelper. */
    private static List<String> itemTags(Item item) {
        var found = new ArrayList<String>();
        net.minecraft.tags.StaticTags.visitHelpers(helper -> {
            if (helper.getKey().equals(Registry.ITEM_REGISTRY)) {
                @SuppressWarnings("unchecked")
                var collection = (net.minecraft.tags.TagCollection<Item>) (Object) helper.getAllTags();
                collection.getMatchingTags(item).forEach(id -> found.add(id.toString()));
            }
        });
        return found;
    }

    private static JsonArray strings(List<String> values) {
        var a = new JsonArray();
        values.forEach(a::add);
        return a;
    }
}
