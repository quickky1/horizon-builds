package dev.horizonlab.parity;

import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.core.*;
import net.minecraft.nbt.*;
import net.minecraft.server.Bootstrap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.ServerPacksSource;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.resources.SimpleReloadableResourceManager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Shared set-up for the interaction/inventory parity oracles: the vanilla data
 * pack loaded into registries (as the server does), an NBT registry ops, a
 * stand-in ServerLevel that only answers registryAccess, and canonical text
 * for item stacks and NBT so both sides print comparable lines.
 */
public final class ParityData {
    // 1.19.2: no HolderLookup.Provider (that arrives in 1.19.3) — the
    // registry access itself is the lookup surface, and RegistryOps is
    // built straight from it. The field keeps the `lookup` name: the
    // era-1.19.2 callers (RecipeManager's no-arg ctor is later — the
    // RecipeManager(RegistryAccess) forms, Item.TooltipContext.of,
    // HotbarManager.load/save) all take a RegistryAccess here.
    public static RegistryAccess lookup;
    public static RegistryAccess access;
    // 1.18.1: no RegistryOps (it arrives in 1.18.2) — the era's
    // registry-aware ops do not exist, and plain NbtOps is what the
    // tag codecs of this version serialize through.
    public static com.mojang.serialization.DynamicOps<Tag> ops;
    public static ServerLevel level;
    /** The loot tables of the vanilla data pack (1.19.4: the
     * resources' LootTables — the consolidated LootDataManager
     * arrives in 1.20.2, and the registry-backed holder form with
     * ReloadableServerRegistries in 1.20.5). */
    public static net.minecraft.world.level.storage.loot.LootTables loot;

    public static void init() throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        var repo = new PackRepository(PackType.SERVER_DATA, new ServerPacksSource());
        repo.reload();
        repo.setSelected(List.of("vanilla"));
        // 1.18.1: no MultiPackResourceManager (it arrives in 1.18.2) —
        // packs are added to a SimpleReloadableResourceManager one by one.
        var resources = new SimpleReloadableResourceManager(PackType.SERVER_DATA);
        repo.openAllSelected().forEach(resources::add);
        // 1.19.2: no RegistryLayer / RegistryDataLoader / feature
        // flags (all arrive in 1.19.3) — the worldgen registries load
        // straight into a builtin copy through RegistryAccess.load with
        // a RegistryLoader (its constructor is package-private, so it
        // is built reflectively, as in VanillaCommandParseOracle),
        // then the copy is frozen. Loot tables live in the resources'
        // LootTables via ReloadableServerResources.
        // 1.18.1: the pre-Writable registry model — builtin() hands
        // back the mutable RegistryHolder, datapack registries load
        // through RegistryReadOps.createAndLoad, ServerResources
        // takes the selected pack list, and tags bind inside its own
        // reload (the Writable/Frozen split, RegistryLoader and
        // ReloadableServerResources all arrive in 1.18.2).
        RegistryAccess.RegistryHolder holder = RegistryAccess.builtin();
        net.minecraft.resources.RegistryReadOps.createAndLoad(
            com.mojang.serialization.JsonOps.INSTANCE, resources, holder);
        lookup = holder;
        access = holder;
        var managers = net.minecraft.server.ServerResources.loadResources(
            repo.openAllSelected(), holder,
            net.minecraft.commands.Commands.CommandSelection.INTEGRATED, 4, Runnable::run, Runnable::run).join();
        loot = managers.getLootTables();
        ops = NbtOps.INSTANCE;
        var unsafeField = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
        unsafeField.setAccessible(true);
        Object unsafe = unsafeField.get(null);
        level = (ServerLevel) unsafe.getClass().getMethod("allocateInstance", Class.class).invoke(unsafe, ServerLevel.class);
        // 1.19.2: Level carries no registryAccess field — ServerLevel
        // .registryAccess() delegates to its server, and the server's
        // registryAccess() reads its `registryHolder` field (the
        // layered RegistryLayer form arrives in 1.19.3). Give the fake
        // level a stub server carrying the frozen access.
        var stubServer = (net.minecraft.server.MinecraftServer) unsafe.getClass().getMethod("allocateInstance", Class.class).invoke(unsafe, net.minecraft.server.dedicated.DedicatedServer.class); // MinecraftServer itself is abstract in 1.19.2; DedicatedServer is its concrete server-side subclass
        Field registryHolder = net.minecraft.server.MinecraftServer.class.getDeclaredField("registryHolder");
        registryHolder.setAccessible(true);
        long holderOffset = (long) unsafe.getClass().getMethod("objectFieldOffset", Field.class).invoke(unsafe, registryHolder);
        unsafe.getClass().getMethod("putObject", Object.class, long.class, Object.class).invoke(unsafe, stubServer, holderOffset, holder);
        Field serverField = ServerLevel.class.getDeclaredField("server");
        serverField.setAccessible(true);
        long serverOffset = (long) unsafe.getClass().getMethod("objectFieldOffset", Field.class).invoke(unsafe, serverField);
        unsafe.getClass().getMethod("putObject", Object.class, long.class, Object.class).invoke(unsafe, level, serverOffset, stubServer);
    }

    /** "-" is the empty stack; otherwise the stack's NBT form
     * ({id, Count, tag}) over SNBT — 1.20.4 has no ItemStack.CODEC
     * (that arrives with data components in 1.20.5). */
    public static ItemStack stack(String snbt) throws Exception {
        if (snbt.equals("-")) return ItemStack.EMPTY;
        Tag tag = TagParser.parseTag(snbt);
        return ItemStack.of((CompoundTag) tag);
    }

    public static String canon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "-";
        Tag tag = stack.save(new CompoundTag());
        return canon(tag);
    }

    /** Sorted-key, type-annotated text of an NBT tag. */
    public static String canon(Tag tag) {
        StringBuilder out = new StringBuilder();
        canon(tag, out);
        return out.toString();
    }

    private static void canon(Tag tag, StringBuilder out) {
        // Switch patterns are preview-only on Java 17; instanceof
        // patterns are standard, so the chain is spelled out.
        if (tag instanceof ByteTag t) {
            out.append(t.getAsByte()).append('b');
        } else if (tag instanceof ShortTag t) {
            out.append(t.getAsShort()).append('s');
        } else if (tag instanceof IntTag t) {
            out.append(t.getAsInt());
        } else if (tag instanceof LongTag t) {
            out.append(t.getAsLong()).append('L');
        } else if (tag instanceof FloatTag t) {
            out.append(t.getAsFloat()).append('f');
        } else if (tag instanceof DoubleTag t) {
            out.append(t.getAsDouble()).append('d');
        } else if (tag instanceof StringTag t) {
            out.append('"').append(t.getAsString().replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
        } else if (tag instanceof ByteArrayTag t) {
            out.append("[B;");
            byte[] a = t.getAsByteArray();
            for (int i = 0; i < a.length; i++) out.append(i > 0 ? "," : "").append(a[i]);
            out.append(']');
        } else if (tag instanceof IntArrayTag t) {
            out.append("[I;");
            int[] a = t.getAsIntArray();
            for (int i = 0; i < a.length; i++) out.append(i > 0 ? "," : "").append(a[i]);
            out.append(']');
        } else if (tag instanceof LongArrayTag t) {
            out.append("[L;");
            long[] a = t.getAsLongArray();
            for (int i = 0; i < a.length; i++) out.append(i > 0 ? "," : "").append(a[i]);
            out.append(']');
        } else if (tag instanceof ListTag t) {
            out.append('[');
            for (int i = 0; i < t.size(); i++) {
                if (i > 0) out.append(',');
                canon(t.get(i), out);
            }
            out.append(']');
        } else if (tag instanceof CompoundTag t) {
            out.append('{');
            boolean first = true;
            for (String key : new TreeSet<>(t.getAllKeys())) {
                if (!first) out.append(',');
                first = false;
                out.append(key).append(':');
                canon(t.get(key), out);
            }
            out.append('}');
        } else {
            throw new IllegalStateException(tag.toString());
        }
    }
}
