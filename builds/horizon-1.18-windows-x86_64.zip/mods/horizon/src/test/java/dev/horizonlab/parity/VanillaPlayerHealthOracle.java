package dev.horizonlab.parity;
import com.google.gson.*;import java.io.*;import java.lang.reflect.*;import java.nio.file.*;import java.util.*;
import net.minecraft.core.*;import net.minecraft.resources.ResourceLocation;import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.entity.ai.attributes.*;import net.minecraft.network.syncher.*;
/** Actual player health/absorption on one native synchronized table. */
public final class VanillaPlayerHealthOracle {
    static final class Stop extends RuntimeException {}
    static EntityDataAccessor<Float> healthKey,absorptionKey;
    static float single(JsonElement v){return Float.intBitsToFloat(Integer.parseUnsignedInt(v.getAsString(),16));}
    static double number(JsonElement v){return Double.longBitsToDouble(Long.parseUnsignedLong(v.getAsString(),16));}
    static String bits(float v){return String.format("%08x",Float.floatToIntBits(v));}
    // 1.19.2: SynchedEntityData has no DataValue record (it arrives in
    // 1.19.3) and no getNonDefaultValues(); the values that differ are
    // tracked on DataItem objects, and "not default" is the item's value
    // differing from the value it was defined with.
    static String values(List<SynchedEntityData.DataItem<?>> values){if(values==null)return "none";var s=new StringJoiner(",");for(var v:values)s.add(v.getAccessor().getId()+":"+bits((Float)v.getValue()));return s.length()==0?"empty":s.toString();}
    static Field field(Class<?> c,String n)throws Exception{var f=c.getDeclaredField(n);f.setAccessible(true);return f;}
    static final class Data {JsonObject op;PrintWriter out;AttributeMap attributes;SynchedEntityData data;int calls;
        void event(String s){out.println(s);if(calls++==op.get("fail").getAsInt())throw new Stop();}}
    static final class Actor extends Player {Data d;Actor(){super(null,null,0f,null);} /* 1.18.2: Player's constructor has no ProfilePublicKey parameter (profile keys arrive in 1.19) */ @Override public boolean isCreative(){return false;} @Override public boolean isSpectator(){return false;}
        // 1.19.2: attributes are plain Attribute objects (Holder<Attribute>
        // arrives in 1.19.3), so only the plain form exists here.
        @Override public double getAttributeValue(Attribute a){return d.attributes.getValue(a);}
        @Override public void onSyncedDataUpdated(EntityDataAccessor<?> a){var key=a.getId()==healthKey.getId()?healthKey:absorptionKey;d.event("updated "+key.getId()+" "+bits(d.data.get(key))+" "+d.data.isDirty());if(d.op.get("pack_callback").getAsBoolean())d.out.println("callback-pack "+values(d.data.packDirty()));}
        // 1.19.3: Entity has no batch onSyncedDataUpdated(List) callback
        // (it arrives in 1.19.4) — SynchedEntityData.assignValues notifies
        // per accessor (bytecode-verified), so an "assign" op traces one
        // "updated" event per value on this pin instead of one "assigned".
    }
    static void addOrUpdate(AttributeInstance inst,AttributeModifier mod){if(inst.getModifier(mod.getId())!=null)inst.removeModifier(mod.getId());inst.addTransientModifier(mod);}
    @SuppressWarnings("unchecked") public static void main(String[] args)throws Exception {
        Path dir=Path.of(args[1]);if(args[0].equals("export"))VanillaEntityAttributeOracle.main(args);else{net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();}
        healthKey=(EntityDataAccessor<Float>)field(LivingEntity.class,"DATA_HEALTH_ID").get(null);absorptionKey=(EntityDataAccessor<Float>)field(Player.class,"DATA_PLAYER_ABSORPTION_ID").get(null);if(args[0].equals("export")){var ids=new JsonObject();ids.addProperty("health",healthKey.getId());ids.addProperty("absorption",absorptionKey.getId());Files.writeString(dir.resolve("ids.json"),ids.toString());return;}
        var u=Class.forName("sun.misc.Unsafe");var uf=u.getDeclaredField("theUnsafe");uf.setAccessible(true);var unsafe=uf.get(null);var allocate=u.getMethod("allocateInstance",Class.class);var storage=field(Entity.class,"entityData");var dead=field(LivingEntity.class,"dead");var keys=List.of(Attributes.MAX_HEALTH,Attributes.MAX_HEALTH); // 1.19.2: generic.max_absorption does not exist (it arrives in 1.20.2); attribute 1 in the harness feeds LivingEntity's health logic, which reads MAX_HEALTH.
        try(var out=new PrintWriter(Files.newBufferedWriter(dir.resolve(args[0]+".txt")));var lines=Files.lines(dir.resolve("inputs.txt"))){for(var line:(Iterable<String>)lines::iterator){var f=JsonParser.parseString(line).getAsJsonObject();var d=new Data();d.out=out;d.attributes=new AttributeMap(VanillaEntityAttributeOracle.supplier(Registry.ENTITY_TYPE.get(ResourceLocation.tryParse("minecraft:player"))));var actor=(Actor)allocate.invoke(unsafe,Actor.class);actor.d=d;
            d.data=new SynchedEntityData(actor);d.data.define(healthKey,single(f.get("health")));d.data.define(absorptionKey,single(f.get("absorption")));var byId=(it.unimi.dsi.fastutil.ints.Int2ObjectMap<SynchedEntityData.DataItem<?>>)field(SynchedEntityData.class,"itemsById").get(d.data);var health=(SynchedEntityData.DataItem<Float>)byId.get(healthKey.getId());var absorption=(SynchedEntityData.DataItem<Float>)byId.get(absorptionKey.getId());var healthDefault=health.getValue();var absorptionDefault=absorption.getValue();storage.set(actor,d.data);dead.setBoolean(actor,f.get("dead").getAsBoolean());
            for(var ov:f.getAsJsonArray("ops")){var op=ov.getAsJsonObject();d.op=op;d.calls=0;var key=keys.get(op.get("attribute").getAsInt());float v=single(op.get("value"));try{switch(op.get("mode").getAsString()){
                case "set":actor.setHealth(v);break;case "heal":actor.heal(v);break;case "absorption":actor.setAbsorptionAmount(v);break;case "get-absorption":out.println("float "+bits(actor.getAbsorptionAmount()));break;
                case "hurt":out.println("bool "+actor.isHurt());break;case "dead":out.println("bool "+actor.isDeadOrDying());break;
                case "base":d.attributes.getInstance(key).setBaseValue(number(op.get("amount")));break;
                case "add":addOrUpdate(d.attributes.getInstance(key),new AttributeModifier(java.util.UUID.nameUUIDFromBytes(op.get("id").getAsString().getBytes(java.nio.charset.StandardCharsets.UTF_8)),op.get("id").getAsString(),number(op.get("amount")),AttributeModifier.Operation.values()[op.get("operation").getAsInt()]));break;
                case "remove":d.attributes.getInstance(key).removeModifier(java.util.UUID.nameUUIDFromBytes(op.get("id").getAsString().getBytes(java.nio.charset.StandardCharsets.UTF_8)));break;case "reset":{var inst=d.attributes.getInstance(key);if(inst!=null)inst.setBaseValue(key.getDefaultValue());break;}
                case "pack":out.println("packed "+values(d.data.packDirty()));break;case "defaults":{var nd=new ArrayList<SynchedEntityData.DataItem<?>>();if(!health.getValue().equals(healthDefault))nd.add(health);if(!absorption.getValue().equals(absorptionDefault))nd.add(absorption);nd.sort(Comparator.comparingInt(i->i.getAccessor().getId()));out.println("defaults "+values(nd));break;}
                case "assign":{var data=new ArrayList<SynchedEntityData.DataItem<?>>();for(var x:op.getAsJsonArray("values")){var e=x.getAsJsonObject();data.add(new SynchedEntityData.DataItem<Float>(e.get("field").getAsInt()==0?healthKey:absorptionKey,single(e.get("value"))));}d.data.assignValues(data);break;}
                default:throw new AssertionError();}out.println("result ok");}catch(Stop e){out.println("result error");}
                out.println("state "+bits(health.getValue())+" "+bits(absorption.getValue())+" "+d.data.isDirty()+" "+health.isDirty()+" "+absorption.isDirty()+" "+health.getValue().equals(healthDefault)+" "+absorption.getValue().equals(absorptionDefault)+" "+d.calls);
            }
        }}
    }
}
