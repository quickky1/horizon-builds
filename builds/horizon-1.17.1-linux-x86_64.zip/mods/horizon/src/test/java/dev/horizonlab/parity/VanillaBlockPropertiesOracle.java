package dev.horizonlab.parity;
import com.google.gson.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import net.minecraft.core.Registry;
import net.minecraft.core.Direction;
import net.minecraft.nbt.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.*;
/** Imports definition inputs only; vanilla computes the independently compared solidity results. */
public final class VanillaBlockPropertiesOracle {
    private static Field field(Class<?> cls,String name) throws Exception {var f=cls.getDeclaredField(name);f.setAccessible(true);return f;}
    // 1.19.4: the force-solid properties (forceSolidOn/forceSolidOff)
    // and BlockStateBase.calculateSolid arrive in 1.20. On this pin
    // the flags read as permanently false — no block can force
    // solidity either way — and the compare branch reports the solid
    // query as unsupported rather than inventing a vanilla answer.
    private static Field optField(Class<?> cls,String name) {try {var f=cls.getDeclaredField(name);f.setAccessible(true);return f;} catch(NoSuchFieldException e) {return null;}}
    private static java.lang.reflect.Method optMethod(Class<?> cls,String name) {try {return cls.getDeclaredMethod(name);} catch(NoSuchMethodException e) {return null;}}
    private static boolean flag(Field f,Object o) throws Exception {return f!=null&&f.getBoolean(o);}
    private static void flag(Field f,Object o,boolean v) throws Exception {if(f!=null)f.setBoolean(o,v);}
    private static VoxelShape shape(JsonElement value) {
        var a=value.getAsJsonArray();double[] v=new double[6];for(int i=0;i<6;i++)v[i]=Double.longBitsToDouble(Long.parseUnsignedLong(a.get(i).getAsString(),16));
        return Shapes.create(new AABB(v[0],v[1],v[2],v[3],v[4],v[5]));
    }
    public static void main(String[] args) throws Exception {
        net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();
        var properties=field(BlockBehaviour.class,"properties");var on=optField(BlockBehaviour.Properties.class,"forceSolidOn");var off=optField(BlockBehaviour.Properties.class,"forceSolidOff");var replace=optField(BlockBehaviour.Properties.class,"replaceable");var liquid=optField(BlockBehaviour.Properties.class,"liquid");var occlude=field(BlockBehaviour.Properties.class,"canOcclude");
        var cache=field(BlockBehaviour.BlockStateBase.class,"cache");var collision=field(cache.getType(),"collisionShape");
        var calculate=optMethod(BlockBehaviour.BlockStateBase.class,"calculateSolid");if(calculate!=null)calculate.setAccessible(true);
        Path dir=Path.of(args[1]);
        if(args[0].equals("export")) {
            VanillaCollisionOracle.main(new String[]{"generate",args[1]});
            var states=new ListTag();var blocks=new CompoundTag();
            for(var state:Block.BLOCK_STATE_REGISTRY)states.add(BlockState.CODEC.encodeStart(NbtOps.INSTANCE,state).getOrThrow(false, __err -> { throw new IllegalStateException(__err); }));
            for(var block:Registry.BLOCK) {
                var p=properties.get(block);blocks.putByte(Registry.BLOCK.getKey(block).toString(),(byte)((flag(on,p)?1:0)|(flag(off,p)?2:0)|((replace!=null?flag(replace,p):block.defaultBlockState().getMaterial().isReplaceable())?4:0)|((liquid!=null?flag(liquid,p):block.defaultBlockState().getMaterial().isLiquid())?8:0)|(occlude.getBoolean(p)?16:0)));
            }
            var root=new CompoundTag();root.putInt("DataVersion",net.minecraft.SharedConstants.getCurrentVersion().getWorldVersion());root.put("states",states);root.put("blocks",blocks);root.put("occlusion",VanillaCollisionOracle.occlusionDefinitions());
            try(var out=new DataOutputStream(Files.newOutputStream(dir.resolve("block-properties.nbt")))){NbtIo.write(root,out);}return;
        }
        try(var out=new PrintWriter(Files.newBufferedWriter(dir.resolve(args[0]+".txt")))) {
            for(var state:Block.BLOCK_STATE_REGISTRY) {
                var p=properties.get(state.getBlock());
                // 1.19.2: solidity/liquidity/replaceability live on the
                // Material; there is no no-arg canBeReplaced() here.
                out.printf("state %d %s %s %s %s%n",Block.getId(state),flag(on,p),flag(off,p),state.getMaterial().isReplaceable(),state.getMaterial().isSolid());
                out.printf("render %s %s %s%n",state.getMaterial().isLiquid(),state.canOcclude(),state.isSolidRender(net.minecraft.world.level.EmptyBlockGetter.INSTANCE,net.minecraft.core.BlockPos.ZERO));
                int mask=0;for(var direction:Direction.values())if(Block.isShapeFullBlock(state.getFaceOcclusionShape(net.minecraft.world.level.EmptyBlockGetter.INSTANCE,net.minecraft.core.BlockPos.ZERO,direction)))mask|=1<<direction.ordinal();out.println("occlusion "+mask);
                var c=cache.get(state);var s=c==null?null:(VoxelShape)collision.get(c);
                if(s==null)out.println("cache none");else if(s.isEmpty())out.println("cache empty");else {
                    var b=s.bounds();out.printf("cache %016x %016x %016x %016x %016x %016x%n",Double.doubleToRawLongBits(b.minX),Double.doubleToRawLongBits(b.minY),Double.doubleToRawLongBits(b.minZ),Double.doubleToRawLongBits(b.maxX),Double.doubleToRawLongBits(b.maxY),Double.doubleToRawLongBits(b.maxZ));
                }
            }
            var state=Blocks.STONE.defaultBlockState();var p=properties.get(Blocks.STONE);var savedCache=cache.get(state);var savedShape=collision.get(savedCache);boolean savedOn=flag(on,p),savedOff=flag(off,p);
            try(var inputs=Files.lines(dir.resolve("inputs.txt"))) {
                for(var line:(Iterable<String>)inputs::iterator) {
                    var f=new JsonParser().parse(line).getAsJsonObject();VoxelShape s=Shapes.empty();for(var value:f.getAsJsonArray("shape"))s=Shapes.or(s,shape(value));
                    flag(on,p,f.get("on").getAsBoolean());flag(off,p,f.get("off").getAsBoolean());cache.set(state,f.get("cached").getAsBoolean()?savedCache:null);collision.set(savedCache,s);
                    out.println("solid "+(calculate!=null?calculate.invoke(state):"unsupported-era"));
                    out.println("render "+Block.isShapeFullBlock(f.get("occludes").getAsBoolean()?s:Shapes.empty()));
                    int mask=0;if(f.get("occludes").getAsBoolean())for(var direction:Direction.values())if(Block.isShapeFullBlock(s.getFaceShape(direction)))mask|=1<<direction.ordinal();out.println("occlusion "+mask);
                }
            } finally {cache.set(state,savedCache);collision.set(savedCache,savedShape);flag(on,p,savedOn);flag(off,p,savedOff);}
        }
    }
}
