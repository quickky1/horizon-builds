package dev.horizonlab.parity;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.SharedConstants;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.MultiNoiseBiomeSource;

/** 1.17.1: the datagen biome_parameters report does not exist yet
 * (it arrives in 1.19), so the multi-noise parameter tables the
 * worldgen bundle needs exist only in code. This era's climate
 * model is Biome.ClimateParameters: five point-valued floats
 * (temperature, humidity, altitude, weirdness, offset) -- no
 * Climate.ParameterList, no quantized spans, and no
 * continentalness/erosion/depth dimensions (altitude is the single
 * vertical dimension here). Export them in the report's JSON form
 * with the era's own dimensions, each a bare number (the report's
 * point convention). Preset holds only NETHER on this pin, so the
 * overworld table comes from the same static builder the vanilla
 * overworld biome source uses. */
public class VanillaBiomeParametersExporter {
    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        Path dir = Path.of(args[0]);
        Files.createDirectories(dir);
        write(dir, "overworld", MultiNoiseBiomeSource.overworld(BuiltinRegistries.BIOME, 0L));
        write(dir, "nether", MultiNoiseBiomeSource.Preset.NETHER.biomeSource(BuiltinRegistries.BIOME, 0L));
    }

    private static void write(Path dir, String name, MultiNoiseBiomeSource source) throws Exception {
        var field = MultiNoiseBiomeSource.class.getDeclaredField("parameters");
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        // 1.17.1: the parameter list holds Pair<ClimateParameters,
        // Supplier<Biome>> (no Holder form on this pin).
        var list = (java.util.List<com.mojang.datafixers.util.Pair<Biome.ClimateParameters, java.util.function.Supplier<Biome>>>) field.get(source);
        var biomes = new JsonArray();
        for (var pair : list) {
            var point = pair.getFirst();
            var entry = new JsonObject();
            entry.addProperty("biome", BuiltinRegistries.BIOME.getKey(pair.getSecond().get()).toString());
            var params = new JsonObject();
            params.add("altitude", new JsonPrimitive(read(point, "altitude")));
            params.add("humidity", new JsonPrimitive(read(point, "humidity")));
            params.addProperty("offset", read(point, "offset"));
            params.add("temperature", new JsonPrimitive(read(point, "temperature")));
            params.add("weirdness", new JsonPrimitive(read(point, "weirdness")));
            entry.add("parameters", params);
            biomes.add(entry);
        }
        var root = new JsonObject();
        root.add("biomes", biomes);
        Files.writeString(dir.resolve(name + ".json"), root.toString());
    }

    /* ClimateParameters' five floats are private with no accessors
       on this pin (javap-verified field list); read them by name. */
    private static float read(Biome.ClimateParameters point, String name) throws Exception {
        var f = Biome.ClimateParameters.class.getDeclaredField(name);
        f.setAccessible(true);
        return f.getFloat(point);
    }
}
