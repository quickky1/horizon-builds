package dev.horizonlab.parity;

import com.google.gson.*;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipFile;
import com.mojang.serialization.JsonOps;
import net.minecraft.SharedConstants;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.StaticTags;
import net.minecraft.tags.TagCollection;
import net.minecraft.tags.TagContainer;
import net.minecraft.tags.TagLoader;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.pathfinder.WalkNodeEvaluator;

/**
 * Original exporter of the facts the client's mob AI and renderer read from vanilla code:
 * per-state pathfinding types (WalkNodeEvaluator.getPathTypeFromState), pathfindability,
 * spawn-surface predicates, each entity type's spawn placement, and every keyframe
 * animation definition of the client's entity models.
 */
@SuppressWarnings("unchecked")
public final class VanillaMobDataExporter {
    /** A level holding one block state at the origin and air elsewhere. */
    private record OneBlock(BlockState state) implements BlockGetter {
        public BlockEntity getBlockEntity(BlockPos pos) { return null; }
        public BlockState getBlockState(BlockPos pos) { return pos.equals(BlockPos.ZERO) ? state : Blocks.AIR.defaultBlockState(); }
        public FluidState getFluidState(BlockPos pos) { return getBlockState(pos).getFluidState(); }
        public int getHeight() { return 384; }
        public int getMinBuildHeight() { return -64; }
    }

    private static JsonArray states() throws Exception {
        Method pathType = WalkNodeEvaluator.class.getDeclaredMethod("getBlockPathTypeRaw", BlockGetter.class, BlockPos.class);
        pathType.setAccessible(true);
        var out = new JsonArray();
        var empty = EmptyBlockGetter.INSTANCE;
        for (var state : Block.BLOCK_STATE_REGISTRY) {
            var level = new OneBlock(state);
            var type = (BlockPathTypes) pathType.invoke(null, level, BlockPos.ZERO);
            var shape = state.getCollisionShape(empty, BlockPos.ZERO);
            var o = new JsonArray();
            o.add(type.name());
            int flags = 0;
            if (state.isPathfindable(level, BlockPos.ZERO, PathComputationType.LAND)) flags |= 1;
            if (state.isPathfindable(level, BlockPos.ZERO, PathComputationType.WATER)) flags |= 2;
            if (state.isPathfindable(level, BlockPos.ZERO, PathComputationType.AIR)) flags |= 4;
            if (state.isValidSpawn(empty, BlockPos.ZERO, EntityType.ZOMBIE)) flags |= 8;
            if (state.isValidSpawn(empty, BlockPos.ZERO, EntityType.OCELOT)) flags |= 16;
            if (state.isValidSpawn(empty, BlockPos.ZERO, EntityType.POLAR_BEAR)) flags |= 32;
            if (state.isRedstoneConductor(empty, BlockPos.ZERO)) flags |= 64;
            if (net.minecraft.world.level.NaturalSpawner.isValidEmptySpawnBlock(level, BlockPos.ZERO, state, state.getFluidState(), EntityType.ZOMBIE)) flags |= 128;
            if (state.isFaceSturdy(empty, BlockPos.ZERO, Direction.UP)) flags |= 256;
            // 1.19.4: solidity lives on the state's Material.
            if (state.getMaterial().isSolid()) flags |= 512;
            if (state.isSolidRender(empty, BlockPos.ZERO)) flags |= 1024;
            o.add(flags);
            o.add(shape.isEmpty() ? 0.0 : shape.max(Direction.Axis.Y));
            out.add(o);
        }
        return out;
    }

    private static JsonObject placements() {
        var out = new JsonObject();
        for (var type : Registry.ENTITY_TYPE) {
            var placement = SpawnPlacements.getPlacementType(type);
            String name = placement == SpawnPlacements.Type.ON_GROUND ? "on_ground"
                : placement == SpawnPlacements.Type.IN_WATER ? "in_water"
                : placement == SpawnPlacements.Type.IN_LAVA ? "in_lava" : "no_restrictions";
            var o = new JsonObject();
            o.addProperty("placement", name);
            o.addProperty("heightmap", SpawnPlacements.getHeightmapType(type).getSerializedName());
            out.add(Registry.ENTITY_TYPE.getKey(type).toString(), o);
        }
        return out;
    }

    private static JsonArray vector(com.mojang.math.Vector3f v) {
        var a = new JsonArray();
        a.add(v.x()); a.add(v.y()); a.add(v.z());
        return a;
    }

    // 1.18.2: no keyframe animation system (net.minecraft.client.animation
    // arrives in 1.19 with the warden/frog definitions) — the export is
    // empty on this pin.
    private static JsonObject animations(String clientJar) throws Exception {
        return new JsonObject();
    }

    /** Binds one registry's vanilla tags from the jar's data pack, as a server reload would. */
    private static <T> void bindTags(ZipFile jar, Registry<T> registry, ResourceKey<? extends Registry<T>> key, String folder) throws Exception {
        // 1.18.1: TagLoader over element values (see
        // VanillaHeightmapOracle.bindTags).
        var loader = new TagLoader<T>(id -> registry.getOptional(id), "tags/" + folder);
        // 1.18.2: hand-parsed Tag.Builder form (see VanillaHeightmapOracle).
        var definitions = new HashMap<ResourceLocation, net.minecraft.tags.Tag.Builder>();
        var prefix = "data/minecraft/tags/" + folder + "/";
        var entries = jar.entries();
        while (entries.hasMoreElements()) {
            var entry = entries.nextElement();
            var name = entry.getName();
            if (!name.startsWith(prefix) || !name.endsWith(".json")) continue;
            var text = new String(jar.getInputStream(entry).readAllBytes(), StandardCharsets.UTF_8);
            var builder = net.minecraft.tags.Tag.Builder.tag();
            var file = new JsonParser().parse(text).getAsJsonObject();
            for (var e : file.getAsJsonArray("values")) {
                if (e.isJsonPrimitive()) { var s = e.getAsString(); if (s.startsWith("#")) builder.addTag(new ResourceLocation(s.substring(1)), "vanilla"); else builder.addElement(new ResourceLocation(s), "vanilla"); }
                else { var o = e.getAsJsonObject(); var id = o.get("id").getAsString(); boolean req = !o.has("required") || o.get("required").getAsBoolean(); if (id.startsWith("#")) { if (req) builder.addTag(new ResourceLocation(id.substring(1)), "vanilla"); else builder.addOptionalTag(new ResourceLocation(id.substring(1)), "vanilla"); } else if (req) builder.addElement(new ResourceLocation(id), "vanilla"); else builder.addOptionalElement(new ResourceLocation(id), "vanilla"); }
            }
            definitions.put(ResourceLocation.tryParse("minecraft:" + name.substring(prefix.length(), name.length() - 5)), builder);
        }
        // 1.18.1: bind the built collection through this
        // registry's StaticTagHelper (no Registry.bindTags; it
        // arrives in 1.18.2), leaving other registries' wrappers
        // untouched.
        TagCollection<T> collection = loader.build(definitions);
        var container = new TagContainer.Builder().add(key, collection).build();
        StaticTags.visitHelpers(helper -> { if (helper.getKey().equals(key)) helper.reset(container); });
    }

    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        try (var jar = new ZipFile(args[1])) {
            // The jar's tag directories are plural (tags/blocks,
            // tags/fluids): with the singular names the scan matches
            // nothing, the bound collections come up empty, and the
            // first tag lookup throws "used before it was bound".
            bindTags(jar, Registry.BLOCK, Registry.BLOCK_REGISTRY, "blocks");
            bindTags(jar, Registry.FLUID, Registry.FLUID_REGISTRY, "fluids");
        }
        var result = new JsonObject();
        result.add("states", states());
        result.add("placements", placements());
        result.add("animations", animations(args[1]));
        Files.writeString(Path.of(args[0]), new Gson().toJson(result), StandardCharsets.UTF_8);
    }
}
