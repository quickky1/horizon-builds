package dev.horizonlab.parity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.SharedConstants;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.resources.RegistryWriteOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.levelgen.carver.ConfiguredWorldCarver;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.ConfiguredStructureFeature;
import net.minecraft.world.level.levelgen.feature.structures.StructureTemplatePool;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessorList;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessorType;
import net.minecraft.world.level.levelgen.surfacebuilders.ConfiguredSurfaceBuilder;

/** 1.17.1's data generator emits no worldgen reports (the reports
 * arrive in 1.18 with the datapack worldgen model); the whole
 * configured worldgen set lives in code registries. Encode every
 * entry with its era DIRECT_CODEC under RegistryWriteOps into the
 * reports layout the preparer's fallback reads:
 *   <root>/worldgen/<registry>/<entry path>.json
 *   <root>/dimension_type/<entry path>.json
 * Failures are collected and printed, never silently skipped. */
public class VanillaWorldgenDumpExporter {
    static int written = 0;
    static final List<String> failures = new ArrayList<>();
    static Gson gson;

    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        Path root = Path.of(args[0]);
        RegistryAccess access = RegistryAccess.builtin();
        var ops = RegistryWriteOps.create(JsonOps.INSTANCE, access);
        gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

        dump(root.resolve("worldgen/biome"), BuiltinRegistries.BIOME, Biome.DIRECT_CODEC, ops);
        dump(root.resolve("worldgen/configured_surface_builder"), BuiltinRegistries.CONFIGURED_SURFACE_BUILDER,
                ConfiguredSurfaceBuilder.DIRECT_CODEC, ops);
        dump(root.resolve("worldgen/configured_carver"), BuiltinRegistries.CONFIGURED_CARVER,
                ConfiguredWorldCarver.DIRECT_CODEC, ops);
        dump(root.resolve("worldgen/configured_feature"), BuiltinRegistries.CONFIGURED_FEATURE,
                ConfiguredFeature.DIRECT_CODEC, ops);
        dump(root.resolve("worldgen/configured_structure_feature"), BuiltinRegistries.CONFIGURED_STRUCTURE_FEATURE,
                ConfiguredStructureFeature.DIRECT_CODEC, ops);
        dump(root.resolve("worldgen/noise_settings"), BuiltinRegistries.NOISE_GENERATOR_SETTINGS,
                NoiseGeneratorSettings.DIRECT_CODEC, ops);
        dump(root.resolve("worldgen/template_pool"), BuiltinRegistries.TEMPLATE_POOL,
                StructureTemplatePool.DIRECT_CODEC, ops);
        dumpProcessors(root.resolve("worldgen/processor_list"), ops);
        @SuppressWarnings("rawtypes")
        Registry dimensionTypes = (Registry) access.registry(Registry.DIMENSION_TYPE_REGISTRY).orElseThrow();
        dump(root.resolve("dimension_type"), dimensionTypes, DimensionType.DIRECT_CODEC, ops);

        System.out.println("WORLDGEN DUMP: " + written + " entries written, " + failures.size() + " failures");
        for (String f : failures) {
            System.out.println("FAIL " + f);
        }
        if (!failures.isEmpty()) {
            System.exit(2);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    static void dump(Path dir, Registry registry, Codec codec, RegistryWriteOps<JsonElement> ops) throws Exception {
        for (Object entry : registry) {
            ResourceLocation key = registry.getKey(entry);
            var result = codec.encodeStart(ops, entry);
            if (result.error().isPresent()) {
                failures.add(key + ": " + String.valueOf(result.error().get()));
                continue;
            }
            Path file = dir.resolve(key.getPath() + ".json");
            Files.createDirectories(file.getParent());
            Files.writeString(file, gson.toJson(result.result().get()));
            written++;
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    static void dumpProcessors(Path dir, RegistryWriteOps<JsonElement> ops) throws Exception {
        // StructureProcessorList has no codec of its own on this pin;
        // write the modern {"processors":[...]} form with each
        // processor encoded by its type's codec plus the
        // processor_type dispatch key.
        Method getType = StructureProcessor.class.getDeclaredMethod("getType");
        getType.setAccessible(true);
        for (Object entry : BuiltinRegistries.PROCESSOR_LIST) {
            StructureProcessorList list = (StructureProcessorList) entry;
            ResourceLocation key = BuiltinRegistries.PROCESSOR_LIST.getKey(list);
            try {
                JsonArray arr = new JsonArray();
                for (StructureProcessor p : list.list()) {
                    StructureProcessorType type = (StructureProcessorType) getType.invoke(p);
                    Codec pc = type.codec();
                    var encoded = pc.encodeStart(ops, p);
                    if (encoded.error().isPresent()) {
                        throw new IllegalStateException(String.valueOf(encoded.error().get()));
                    }
                    JsonObject obj = new JsonObject();
                    String typeKey = Registry.STRUCTURE_PROCESSOR.getKey(type).toString();
                    obj.addProperty("processor_type", typeKey);
                    JsonElement encodedEl = (JsonElement) encoded.result().get();
                    if (encodedEl.isJsonObject()) {
                        encodedEl.getAsJsonObject().entrySet().forEach(e -> obj.add(e.getKey(), e.getValue()));
                    } else if (encodedEl.isJsonPrimitive() && encodedEl.getAsJsonPrimitive().isString()
                            && typeKey.equals("minecraft:protected_blocks")) {
                        // The era codec for ProtectedBlocksProcessor
                        // encodes its block tag as the bare location;
                        // the modern form carries it as "value" with
                        // the tag '#' prefix (measured in 1.18.2's
                        // own fossil processor lists).
                        obj.addProperty("value", "#" + encodedEl.getAsString());
                    } else {
                        throw new IllegalStateException("non-object processor encoding for " + typeKey + ": " + encodedEl);
                    }
                    arr.add(obj);
                }
                JsonObject rootObj = new JsonObject();
                rootObj.add("processors", arr);
                Path file = dir.resolve(key.getPath() + ".json");
                Files.createDirectories(file.getParent());
                Files.writeString(file, gson.toJson(rootObj));
                written++;
            } catch (Exception ex) {
                failures.add(key + ": processor " + ex);
            }
        }
    }
}
