package dev.horizonlab.parity;

import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.core.*;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.Heightmap;

/** Original transport calling actual vanilla heightmap and chunk APIs. */
public final class VanillaHeightmapOracle {
    private static final Heightmap.Types[] TYPES=Heightmap.Types.values();
    private static net.minecraft.core.Registry<Biome> factory;
    // 1.21.8 has no PalettedContainerFactory (that is the 1.21.9 palette
    // refactor): ProtoChunk takes the biome registry and fills its sections
    // from it (ChunkAccess.replaceMissingSections -> LevelChunkSection(registry),
    // whose biome container needs registry.getOrThrow(Biomes.PLAINS)). A
    // one-entry MappedRegistry over a reflectively built Biome is enough;
    // only in-memory section storage is exercised, codecs are not invoked.
    private static net.minecraft.core.Registry<Biome> biomeRegistry() {
        try {
            var climateCtor=Class.forName("net.minecraft.world.level.biome.Biome$ClimateSettings").getDeclaredConstructors()[0];climateCtor.setAccessible(true);
            var climate=climateCtor.newInstance(Biome.Precipitation.NONE,0.8f,Biome.TemperatureModifier.NONE,0.5f);
            var ctor=Biome.class.getDeclaredConstructors()[0];ctor.setAccessible(true);
            var biome=(Biome)ctor.newInstance(climate,null,null,null);
            // 1.18.1: MappedRegistry takes (key, lifecycle) only
            // and has no freeze() (both arrive in 1.18.2).
            var registry=new net.minecraft.core.MappedRegistry<Biome>(Registry.BIOME_REGISTRY,com.mojang.serialization.Lifecycle.stable());
            net.minecraft.core.Registry.register(registry,"minecraft:plains",biome);
            return registry;
        } catch(ReflectiveOperationException e) { throw new IllegalStateException(e); }
    }


    private static JsonObject facts() {
        var result=new JsonObject();var states=new JsonArray();var defaults=new JsonObject();
        for(var state:Block.BLOCK_STATE_REGISTRY) {
            var entry=new JsonArray();
            entry.add(Registry.BLOCK.getKey(state.getBlock()).toString());
            entry.add(state.isAir());entry.add(!state.getFluidState().isEmpty());
            entry.add(state.toString());entry.add(BlockState.CODEC.encodeStart(JsonOps.INSTANCE,state).getOrThrow(false, __err -> { throw new IllegalStateException(__err); }));states.add(entry);
        }
        for(var id:new TreeSet<>(Registry.BLOCK.keySet()))
            defaults.addProperty(id.toString(),Block.getId(Registry.BLOCK.get(id).defaultBlockState()));
        result.add("states",states);result.add("defaults",defaults);return result;
    }
    /** The blocks whose states block motion, for versions whose jars carry
        no blocks_motion_in_heightmap tag (26.3 turned this code predicate
        into tag data): a block is in when any of its states blocks motion.
        The no-leaves variant is derived by the preparer from the jar's own
        leaves tag. */
    private static JsonObject motionTags() {
        var motion=new TreeSet<String>();
        for(var block:Registry.BLOCK) {
            for(var state:block.getStateDefinition().getPossibleStates())
                // 1.19.4: no BlockStateBase.blocksMotion() — the fact
                // lives on the state's Material.
                if(state.getMaterial().blocksMotion()) { motion.add(Registry.BLOCK.getKey(block).toString()); break; }
        }
        var values=new JsonArray();motion.forEach(values::add);
        var result=new JsonObject();result.add("minecraft:blocks_motion_in_heightmap",values);return result;
    }
    /** The block tag collection most recently bound by bindTags;
        VanillaMovementRegistryOracle's tag-mode switches rebind
        variants of it. */
    static TagCollection<Block> boundBlockTags;
    /** Binds one built block tag collection into the static
        BlockTags wrappers. 1.18.1: no Registry.bindTags (it arrives
        in 1.18.2 with the Holder system) — the collection reaches
        the wrappers through their StaticTagHelper, reset from a
        one-registry TagContainer (StaticTags.resetAll would also
        empty every other registry's wrappers). */
    static void bindBlockTags(TagCollection<Block> collection) {
        boundBlockTags=collection;
        var container=new TagContainer.Builder().add(Registry.BLOCK_REGISTRY,collection).build();
        StaticTags.visitHelpers(helper->{if(helper.getKey().equals(Registry.BLOCK_REGISTRY))helper.reset(container);});
    }
    static void bindTags(JsonObject resources) {
        var registry=Registry.BLOCK;
        // 1.18.1: TagLoader is over element values, not holders —
        // the lookup is the registry's own Optional getter.
        var loader=new TagLoader<Block>(id->registry.getOptional(id),"tags/block");
        // 1.18.2: no TagFile/EntryWithSource (they arrive in 1.19) —
        // tag files parse by hand into Tag.Builder entries, and the
        // loader's build resolves them against the registry.
        var definitions=new HashMap<ResourceLocation,net.minecraft.tags.Tag.Builder>();
        for(var item:resources.entrySet()) {
            var builder=net.minecraft.tags.Tag.Builder.tag();
            var file=new JsonParser().parse(item.getValue().getAsString()).getAsJsonObject();
            for(var e:file.getAsJsonArray("values")) {
                if(e.isJsonPrimitive()) { var s=e.getAsString(); if(s.startsWith("#"))builder.addTag(new ResourceLocation(s.substring(1)),"vanilla"); else builder.addElement(new ResourceLocation(s),"vanilla"); }
                else { var o=e.getAsJsonObject(); var id=o.get("id").getAsString(); boolean req=!o.has("required")||o.get("required").getAsBoolean(); if(id.startsWith("#")) { if(req)builder.addTag(new ResourceLocation(id.substring(1)),"vanilla"); else builder.addOptionalTag(new ResourceLocation(id.substring(1)),"vanilla"); } else if(req)builder.addElement(new ResourceLocation(id),"vanilla"); else builder.addOptionalElement(new ResourceLocation(id),"vanilla"); }
            }
            definitions.put(ResourceLocation.tryParse(item.getKey()),builder);
        }
        // 1.18.1: TagLoader.build returns the TagCollection
        // itself (the id->tag map form arrives in 1.18.2).
        var collection=loader.build(definitions);
        if(collection.getAllTags().size()!=resources.size())throw new AssertionError("incomplete block tags");
        bindBlockTags(collection);
    }
    private static final class Chunk extends ProtoChunk {
        final List<String> reads=new ArrayList<>();
        final boolean trace;
        Chunk(int min,int height,boolean trace) {
            /* 1.17.1: LevelHeightAccessor has no create() (it arrives
               in 1.18) -- it is an interface with only getHeight() and
               getMinBuildHeight() abstract. ProtoChunk's 3-arg ctor
               builds the section array but leaves the sections null
               (javap-verified), so the fixture fills them with this
               era's 1-arg LevelChunkSection ctor. */
            super(new ChunkPos(0,0),UpgradeData.EMPTY,new LevelHeightAccessor(){
                @Override public int getHeight(){return height;}
                @Override public int getMinBuildHeight(){return min;}
            });
            this.trace=trace;
            var sections=getSections();
            for(int i=0;i<sections.length;i++)sections[i]=new LevelChunkSection(getSectionYFromSectionIndex(i));
        }
        @Override public BlockState getBlockState(BlockPos pos) {
            var state=super.getBlockState(pos);
            if(trace)reads.add("read "+pos.getX()+" "+pos.getY()+" "+pos.getZ()+" "+Block.getId(state));
            return state;
        }
        void write(int x,int y,int z,int id) {
            getSections()[getSectionIndex(y)].setBlockState(x&15,y&15,z&15,Block.stateById(id),false); /* 1.17.1: no ChunkAccess.getSection(int) */
        }
    }
    private static void fixture(JsonObject input,PrintWriter out) {
        int min=input.get("min").getAsInt(),height=input.get("height").getAsInt();
        var chunk=new Chunk(min,height,input.get("trace").getAsBoolean());
        out.println("chunk "+min+" "+height);
        for(var item:input.getAsJsonArray("initial")) {
            var a=item.getAsJsonArray();chunk.write(a.get(0).getAsInt(),a.get(1).getAsInt(),a.get(2).getAsInt(),a.get(3).getAsInt());
        }
        for(var type:TYPES)chunk.getOrCreateHeightmapUnprimed(type);
        for(var item:input.getAsJsonArray("ops")) {
            var a=item.getAsJsonArray();String op=a.get(0).getAsString();
            switch(op) {
                case "set" -> {
                    int x=a.get(1).getAsInt(),y=a.get(2).getAsInt(),z=a.get(3).getAsInt(),id=a.get(4).getAsInt(),mask=a.get(5).getAsInt();
                    chunk.write(x,y,z,id);
                    for(int t=0;t<TYPES.length;t++)if((mask&(1<<t))!=0) {
                        try {out.println("update "+t+" "+chunk.getOrCreateHeightmapUnprimed(TYPES[t]).update(x,y,z,Block.stateById(id)));}
                        catch(RuntimeException e){out.println("update "+t+" error");}
                    }
                }
                case "update" -> {
                    int x=a.get(1).getAsInt(),y=a.get(2).getAsInt(),z=a.get(3).getAsInt(),id=a.get(4).getAsInt(),t=a.get(5).getAsInt();
                    try {out.println("update "+t+" "+chunk.getOrCreateHeightmapUnprimed(TYPES[t]).update(x,y,z,Block.stateById(id)));}
                    catch(RuntimeException e){out.println("update "+t+" error");}
                }
                case "prime" -> {
                    var selected=EnumSet.noneOf(Heightmap.Types.class);int mask=a.get(1).getAsInt();
                    for(int t=0;t<TYPES.length;t++)if((mask&(1<<t))!=0)selected.add(TYPES[t]);
                    Heightmap.primeHeightmaps(chunk,selected);out.println("prime "+mask);
                }
                case "raw" -> {
                    int t=a.get(1).getAsInt();var words=a.get(2).getAsJsonArray();long[] data=new long[words.size()];
                    for(int i=0;i<data.length;i++)data[i]=Long.parseUnsignedLong(words.get(i).getAsString(),16);
                    chunk.getOrCreateHeightmapUnprimed(TYPES[t]).setRawData(chunk,TYPES[t],data);out.println("raw "+t);
                }
                case "query" -> {
                    int x=a.get(1).getAsInt(),z=a.get(2).getAsInt();
                    for(int t=0;t<TYPES.length;t++) {
                        var map=chunk.getOrCreateHeightmapUnprimed(TYPES[t]);
                        try {out.println("height "+t+" "+x+" "+z+" "+map.getFirstAvailable(x,z)+" "+map.getHighestTaken(x,z));}
                        catch(RuntimeException e){out.println("height "+t+" "+x+" "+z+" error");}
                    }
                }
                case "dump" -> {
                    out.println("highest_section "+chunk.getHighestSectionPosition());
                    for(int t=0;t<TYPES.length;t++) {
                        long[] data=chunk.getOrCreateHeightmapUnprimed(TYPES[t]).getRawData();
                        out.println("words "+t+" "+data.length);
                        for(long word:data)out.println(Long.toUnsignedString(word,16));
                    }
                }
                default -> throw new IllegalArgumentException(op);
            }
            for(String read:chunk.reads)out.println(read);chunk.reads.clear();
        }
    }
    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();Bootstrap.bootStrap();
        Path directory=Path.of(args[1]);
        if(args[0].equals("export")) {
            Files.writeString(directory,new Gson().toJson(facts()),StandardCharsets.UTF_8);
            Files.writeString(directory.resolveSibling("motion-tags.json"),new Gson().toJson(motionTags()),StandardCharsets.UTF_8);return;
        }
        factory=biomeRegistry();
        bindTags(new JsonParser().parse(Files.readString(directory.resolve("tags.json"))).getAsJsonObject());
        try(var out=new PrintWriter(Files.newBufferedWriter(directory.resolve(args[0]+".txt"),StandardCharsets.UTF_8))) {
            for(int t=0;t<TYPES.length;t++)out.println("type "+t+" "+TYPES[t].getSerializationKey()+" "+TYPES[t].sendToClient()+" "+TYPES[t].keepAfterWorldgen());
            for(var state:Block.BLOCK_STATE_REGISTRY) {
                int mask=0;for(int t=0;t<TYPES.length;t++)if(TYPES[t].isOpaque().test(state))mask|=1<<t;
                out.println("predicate "+Block.getId(state)+" "+mask);
            }
            for(String line:Files.readAllLines(directory.resolve("inputs.txt")))fixture(new JsonParser().parse(line).getAsJsonObject(),out);
        }
    }
}
