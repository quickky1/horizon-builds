package dev.horizonlab.parity;
import com.google.gson.*;import java.io.*;import java.lang.reflect.*;import java.nio.file.*;import java.util.*;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.*;import net.minecraft.world.damagesource.*;import net.minecraft.world.item.*;import net.minecraft.world.phys.Vec3;
/** Native damage definitions, resolved tags and source query behavior.
 *
 * 1.19.2 era: there is no damage-type registry (DamageType,
 * Registries.DAMAGE_TYPE and the data/minecraft/damage_type resources
 * all arrive in 1.19.4), so the catalog is synthesized from the era's
 * own code: every kind is a DamageSource static or factory product of
 * this jar, its message id and food exhaustion are read back off the
 * constructed instance, and the flag-backed tag memberships are the
 * instance flags themselves. Scaling / hurt effects / death-message
 * type have no per-kind data in 1.19.2 (difficulty scaling is the
 * EntityDamageSource living-non-player rule plus the plain-source
 * flag; the rest is chosen in LivingEntity/DamageSource code), so
 * those three columns carry the values Mojang's own 1.19.4 migration
 * assigned the same kinds, listed explicitly in KINDS. Verified
 * against the instances: every message id matches the migration's,
 * and so does every exhaustion but one — IN_FIRE reads 0.0 here
 * because the 1.19.2 static bypasses armour (bypassArmor() also
 * zeroes the exhaustion), where the 1.19.4 migration dropped it from
 * bypasses_armor and set its exhaustion to 0.1; the era values are
 * kept for both. The flag tags match the 1.19.4 memberships
 * everywhere except is_projectile, which in 1.19.4 adds
 * mob_projectile: the 1.19.2 indirectMobAttack factory never sets
 * the projectile flag. The unattributed fireball kind is the
 * fireball factory's null-shooter branch (message id "onFire").
 * The export also
 * overwrites the extracted types.json/tags.json (both empty objects
 * on this pin: the jar has no damage resources) with the synthesized
 * resources, so prepare's copies carry the era data. */
public final class VanillaDamageSourceOracle {
    static final class Stop extends RuntimeException {}
    static Object unsafe;static Method allocate;
    static <T>T make(Class<T> c)throws Exception{return c.cast(allocate.invoke(unsafe,c));}
    static double number(JsonElement v){return Double.longBitsToDouble(Long.parseUnsignedLong(v.getAsString(),16));}
    static Vec3 position(JsonElement v){var a=v.getAsJsonArray();return new Vec3(number(a.get(0)),number(a.get(1)),number(a.get(2)));}
    static String bits(float v){return String.format("%08x",Float.floatToIntBits(v));}
    static String vec(Vec3 v){return v==null?"none":String.format("%016x %016x %016x",Double.doubleToLongBits(v.x),Double.doubleToLongBits(v.y),Double.doubleToLongBits(v.z));}
    // id, message id, scaling, effects, death message type — sorted by id.
    static final String[][] KINDS={
        {"minecraft:arrow","arrow","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:bad_respawn_point","badRespawnPoint","always","hurt","intentional_game_design"},
        {"minecraft:cactus","cactus","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:cramming","cramming","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:dragon_breath","dragonBreath","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:drown","drown","when_caused_by_living_non_player","drowning","default"},
        {"minecraft:dry_out","dryout","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:explosion","explosion","always","hurt","default"},
        {"minecraft:fall","fall","when_caused_by_living_non_player","hurt","fall_variants"},
        {"minecraft:falling_anvil","anvil","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:falling_block","fallingBlock","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:falling_stalactite","fallingStalactite","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:fireball","fireball","when_caused_by_living_non_player","burning","default"},
        {"minecraft:fireworks","fireworks","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:fly_into_wall","flyIntoWall","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:freeze","freeze","when_caused_by_living_non_player","freezing","default"},
        {"minecraft:generic","generic","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:hot_floor","hotFloor","when_caused_by_living_non_player","burning","default"},
        {"minecraft:in_fire","inFire","when_caused_by_living_non_player","burning","default"},
        {"minecraft:in_wall","inWall","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:indirect_magic","indirectMagic","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:lava","lava","when_caused_by_living_non_player","burning","default"},
        {"minecraft:lightning_bolt","lightningBolt","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:magic","magic","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:mob_attack","mob","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:mob_attack_no_aggro","mob","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:mob_projectile","mob","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:on_fire","onFire","when_caused_by_living_non_player","burning","default"},
        {"minecraft:out_of_world","outOfWorld","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:player_attack","player","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:player_explosion","explosion.player","always","hurt","default"},
        {"minecraft:stalagmite","stalagmite","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:starve","starve","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:sting","sting","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:sweet_berry_bush","sweetBerryBush","when_caused_by_living_non_player","poking","default"},
        {"minecraft:thorns","thorns","when_caused_by_living_non_player","thorns","default"},
        {"minecraft:thrown","thrown","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:trident","trident","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:unattributed_fireball","onFire","when_caused_by_living_non_player","burning","default"},
        {"minecraft:wither","wither","when_caused_by_living_non_player","hurt","default"},
        {"minecraft:wither_skull","witherSkull","when_caused_by_living_non_player","hurt","default"},
    };
    static final Map<String,String[]> KIND=new TreeMap<>();
    static final Map<String,DamageSource> INSTANCES=new TreeMap<>();
    static{for(var k:KINDS)KIND.put(k[0],k);}
    static DamageSource instance(String id)throws Exception{
        return switch(id){
            case "minecraft:in_fire"->DamageSource.IN_FIRE;
            case "minecraft:lightning_bolt"->DamageSource.LIGHTNING_BOLT;
            case "minecraft:on_fire"->DamageSource.ON_FIRE;
            case "minecraft:lava"->DamageSource.LAVA;
            case "minecraft:hot_floor"->DamageSource.HOT_FLOOR;
            case "minecraft:in_wall"->DamageSource.IN_WALL;
            case "minecraft:cramming"->DamageSource.CRAMMING;
            case "minecraft:drown"->DamageSource.DROWN;
            case "minecraft:starve"->DamageSource.STARVE;
            case "minecraft:cactus"->DamageSource.CACTUS;
            case "minecraft:fall"->DamageSource.FALL;
            case "minecraft:fly_into_wall"->DamageSource.FLY_INTO_WALL;
            case "minecraft:out_of_world"->DamageSource.OUT_OF_WORLD;
            case "minecraft:generic"->DamageSource.GENERIC;
            case "minecraft:magic"->DamageSource.MAGIC;
            case "minecraft:wither"->DamageSource.WITHER;
            case "minecraft:dragon_breath"->DamageSource.DRAGON_BREATH;
            case "minecraft:dry_out"->DamageSource.DRY_OUT;
            case "minecraft:sweet_berry_bush"->DamageSource.SWEET_BERRY_BUSH;
            case "minecraft:freeze"->DamageSource.FREEZE;
            case "minecraft:stalagmite"->DamageSource.STALAGMITE;
            // 1.19.2: falling_block / falling_anvil / falling_stalactite
            // are DamageSource statics here (the factories arrive in
            // 1.19.3).
            case "minecraft:falling_block"->DamageSource.FALLING_BLOCK;
            case "minecraft:falling_anvil"->DamageSource.ANVIL;
            case "minecraft:falling_stalactite"->DamageSource.FALLING_STALACTITE;
            case "minecraft:sting"->DamageSource.sting(null);
            case "minecraft:mob_attack"->DamageSource.mobAttack(null);
            case "minecraft:mob_attack_no_aggro"->DamageSource.mobAttack(null).setNoAggro();
            case "minecraft:mob_projectile"->DamageSource.indirectMobAttack(null,null);
            case "minecraft:player_attack"->DamageSource.playerAttack(null);
            case "minecraft:arrow"->DamageSource.arrow(null,null);
            case "minecraft:trident"->DamageSource.trident(null,null);
            case "minecraft:fireworks"->DamageSource.fireworks(null,null);
            // fireball(Fireball, Entity) branches on the shooter:
            // non-null gives the "fireball" message id, null gives
            // "onFire" — the two kinds the 1.19.4 registry later
            // names fireball and unattributed_fireball.
            case "minecraft:fireball"->DamageSource.fireball(null,make(Marker.class));
            case "minecraft:unattributed_fireball"->DamageSource.fireball(null,null);
            case "minecraft:wither_skull"->DamageSource.witherSkull(null,null);
            case "minecraft:thrown"->DamageSource.thrown(null,null);
            case "minecraft:indirect_magic"->DamageSource.indirectMagic(null,null);
            case "minecraft:thorns"->DamageSource.thorns(null);
            // 1.19.2: the explosion(Entity, Entity) factory is gone;
            // DamageSource.explosion(Explosion) reads the explosion's
            // source mob: null mob → plain "explosion" source; a living
            // mob → EntityDamageSource "explosion.player" (bytecode-
            // verified on this jar).
            case "minecraft:explosion"->DamageSource.explosion((net.minecraft.world.level.Explosion)null);
            case "minecraft:player_explosion"->{
                // The Unsafe-allocated Explosion's `source` field is
                // null, which getSourceMob() reads back as the plain
                // "explosion" source — set it to a Living entity
                // first (bytecode: source instanceof LivingEntity →
                // the mob itself; the vanilla Marker entity is NOT
                // a LivingEntity and reads back as no mob).
                var explosion=make(net.minecraft.world.level.Explosion.class);
                var sourceField=net.minecraft.world.level.Explosion.class.getDeclaredField("source");
                sourceField.setAccessible(true);
                sourceField.set(explosion,make(Living.class));
                yield DamageSource.explosion(explosion);
            }
            // 1.19.2: badRespawnPointExplosion() is no-arg; the kind is a
            // plain DamageSource("badRespawnPoint") + scales/explosion
            // flags (the positioned PointDamageSource form is 1.19.3).
            case "minecraft:bad_respawn_point"->DamageSource.badRespawnPointExplosion();
            default->throw new AssertionError(id);
        };
    }
    static void buildInstances()throws Exception{for(var id:KIND.keySet())INSTANCES.put(id,instance(id));}
    // Tag memberships with no instance flag behind them: the 1.19.4
    // migration's lists, restricted to the kinds above.
    static final String[][] LITERAL_TAGS={
        {"minecraft:always_hurts_ender_dragons","#minecraft:is_explosion"},
        {"minecraft:always_most_significant_fall","minecraft:out_of_world"},
        {"minecraft:always_triggers_silverfish","minecraft:magic"},
        {"minecraft:avoids_guardian_thorns","minecraft:magic,minecraft:thorns,#minecraft:is_explosion"},
        {"minecraft:burns_armor_stands","minecraft:on_fire"},
        {"minecraft:bypasses_effects","minecraft:starve"},
        {"minecraft:bypasses_resistance","minecraft:out_of_world"},
        {"minecraft:bypasses_shield","#minecraft:bypasses_armor,minecraft:falling_anvil,minecraft:falling_stalactite"},
        {"minecraft:ignites_armor_stands","minecraft:in_fire"},
        {"minecraft:is_drowning","minecraft:drown"},
        {"minecraft:is_freezing","minecraft:freeze"},
        {"minecraft:is_lightning","minecraft:lightning_bolt"},
        {"minecraft:no_impact","minecraft:drown"},
        {"minecraft:witch_resistant_to","minecraft:magic,minecraft:indirect_magic,minecraft:thorns"}, // 1.18.2: no sonic boom (the warden arrives in 1.19)
        {"minecraft:wither_immune_to","minecraft:drown"},
    };
    static Map<String,List<String>> eraTags(){
        var tags=new TreeMap<String,List<String>>();
        java.util.function.Function<java.util.function.Predicate<DamageSource>,List<String>> byFlag=p->{var out=new ArrayList<String>();for(var e:INSTANCES.entrySet())if(p.test(e.getValue()))out.add(e.getKey());return out;};
        tags.put("minecraft:bypasses_armor",byFlag.apply(DamageSource::isBypassArmor));
        tags.put("minecraft:bypasses_enchantments",byFlag.apply(DamageSource::isBypassMagic)); // 1.18.2: no isBypassEnchantments — the bypassMagic flag is the era fact (the split arrives later)
        tags.put("minecraft:bypasses_invulnerability",byFlag.apply(DamageSource::isBypassInvul));
        tags.put("minecraft:damages_helmet",byFlag.apply(DamageSource::isDamageHelmet));
        tags.put("minecraft:is_explosion",byFlag.apply(DamageSource::isExplosion));
        tags.put("minecraft:is_fall",byFlag.apply(DamageSource::isFall));
        tags.put("minecraft:is_fire",byFlag.apply(DamageSource::isFire));
        tags.put("minecraft:is_projectile",byFlag.apply(DamageSource::isProjectile));
        tags.put("minecraft:no_anger",byFlag.apply(DamageSource::isNoAggro));
        for(var t:LITERAL_TAGS)tags.put(t[0],List.of(t[1].split(",")));
        return tags;
    }
    static boolean member(Map<String,List<String>> tags,String tag,String kind,Set<String> seen){
        if(!seen.add(tag))return false;var values=tags.get(tag);if(values==null)return false;
        for(var v:values){if(v.equals(kind))return true;if(v.startsWith("#")&&member(tags,v.substring(1),kind,seen))return true;}
        return false;
    }
    static Map<String,List<String>> parseTags(JsonObject resources){
        var tags=new TreeMap<String,List<String>>();
        for(var e:resources.entrySet()){var values=new ArrayList<String>();for(var v:new JsonParser().parse(e.getValue().getAsString()).getAsJsonObject().getAsJsonArray("values"))values.add(v.isJsonObject()?v.getAsJsonObject().get("id").getAsString():v.getAsString());tags.put(e.getKey(),values);}
        return tags;
    }
    static final class Data {JsonObject f;PrintWriter out;int calls;boolean changed;Entity[] entities;
        JsonObject state(){return f.getAsJsonObject(changed?"after":"initial");}void event(String s){out.println(s);int n=calls++;if(n==f.get("fail").getAsInt())throw new Stop();if(n==f.get("mutate_at").getAsInt())changed=true;}
        int id(Entity e){for(int i=0;i<entities.length;i++)if(entities[i]==e)return i;throw new AssertionError();}}
    static final class Source extends DamageSource {Data d;final String kind;final Entity direct,causing;final Vec3 pos;
        Source(String kind,String msgId,Entity direct,Entity causing,Vec3 pos){super(msgId);this.kind=kind;this.direct=direct;this.causing=causing;this.pos=pos;}
        @Override public Entity getEntity(){d.event("entity");return d.f.get("virtual").getAsBoolean()?d.entities[d.state().get("virtual_entity").getAsInt()]:causing;}
        @Override public Entity getDirectEntity(){return direct;}
        @Override public Vec3 getSourcePosition(){return pos!=null?pos:direct!=null?direct.position():null;}
        Entity stored(){return causing;}
        public boolean isDirect(){return getDirectEntity()==stored();}
        public ItemStack getWeaponItem(){Entity e=getDirectEntity();if(e instanceof Other o)return o.getWeaponItem();if(e instanceof Living l)return l.getWeaponItem();if(e instanceof Human h)return h.getWeaponItem();return null;}}
    static final class Other extends net.minecraft.world.entity.Marker {Other(){super(null,null);}
Data d;int id;
        public ItemStack getWeaponItem(){d.event("weapon "+id);return d.state().getAsJsonArray("weapons").get(id).getAsBoolean()?ItemStack.EMPTY:null;}
        @Override public Vec3 position(){d.event("position "+id);return VanillaDamageSourceOracle.position(d.state().getAsJsonArray("positions").get(id));}
    }
    static final class Living extends net.minecraft.world.entity.decoration.ArmorStand {Living(){super(null,null);}
Data d;int id;
        public ItemStack getWeaponItem(){d.event("weapon "+id);return d.state().getAsJsonArray("weapons").get(id).getAsBoolean()?ItemStack.EMPTY:null;}
        @Override public Vec3 position(){d.event("position "+id);return VanillaDamageSourceOracle.position(d.state().getAsJsonArray("positions").get(id));}
    }
    static final class Human extends Player {Human(){super(null,null,0f,null);} // 1.18.2: no ProfilePublicKey constructor parameter
Data d;int id;
        public ItemStack getWeaponItem(){d.event("weapon "+id);return d.state().getAsJsonArray("weapons").get(id).getAsBoolean()?ItemStack.EMPTY:null;}
        @Override public Vec3 position(){d.event("position "+id);return VanillaDamageSourceOracle.position(d.state().getAsJsonArray("positions").get(id));}
        @Override public boolean isCreative(){return getAbilities().instabuild;} @Override public boolean isSpectator(){return false;}
        @Override public Abilities getAbilities(){d.event("abilities "+id);var a=new Abilities();a.instabuild=d.state().getAsJsonArray("creative").get(id).getAsBoolean();return a;}
    }
    static void export(Path dir)throws Exception{
        buildInstances();
        var root=new JsonObject();root.addProperty("data_version",net.minecraft.SharedConstants.getCurrentVersion().getWorldVersion());var types=new JsonArray();
        var resources=new JsonObject();
        for(var e:KIND.entrySet()){var id=e.getKey();var k=e.getValue();var s=INSTANCES.get(id);
            if(!s.getMsgId().equals(k[1]))throw new AssertionError(id+" msgId "+s.getMsgId()+" != "+k[1]);
            var d=new JsonObject();d.addProperty("id",id);d.addProperty("message_id",k[1]);d.addProperty("exhaustion",bits(s.getFoodExhaustion()));d.addProperty("scaling",k[2]);d.addProperty("effects",k[3]);d.addProperty("death_message_type",k[4]);types.add(d);
            var r=new JsonObject();r.addProperty("message_id",k[1]);r.addProperty("exhaustion",s.getFoodExhaustion());r.addProperty("scaling",k[2]);if(!k[3].equals("hurt"))r.addProperty("effects",k[3]);if(!k[4].equals("default"))r.addProperty("death_message_type",k[4]);resources.addProperty(id,r.toString());}
        root.add("types",types);Files.writeString(dir.resolve("catalog.json"),root.toString());
        Files.writeString(dir.resolve("types.json"),resources.toString());
        var tagResources=new JsonObject();for(var e:eraTags().entrySet()){var file=new JsonObject();var values=new JsonArray();for(var v:e.getValue())values.add(v);file.add("values",values);tagResources.addProperty(e.getKey(),file.toString());}
        Files.writeString(dir.resolve("tags.json"),tagResources.toString());
    }
    public static void main(String[] args)throws Exception{
        net.minecraft.SharedConstants.tryDetectVersion();net.minecraft.server.Bootstrap.bootStrap();Path dir=Path.of(args[1]);
        var u=Class.forName("sun.misc.Unsafe");var uf=u.getDeclaredField("theUnsafe");uf.setAccessible(true);unsafe=uf.get(null);allocate=u.getMethod("allocateInstance",Class.class);
        if(args[0].equals("export")){export(dir);return;}
        buildInstances();var tags=parseTags(new JsonParser().parse(Files.readString(dir.resolve("tags.json"))).getAsJsonObject());var tagNames=new TreeSet<String>();tagNames.addAll(tags.keySet());
        try(var out=new PrintWriter(Files.newBufferedWriter(dir.resolve(args[0]+".txt")));var lines=Files.lines(dir.resolve("inputs.txt"))){
            for(var e:KIND.entrySet()){var id=e.getKey();var k=e.getValue();var s=INSTANCES.get(id);out.println("definition "+id+" "+s.getMsgId()+" "+bits(s.getFoodExhaustion())+" "+k[2]+" "+k[3]+" "+k[4]);for(var tag:tagNames)out.println("tag "+tag+" "+member(tags,tag,id,new HashSet<>()));}
            for(var line:(Iterable<String>)lines::iterator){var d=new Data();d.f=new JsonParser().parse(line).getAsJsonObject();d.out=out;var other=make(Other.class);other.d=d;other.id=1;var living=make(Living.class);living.d=d;living.id=2;var a=make(Human.class);a.d=d;a.id=3;var b=make(Human.class);b.d=d;b.id=4;d.entities=new Entity[]{null,other,living,a,b};var f=d.f;var kind=f.get("type").getAsString();var k=KIND.get(kind);if(k==null)throw new AssertionError(kind);int direct=f.get("direct").getAsInt(),causing=f.get("causing").getAsInt();var source=switch(f.get("constructor").getAsInt()){case 0->new Source(kind,k[1],d.entities[direct],d.entities[causing],null);case 1->new Source(kind,k[1],d.entities[direct],d.entities[direct],null);case 2->new Source(kind,k[1],null,null,position(f.get("position")));case 3->new Source(kind,k[1],null,null,null);default->throw new AssertionError();};source.d=d;
                try{out.println("direct "+source.isDirect()+" "+d.id(source.getDirectEntity())+" "+d.id(source.stored()));out.println("scales "+scales(k[2],source.stored()));out.println("weapon-result "+(source.getWeaponItem()!=null));out.println("creative "+source.isCreativePlayer());out.println("position-result "+vec(source.getSourcePosition()));out.println("raw "+vec(source.pos));out.println("type "+source.kind.equals(f.get("check_type").getAsString()));out.println("result ok");}catch(Stop e){out.println("result error");}out.println("queries "+d.calls+" "+d.changed);
            }
        }
    }
    // The catalog's scaling rule applied to the stored causing entity,
    // exactly as the Rust model evaluates it: a living non-player is
    // the ArmorStand fake (a player or a marker never scales).
    static boolean scales(String scaling,Entity causing){
        return switch(scaling){case "never"->false;case "always"->true;case "when_caused_by_living_non_player"->causing instanceof net.minecraft.world.entity.LivingEntity&&!(causing instanceof Player);default->throw new AssertionError(scaling);};
    }
}
