package dev.horizonlab.parity;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContextBuilder;
import com.mojang.brigadier.context.ParsedCommandNode;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.SharedConstants;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.Bootstrap;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.ServerScoreboard;
import net.minecraft.server.dedicated.DedicatedServer;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.ServerPacksSource;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.resources.SimpleReloadableResourceManager;
import net.minecraft.server.players.PlayerList;
import net.minecraft.tags.TagLoader;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

/**
 * Runs a corpus of command strings through vanilla's real Brigadier command
 * tree and prints, per input, whether it parses, the error (message and
 * cursor), the parsed nodes and the completion suggestions at the end of the
 * input. Also exports the registry contents the Rust side needs.
 *
 * usage: registries|tree|run OUT_DIR [CORPUS PERMISSION_LEVEL | SELECTION]
 */
public final class VanillaCommandParseOracle {
    static sun.misc.Unsafe unsafe;
    static final String[] PLAYERS = {"Player", "Steve", "Alex"};
    /** ClientSuggestionProvider.getSelectedEntities: the crosshair entity's UUID. */
    static final String[] SELECTED = {"0b9c6a7e-3d1f-4a2b-9c8d-7e6f5a4b3c2d"};
    static final String[] TEAMS = {"red", "blue"};
    static final String[] OBJECTIVES = {"kills", "health", "obj"};
    static final String[] TRACKED = {"#total", "Steve", "fake"};

    static final class Src extends CommandSourceStack {
        final RegistryAccess access;
        final RegistryAccess lookup;
        Src(MinecraftServer server, int perms, RegistryAccess access, RegistryAccess lookup) {
            this(server, null, perms, access, lookup);
        }
        Src(MinecraftServer server, net.minecraft.server.level.ServerLevel level, int perms, RegistryAccess access, RegistryAccess lookup) {
            // 1.18.2: Component has no literal() factory (it arrives in
            // 1.19) — components are built with their constructors.
            super(CommandSource.NULL, Vec3.ZERO, Vec2.ZERO, level, perms, "Player", new net.minecraft.network.chat.TextComponent("Player"), server, null);
            this.access = access;
            this.lookup = lookup;
        }
        @Override public Collection<String> getOnlinePlayerNames() { return new ArrayList<>(List.of(PLAYERS)); }
        @Override public Collection<String> getSelectedEntities() { return new ArrayList<>(List.of(SELECTED)); }
        @Override public Collection<String> getAllTeams() { return new ArrayList<>(List.of(TEAMS)); }
        @Override public RegistryAccess registryAccess() { return access; }
        @Override public Set<ResourceKey<Level>> levels() { return Set.of(Level.OVERWORLD, Level.NETHER, Level.END); }
        // 1.19.2: no enabledFeatures on a command source (feature flags
        // arrive in 1.19.3); every registry's full contents are live.
        // 1.18.1: no suggestRegistryElements hook on the source
        // (it arrives in 1.18.2 with ElementSuggestionType); the
        // era's registry arguments suggest from their own code.
    }

    static void put(Object target, Class<?> owner, String name, Object value) throws Exception {
        Field f = owner.getDeclaredField(name);
        long offset = unsafe.objectFieldOffset(f);
        unsafe.putObject(target, offset, value);
    }

    static String message(CommandSyntaxException e) {
        com.mojang.brigadier.Message m = e.getRawMessage();
        return m.getString();
    }

    public static void main(String[] args) throws Exception {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        var unsafeField = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
        unsafeField.setAccessible(true);
        unsafe = (sun.misc.Unsafe) unsafeField.get(null);
        Path out = Path.of(args[1]);
        var repo = new PackRepository(PackType.SERVER_DATA, new ServerPacksSource());
        repo.reload();
        repo.setSelected(List.of("vanilla"));
        // 1.18.1: SimpleReloadableResourceManager + add per pack
        // (MultiPackResourceManager arrives in 1.18.2).
        var resources = new SimpleReloadableResourceManager(PackType.SERVER_DATA);
        repo.openAllSelected().forEach(resources::add);
        // 1.19.2: no RegistryLayer and no RegistryDataLoader (both arrive
        // in 1.19.3): datapack registries load into a builtin copy through
        // RegistryLoader over the pack resources, then freeze. The
        // loader's constructor is package-private, so build it
        // reflectively, as with the server below.
        // 1.18.1: builtin() RegistryHolder + RegistryReadOps
        // .createAndLoad (see ParityData); ServerResources takes the
        // pack list and binds tags in its own reload.
        RegistryAccess.RegistryHolder holderAccess = RegistryAccess.builtin();
        net.minecraft.resources.RegistryReadOps.createAndLoad(
            com.mojang.serialization.JsonOps.INSTANCE, resources, holderAccess);
        var managers = net.minecraft.server.ServerResources.loadResources(
            repo.openAllSelected(), holderAccess, Commands.CommandSelection.INTEGRATED,
            4, Runnable::run, Runnable::run).join();
        RegistryAccess lookup = holderAccess;
        RegistryAccess access = holderAccess;

        if (args[0].equals("registries")) {
            exportRegistries(out, access, lookup, repo, resources, managers);
            return;
        }
        // 1.18.2: Commands takes the selection alone — CommandBuildContext
        // does not exist yet (it arrives in 1.19.3 with HolderLookup).
        var selection = args[0].equals("tree") && args.length > 2 ? Commands.CommandSelection.valueOf(args[2]) : Commands.CommandSelection.INTEGRATED;
        Commands commands = new Commands(selection);
        CommandDispatcher<CommandSourceStack> dispatcher = commands.getDispatcher();

        if (args[0].equals("tree")) {
            // 1.18.2: node serialization lives on ArgumentTypes (the
            // ArgumentUtils split arrives later).
            Files.writeString(out.resolve("tree.json"), net.minecraft.commands.synchronization.ArgumentTypes.serializeNodeToJson(dispatcher, dispatcher.getRoot()).toString());
            return;
        }
        MinecraftServer server = (MinecraftServer) unsafe.allocateInstance(DedicatedServer.class);
        // The minimal state of a freshly created world that suggestion providers read:
        // empty command storage, stopwatches, boss bars, random sequences and
        // scheduled functions, the world clocks, the vanilla data pack (repository,
        // advancements, functions, structure templates) and an overworld level.
        // 1.19.2: the server's registry field is the frozen access itself,
        // named registryHolder (the layered RegistryLayer form arrives
        // in 1.19.3).
        put(server, MinecraftServer.class, "registryHolder", holderAccess);
        // 1.18.1: the server's resources field IS the ServerResources
        // (the ReloadableResources wrapper arrives in 1.18.2).
        put(server, MinecraftServer.class, "resources", managers);
        put(server, MinecraftServer.class, "functionManager", new net.minecraft.server.ServerFunctionManager(server, managers.getFunctionLibrary()));
        put(server, MinecraftServer.class, "packRepository", repo);
        put(server, MinecraftServer.class, "commandStorage", new net.minecraft.world.level.storage.CommandStorage(null));
        // 1.21.10: no stopwatches (that system is 1.21.11+; neither
        // the class nor the server field exists here).
        put(server, MinecraftServer.class, "customBossEvents", new net.minecraft.server.bossevents.CustomBossEvents());
        // 1.19.4: no RandomSequences — the class and the server field
        // both arrive in 1.20 with the loot random-sequence system.
        put(server, MinecraftServer.class, "scheduledEvents", unsafe.allocateInstance(net.minecraft.world.level.timers.TimerQueue.class));
        // 1.21.11: no world-clock manager (clocks arrive in 26.1); no clockManager field exists.
        // 1.18.2: the class is StructureManager (the rename to
        // StructureTemplateManager arrives in 1.19) and the server field
        // is structureManager; with just its resource manager and
        // template cache set it lists ids from the packs, which is all
        // the suggestion providers read.
        var templates = (net.minecraft.world.level.levelgen.structure.templatesystem.StructureManager) unsafe.allocateInstance(
            net.minecraft.world.level.levelgen.structure.templatesystem.StructureManager.class);
        put(templates, net.minecraft.world.level.levelgen.structure.templatesystem.StructureManager.class, "resourceManager", resources);
        put(templates, net.minecraft.world.level.levelgen.structure.templatesystem.StructureManager.class, "structureRepository", new java.util.concurrent.ConcurrentHashMap<>());
        put(server, MinecraftServer.class, "structureManager", templates);
        var level = (net.minecraft.server.level.ServerLevel) unsafe.allocateInstance(net.minecraft.server.level.ServerLevel.class);
        put(level, Level.class, "dimensionType",
            // 1.18.1: Level holds the DimensionType object itself —
            // no holder, no registration wrapper (both arrive in
            // 1.18.2 with the Holder system).
            access.registryOrThrow(Registry.DIMENSION_TYPE_REGISTRY).getOrThrow(ResourceKey.create(Registry.DIMENSION_TYPE_REGISTRY, new net.minecraft.resources.ResourceLocation("overworld"))));
        put(level, net.minecraft.server.level.ServerLevel.class, "server", server);
        PlayerList playerList = (PlayerList) unsafe.allocateInstance(net.minecraft.server.dedicated.DedicatedPlayerList.class);
        put(playerList, PlayerList.class, "players", new ArrayList<>());
        put(server, MinecraftServer.class, "playerList", playerList);
        ServerScoreboard scoreboard = new ServerScoreboard(server);
        put(server, MinecraftServer.class, "scoreboard", scoreboard);
        for (String team : TEAMS) scoreboard.addPlayerTeam(team);
        for (String objective : OBJECTIVES)
            // 1.20.2: no update-display flag or number format on addObjective.
            scoreboard.addObjective(objective, net.minecraft.world.scores.criteria.ObjectiveCriteria.DUMMY, new net.minecraft.network.chat.TextComponent(objective),
                net.minecraft.world.scores.criteria.ObjectiveCriteria.RenderType.INTEGER);
        Object holder = null;
        for (String tracked : TRACKED)
            // 1.20.2: scores are created by holder name (ScoreHolder arrives in 1.20.3).
            scoreboard.getOrCreatePlayerScore(tracked, scoreboard.getObjective("kills"));
        int perms = Integer.parseInt(args[3]);
        Src source = new Src(server, level, perms, access, lookup);

        List<String> lines = Files.readAllLines(Path.of(args[2]), StandardCharsets.UTF_8);
        java.io.BufferedWriter sb = Files.newBufferedWriter(out.resolve("vanilla.jsonl"));
        for (String raw : lines) {
            String input = raw;
            JsonObject row = new JsonObject();
            row.addProperty("in", input);
            try {
                ParseResults<CommandSourceStack> parse = dispatcher.parse(new StringReader(input), source);
                JsonObject result = new JsonObject();
                String error = null;
                int cursor = 0;
                if (parse.getReader().canRead()) {
                    if (parse.getExceptions().size() == 1) {
                        CommandSyntaxException e = parse.getExceptions().values().iterator().next();
                        error = message(e);
                        cursor = e.getCursor();
                    } else if (parse.getContext().getRange().isEmpty()) {
                        error = new net.minecraft.network.chat.TranslatableComponent("command.unknown.command").getString();
                        cursor = parse.getReader().getCursor();
                    } else {
                        error = new net.minecraft.network.chat.TranslatableComponent("command.unknown.argument").getString();
                        cursor = parse.getReader().getCursor();
                    }
                } else {
                    var ctx = parse.getContext().build(input);
                    // Brigadier 1.1.8 has no ContextChain: a built context
                    // with no command is not an executable command.
                    if (ctx.getCommand() == null) {
                        error = new net.minecraft.network.chat.TranslatableComponent("command.unknown.command").getString();
                        cursor = parse.getReader().getCursor();
                    }
                }
                if (error == null) {
                    result.addProperty("ok", true);
                    JsonArray nodes = new JsonArray();
                    CommandContextBuilder<CommandSourceStack> b = parse.getContext();
                    while (b != null) {
                        for (ParsedCommandNode<CommandSourceStack> n : b.getNodes()) nodes.add(n.getNode().getName());
                        b = b.getChild();
                    }
                    result.add("nodes", nodes);
                } else {
                    result.addProperty("ok", false);
                    result.addProperty("error", error);
                    result.addProperty("cursor", cursor);
                }
                row.add("parse", result);
                Suggestions suggestions = dispatcher.getCompletionSuggestions(parse, input.length()).get();
                JsonObject sg = new JsonObject();
                sg.addProperty("start", suggestions.getRange().getStart());
                sg.addProperty("end", suggestions.getRange().getEnd());
                JsonArray list = new JsonArray();
                for (Suggestion s : suggestions.getList()) {
                    String text = s.getText();
                    if (s.getTooltip() != null) text += "\t" + s.getTooltip().getString();
                    list.add(text);
                }
                sg.add("list", list);
                row.add("sugg", sg);
            } catch (Throwable t) {
                Throwable root = t;
                while (root.getCause() != null) root = root.getCause();
                StackTraceElement[] st = root.getStackTrace();
                row.addProperty("crash", root + (st.length > 0 ? " @ " + st[0] : ""));
            }
            sb.write(row.toString());
            sb.write("\n");
        }
        sb.close();
    }

    // 1.19.2: no FileToIdConverter (it arrives later with the template
    // manager's Source rework): structure ids are the packs' structures/
    // resources with the folder prefix and .nbt suffix stripped, exactly
    // the ids the template manager itself lists.
    static java.util.stream.Stream<net.minecraft.resources.ResourceLocation> templateIds(RegistryAccess lookup, net.minecraft.server.packs.resources.ResourceManager resources) {
        // 1.18.2: listResources takes a path-string predicate and
        // returns the ids directly (no resource map).
        return resources.listResources("structures", path -> path.endsWith(".nbt")).stream()
            .map(id -> new net.minecraft.resources.ResourceLocation(id.getNamespace(),
                id.getPath().substring("structures/".length(), id.getPath().length() - ".nbt".length())));
    }

    static void exportRegistries(Path out, RegistryAccess access, RegistryAccess lookup, net.minecraft.server.packs.repository.PackRepository repo, net.minecraft.server.packs.resources.ResourceManager resources, net.minecraft.server.ServerResources managers) throws Exception {
        JsonObject o = new JsonObject();
        Set<String> learnable = new TreeSet<>();
        // 26.2 has no recipe registry (recipes are not a RegistryDataLoader
        // registry there); the recipe manager is the only source.
        managers.getRecipeManager().getRecipes().stream().filter(h -> !h.isSpecial()).forEach(h -> learnable.add(h.getId().toString()));
        JsonArray learnableArr = new JsonArray();
        learnable.forEach(learnableArr::add);
        o.add("learnable_recipes", learnableArr);
        JsonObject criteria = new JsonObject();
        managers.getAdvancements().getAllAdvancements().stream()
            .sorted(java.util.Comparator.comparing(a -> a.getId().toString()))
            .forEach(a -> {
                JsonArray names = new JsonArray();
                new TreeSet<>(a.getCriteria().keySet()).forEach(names::add);
                criteria.add(a.getId().toString(), names);
            });
        o.add("advancement_criteria", criteria);
        JsonArray blockEntities = new JsonArray();
        // 1.19.2: registries are Registry's own statics (BuiltInRegistries
        // arrives in 1.19.3) and no content is feature-gated.
        for (Block block : Registry.BLOCK) {
            if (block.defaultBlockState().hasBlockEntity())
                blockEntities.add(Registry.BLOCK.getKey(block).toString());
        }
        o.add("block_entities", blockEntities);
        // 1.20.4 predates data components entirely: there is no
        // DATA_COMPONENT_TYPE registry, so the persistent set is
        // empty by construction.
        Set<String> persistent = new TreeSet<>();
        JsonArray persistentArr = new JsonArray();
        persistent.forEach(persistentArr::add);
        o.add("persistent_components", persistentArr);
        JsonObject blockTagMembers = new JsonObject();
        // 1.19.2: no HolderLookup layer at all (it arrives in 1.19.3) —
        // tags read straight off the registry: getTags pairs each TagKey
        // with its bound holder set.
        var blockRegistry = access.registryOrThrow(Registry.BLOCK_REGISTRY);
        // 1.18.1: no per-registry bound-tag view (the Holder/TagKey
        // system arrives in 1.18.2) — tags live in the managers'
        // TagContainer, keyed by registry, values as plain objects.
        managers.getTags().getOrEmpty(Registry.BLOCK_REGISTRY).getAllTags().entrySet().stream()
            .sorted(java.util.Comparator.comparing(e -> e.getKey().toString())).forEach(e -> {
                JsonArray members = new JsonArray();
                e.getValue().getValues().forEach(block -> members.add(blockRegistry.getKey(block).toString()));
                blockTagMembers.add(e.getKey().toString(), members);
            });
        o.add("block_tag_members", blockTagMembers);
        JsonArray selected = new JsonArray();
        repo.getSelectedIds().forEach(selected::add);
        o.add("datapacks_selected", selected);
        JsonArray available = new JsonArray();
        repo.getAvailableIds().forEach(available::add);
        o.add("datapacks_available", available);
        JsonArray enableable = new JsonArray();
        // 1.19.2: packs request no features (that metadata arrives with
        // feature flags in 1.19.3), so every available pack is enableable.
        repo.getAvailablePacks().stream()
            .forEach(p -> enableable.add(p.getId()));
        o.add("datapacks_enableable", enableable);
        // 1.21.11: no world clocks or timelines, so no clock_time_markers export.
        o.add("clock_time_markers", new JsonObject());
        Set<String> templates = new TreeSet<>();
        templateIds(lookup, resources).forEach(id -> templates.add(id.toString()));
        JsonArray templateArr = new JsonArray();
        templates.forEach(templateArr::add);
        o.add("templates", templateArr);
        JsonArray items = new JsonArray();
        for (var item : Registry.ITEM) {
            items.add(Registry.ITEM.getKey(item).toString());
        }
        o.add("items", items);
        JsonObject blocks = new JsonObject();
        for (Block block : Registry.BLOCK) {
            JsonArray props = new JsonArray();
            for (Property<?> p : block.getStateDefinition().getProperties()) {
                JsonArray values = new JsonArray();
                for (Object v : p.getPossibleValues()) values.add(((Property) p).getName((Comparable) v));
                JsonArray pair = new JsonArray();
                pair.add(p.getName());
                pair.add(values);
                props.add(pair);
            }
            blocks.add(Registry.BLOCK.getKey(block).toString(), props);
        }
        o.add("blocks", blocks);
        o.add("item_tags", tags(managers.getTags(), Registry.ITEM_REGISTRY));
        o.add("block_tags", tags(managers.getTags(), Registry.BLOCK_REGISTRY));
        JsonArray summonable = new JsonArray();
        JsonArray types = new JsonArray();
        for (var type : Registry.ENTITY_TYPE) {
            String id = Registry.ENTITY_TYPE.getKey(type).toString();
            types.add(id);
            if (type.canSummon()) summonable.add(id);
        }
        o.add("entity_types", types);
        o.add("summonable", summonable);
        o.add("effects", ids(Registry.MOB_EFFECT));
        o.add("attributes", ids(Registry.ATTRIBUTE));
        o.add("sounds", ids(Registry.SOUND_EVENT));
        o.add("enchantments", dynamic(access, Registry.ENCHANTMENT_REGISTRY));
        // 1.18.2: the structure registry key is STRUCTURE_FEATURE_REGISTRY
        // (worldgen/structure_feature; the structure-type split is later).
        o.add("structures", dynamic(access, Registry.STRUCTURE_FEATURE_REGISTRY));
        o.add("biomes", dynamic(access, Registry.BIOME_REGISTRY));
        // 1.19.3 predates the damage-type registry entirely (it and
        // the /damage command arrive in 1.19.4): the export carries
        // an empty list, as it does for any registry a version lacks.
        o.add("damage_types", new JsonArray());
        // 1.21.10 predates timelines entirely (no TIMELINE registry):
        // the export carries an empty list, as it does for any
        // registry a version does not have.
        o.add("timelines", new JsonArray());
        o.add("dimensions", arr("minecraft:overworld", "minecraft:the_nether", "minecraft:the_end"));
        o.add("players", arr(PLAYERS));
        o.add("selected_entities", arr(SELECTED));
        o.add("teams", arr(TEAMS));
        o.add("objectives", arr(OBJECTIVES));
        o.add("tracked", arr(TRACKED));
        JsonObject by = new JsonObject();
        // 1.18.1: no registries() stream on the access — enumerate
        // the known registry data and resolve each on the access;
        // tag names come from the managers' TagContainer (there is
        // no per-registry tag view before the Holder system).
        // 1.17.1: RegistryAccess has no knownRegistries() stream - the
        // dynamic registry catalogue is the class's static REGISTRIES map
        // (its RegistryData values are package-private, so iterate the
        // keys, which are the registry keys themselves); resolve each on
        // this access as the stream form does.
        var registriesField = RegistryAccess.class.getDeclaredField("REGISTRIES");
        registriesField.setAccessible(true);
        ((java.util.Map<ResourceKey<? extends Registry<?>>, ?>) registriesField.get(null)).keySet().forEach(key -> {
            java.util.Optional<? extends Registry<?>> found = access.registry((ResourceKey) key);
            if (found.isEmpty()) return;
            Registry<?> reg = found.get();
            JsonObject entry = new JsonObject();
            java.util.List<String> ids = reg.keySet().stream().map(k -> k.toString()).sorted().toList();
            JsonArray idArr = new JsonArray();
            ids.forEach(idArr::add);
            entry.add("ids", idArr);
            JsonArray tagArr = new JsonArray();
            java.util.Set<String> tagNames = new java.util.TreeSet<>();
            managers.getTags().getOrEmpty((ResourceKey) key).getAvailableTags().forEach(r -> tagNames.add(r.toString()));
            tagNames.forEach(tagArr::add);
            entry.add("tags", tagArr);
            by.add(key.location().toString(), entry);
        });
        o.add("by_registry", by);
        Files.writeString(out.resolve("registries.json"), o.toString());
    }

    static JsonArray arr(String... values) {
        JsonArray a = new JsonArray();
        for (String v : values) a.add(v);
        return a;
    }

    static <T> JsonArray ids(Registry<T> registry) {
        Set<String> sorted = new TreeSet<>();
        for (var key : registry.keySet()) sorted.add(key.toString());
        JsonArray a = new JsonArray();
        sorted.forEach(a::add);
        return a;
    }

    static <T> JsonArray dynamic(RegistryAccess access, ResourceKey<? extends Registry<T>> key) {
        // 1.19.2: no HolderLookup layer (it arrives in 1.19.3): a dynamic
        // registry's element ids are its own keySet.
        Set<String> sorted = new TreeSet<>();
        access.registryOrThrow(key).keySet().forEach(k -> sorted.add(k.toString()));
        JsonArray a = new JsonArray();
        sorted.forEach(a::add);
        return a;
    }

    static <T> JsonArray tags(net.minecraft.tags.TagContainer tags, ResourceKey<? extends Registry<T>> key) {
        // 1.18.1: tag names live in the TagContainer, not the registry.
        Set<String> sorted = new TreeSet<>();
        tags.getOrEmpty(key).getAvailableTags().forEach(t -> sorted.add(t.toString()));
        JsonArray a = new JsonArray();
        sorted.forEach(a::add);
        return a;
    }
}
